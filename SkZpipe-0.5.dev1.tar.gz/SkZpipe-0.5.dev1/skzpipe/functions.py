import os, subprocess, sys, shutil, math, re, time
import datetime, glob, fileinput, tarfile, copy
import numpy, collections

from .exceptions import *
from .parameters  import basicpar as bpar
from .parameters  import database as _db
from .parameters  import options as _opt
from .parameters.classes  import fileclass
from . import fits
from . import mathfunct

##TEMPLATE for function (15 lines)
############
def TEMPXXYYZZ():
  """Template of function and its Description

Parameters
----------
    x : obj
        X

Returns
-------
    x
""";
  _name_='XXYYZZ';


###variable to manipulate internal input data storage (22)
# runlist=None, entrylist=None, datadict=None, datatag=None, 
#    runlist : None, list
#        list of the entries to process. None for parameter 'runlist'
#    entrylist : None, list, str
#        Ordered list of the entries to choose from. None for parameter 'inputlist'. Or the name of the parameter: 'runlist' for parameter 'runlist', 'inputlist' for parameter 'inputlist'.
#    datadict : None, dict
#        Dictionary of input data (dictionary of dictionaries). None for database defined in parameter 'inputdata'
#    datatag : None, list
#        List of the tags in input data. None for parameter 'datatag'
#
#  if(runlist is None): runlist=bpar.SkZp_Par['runlist'];
#  if(entrylist is None): entrylist=bpar.SkZp_Par['inputlist'];
#  if(isinstance(entrylist, str)):
#    if(entrylist is 'inputlist'): entrylist=bpar.SkZp_Par['inputlist'];
#    elif(entrylist is 'runlist'): entrylist=bpar.SkZp_Par['runlist'];
#    else: raise TypeError(_name_+": `entrylist` must be a list, None or a valid parameter name. <{}>".format(entrylist));
#  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
#  if(datatag is None): datatag=bpar.SkZp_Par['datatag'];
#  if(not isinstance(runlist, list)): raise TypeError(_name_+": `runlist` must be a list.  <{}>".format(runlist));
#  if(not isinstance(entrylist, list)): raise TypeError(_name_+": `entrylist` must be a list.  <{}>".format(entrylist));
#  if(not isinstance(datadict,  dict)): raise TypeError(_name_+": `datadict` must be a dict. <{}>".format(datadict));
#  if(not isinstance(datatag,   list)): raise TypeError(_name_+": `datatag` must be a list. <{}>".format(datatag));



##################
#General Function#
##################

def isinteger(x=None):
  """Check it 'x' can be converted in an integer

Parameters
----------
    x : 
        Object that will be tested for integer conversion.

Returns
-------
    True/False
""";
  try:
    int(x);
    return True;
#  except ValueError, TypeError:
  except:
    return False;

###
def getfloat(x=None, x0=None):
  """Return a float conversion of 'x' or return 'x0' if there is an error.

Parameters
----------
    x : 
        Object to be converted in float.
    x0 : 
        Return value if an error occurs (default None).

Returns
-------
    the float conversion or 'x0'
""";
  try:
    return float(x);
  except (ValueError,TypeError):
    return x0;

###
def extractint(txt=''):
  """Return the first integer present in a string (first all no-cipher characters are replaced with spaces, then it convert the first cipher sequence in an integer). 

Parameters
----------
    txt : str
        string from which the integer is extracted

Returns
-------
    An integer
""";
  return int(re.sub('[^0-9]', ' ', txt).split()[0]);

###
def startime(mesg='', verb=True):
  """Return the current time in seconds. 

Parameters
----------
    mesg : str
        Text to be print after the date.
    verb : bool
        Flag to print time and date.

Returns
-------
    Time in second (time.time())
""";
  _name_='startime';
  if(mesg): mesg+='\n';
  if(verb): print("{progr}\n{date}\n{mesg}".format(progr=sys.argv[0], date=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),mesg=mesg), file=bpar.SkZp_Par['stdout']);
  return time.time();

###
def endtime(starttime=None, verb=True, error=True, tformat='s', ndigit=1):
  """Return the time difference between now and a given time (in seconds). It can print the current date and time and the difference.

Parameters
----------
    starttime : int, float
        Time in seconds (from time.time() or datetime.datetime.now())
    verb : bool
        Flag to print (execution time, error and date).
    error : bool
        Flag to print how many error where capture and where.
    tformat : str
        Format of the execution time: 's' for seconds, 'm' for minutes, 'h' for hours.
    ndigit : int
        precision of the output (used by round()). Default 1.

Returns
-------
    The difference between now and starttime 
""";
  _name_='endtime';
  nowtime=time.time();
  runtime=None;
  if(tformat=='s'): tformat=1.;
  elif(tformat=='m'): tformat=60.;
  elif(tformat=='h'): tformat=3600.;
  else: raise ValueError(_name_+": Wrong value for 'tformat' [{}]. it must be 's', 'm', or 'h'.".format(tformat));
  if(isinstance(starttime,(int,float))):
    runtime=int(round(nowtime-starttime, 0));
    if(verb): print(round(runtime/tformat,ndigit), file=bpar.SkZp_Par['stdout']);
  if(verb):
    if(error): print("\nError count:", len(bpar.SkZp_Par['errorlist']), bpar.SkZp_Par['errorlist'], file=bpar.SkZp_Par['stdout']);
    print("{:}\n{:}\n".format(sys.argv[0], datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')), file=bpar.SkZp_Par['stdout']);
  return runtime;

###
def seterrorlist():
  """Backup old error list and clear it.
""";
  _name_='seterrorlist';
  if(bpar.SkZp_Par['errorlist']):
    bpar.SkZp_Par['errorhistory'][datetime.datetime.now().strftime('%Y%m%d_%H%M%S')]=bpar.SkZp_Par['errorlist'].copy(); 

  bpar.SkZp_Par['errorlist'].clear();

###
def pathsplit(fname=None):
  """Separate the full path of a file in dirname,basename.

Parameters
----------
    fname : str
        Filename with path

Returns
-------
    out : tuple of str
        (dirname, basename)
""";
  _name_='pathsplit';
  if(not isinstance(fname,str)): raise TypeError(_name_+": fname must be a string");
  return (os.path.dirname(fname), os.path.basename(fname));


###
def splitconvert(data=None, delimiter=None,  converters=None, maxsplit=-1, appendinput=0, delim_repeat=False, conv_repeat=False):
  """Split the input 'data' into parts according to `delimiter` and convert them according to `converters`.

Parameters
----------
    data : str or list or tuple
        Data to be processed. It can be any object that can use the [:] notation.
    delimiter : str, sequence of int
        The string used to separate values, or sequence of integers as widths of the fields, or the common width of all the fields.
    converters : tuple or list of functions/None
        Tuple of callables that convert the data of a field to a value. None to leave as it is the data.
    maxsplit : int
        If maxsplit is given, at most `maxsplit` splits are done. If negative, all the splits are done.
    appendinput : bool, int
        False, 0: just standard output
        True, >0: the last element of the tuple will be the whole initial input.
        < 0: the last element of the tuple will be the initial input not converted.
    delim_repeat : bool
        If `delimiter` is a sequance of integer, the last will be used to extract the remaining fields.
    conv_repeat : bool
        If True, the last entry of `converters` will be used on all the remaining fields.

Returns
-------
    out : tuple
        Tuple of object. The number is limited by `maxsplit` (-1 for all, if not negative the tuple will include `maxsplit` objects).
""";
  _name_='splitconvert';
  if(not isinstance(maxsplit,int)): raise TypeError(_name_+": `maxsplit` must be an integer");
  if(not isinstance(appendinput,(bool,int))): raise TypeError(_name_+": `maxsplit` must be an integer");
  if(maxsplit==0): return ();
  unconverted=None;
  if(isinstance(delimiter, int)): delimiter=(delimiter,)*int(len(data)/delimiter+1);
  if(isinstance(data,str) and (delimiter is None or isinstance(delimiter,str))):
    tmpL=data.split(delimiter, maxsplit=maxsplit);
    if(maxsplit<len(tmpL)): unconverted=tmpL[maxsplit]
    if(maxsplit>0): tmpL=tmpL[:maxsplit];
  elif(not isinstance(data,str) and isinstance(delimiter,str)): raise TypeError(_name_+": `delimiter` cannot be a str if `data` is not");
  elif(isinstance(data,(str,list,tuple)) and isinstance(delimiter,(list,tuple))):
    tmpL=[];
    tmps=copy.copy(data);
    for pp in delimiter:
      if(pp>0):
        tmpL.append(tmps[:pp]);
        tmps=tmps[pp:];
      elif(pp==0):
        tmpL.append(tmps[:0]);
      else: 
        break;
      if(len(tmps)==0 or len(tmpL)==maxsplit): break
    if(delim_repeat and len(tmpL)!=maxsplit):
      while(len(tmps)):
        if(delimiter[-1]>0):
          tmpL.append(tmps[:delimiter[-1]]);
          tmps=tmps[delimiter[-1]:];
        elif(delimiter[-1]==0):
          tmpL.append(tmps[:0]);
        else: 
          break;
        if(len(tmps)==0 or len(tmpL)==maxsplit): break
    unconverted=tmps;

  if(converters):
    if(conv_repeat and len(tmpL)>len(converters)): converters+=converters[-1:]*(len(tmpL)-len(converters))
    for ii in range(min(len(converters), len(tmpL))):
      if(callable(converters[ii])): tmpL[ii]=converters[ii](tmpL[ii]);

  if(appendinput):
    tmpL.append( data if(appendinput>0) else unconverted );

  return tuple(tmpL);


###
def scriptdefine(auto=True):
  """Analize the name of the script (sys.argv[0]) and split it in path and scriptname, and the type of the name (the part after '_')

Parameters
----------
    auto : bool
        If to set automatically the 'script' global parameter with its output

Returns
-------
    Tuple of 3 str: scriptpath, scriptname, scriptype
""";
  (pathscript, scriptname, scriptype)=(None,)*3;
  if(sys.argv[0]!=''):
    (pathscript, scriptname)=pathsplit(sys.argv[0]);
    scriptname=re.sub('\.py$','',scriptname)
    scriptype=scriptname.split('_')[-1];
  if(auto): bpar.SkZp_Par['script'].update({'pathscript':pathscript, 'scriptname':scriptname, 'scriptype':scriptype});
  return (pathscript, scriptname, scriptype);


###
def backupfile(fname=None, keep=False):
  """Create a back-up of a file. The backup file name has the modification time appended to the end.

Parameters
----------
    fname : str
        Name of the file to backup
    keep : bool
        Flag to create a backup or change the name of the exixting file.

Returns
-------
    Integer: 0 for succeed, -1 for failing
""";
  if(isinstance(fname,str) and os.path.exists(fname)):
    if(keep):
      shutil.copy(fname, fname+datetime.datetime.fromtimestamp(os.stat(fname).st_mtime).strftime('-%Y%m%d_%H%M%S'));
    else:
      shutil.move(fname, fname+datetime.datetime.fromtimestamp(os.stat(fname).st_mtime).strftime('-%Y%m%d_%H%M%S'));
    return 0;
  return -1;


###
def file_stat(infile='', opt=None):
  """

Parameters
----------
    infile : str
        Name of the file to analyze
    opt : str
        String with options: 'l' for line count; 'c' for character count; 's' for space count.

Returns
-------
    Tuple of the values
""";
  if(opt is None): opt='l';
  elif('s' in opt): opt='lcs';
  nl=-1;
  if(os.path.exists(infile)):
    with open(infile, 'rb') as f_in:
      minl, minll,  nc, nl, nll,  maxl, meanl, meansp=1e100,1e100,  0,0,0,  0,0,0;
      buf=f_in.read(1<<20);
      while (buf):
        nl+=buf.count(b'\n');
        if('c' in opt):
          len_a=len(buf);
          nc+=len_a;
          if('s' in opt):
            npos=buf.find(b'\n');
            opos=0;
            while(npos>=0):
              if(maxl<len_a): maxl=len_a;
              if(minl>len_a): minl=len_a;
              meanl+=len_a;
              len_nosp=len(re.sub('\s','',line));
              meansp+=len_a-len_nosp;
              if(len_nosp>0):
                nll+=1;
              if(minll>len_a): minll=len_a;
              opos=npos;
              npos=buf.find(b'\n', opos+1);
        buf=f_in.read(1<<20);
      if('s' in opt):
        return (nl, nc, nll, minl, minll, maxl, meanl/i, meansp/i);
  return (nl);
  

###
def get_num_lines(infile=None):
  """Return the number of lines of a file. A line terminates with a newline '\n'.

Parameters
----------
    infile : str
        Name of the file to process.

Returns
-------
    Number of lines in the file. -1 for errors
""";
  if(infile is None): return -1;
  if(os.path.exists(infile)):
    BSIZE=1024;
    nl=0;
    with open(infile, 'rb') as f_in:
      buf=f_in.read(BSIZE);
      while (buf):
        nl+=buf.count(b'\n');
        buf=f_in.read(BSIZE);
    return nl;
  return -1;

############
def tailfile(f=None, n=1):
  """Return the last 'n' lines of the file 'f'

Parameters
----------
    f : str or IOStream
        Name of the file or an object with method read and seek.
    n : int
        Number (not negative) of the lines to return

Returns
-------
    ret : list of str
        List of the last 'n' lines (with terminal newline). If n==0, then an empty list is return anyway. If the file is empty, return a list with empty lines.
""";
  _name_='tailfile';
  if(not isinstance(n,int)): raise TypeError(_name_+": 'n' must be an int");
  if(n<0): raise ValueError(_name_+": 'n' must be a not negative int");
  if(n==0): return [];
  if(not isinstance(f, (str,IOStream))): raise TypeError(_name_+": 'f' must be a str (filename) or a IOStream");
  if(isinstance(f, str)):
    if(not os.path.exists(f)): raise IOError(_name_+": file {f} does not exist".format(f=f));
    f=open(f, 'rb');
  BSIZE = 1024;
  f.seek(0, 2);
  posbyte = f.tell();
  missing = n;
  nread = 1;
  data='';
  ret=[];
  while(missing > 0 and posbyte > 0):
      if(posbyte - BSIZE > 0):
        f.seek(-nread*BSIZE, 2);
        data=f.read(BSIZE)+data;
      else:
        f.seek(0,0);
        data=f.read(posbyte)+data;
      nl=data.rfind(b'\n');
      if(nl>=0):
        ret[0:0]=data[nl+1]
      missing -= lines_found;
      posbyte -= BSIZE;
      nread+=1;
  return data;




###
def check_file(files=[], minline=1, namemaxlen=256, raisexc=True):   #RAISE IOError SkZpipeErr
  """Check a file if it exists, has enough lines and its filename is not too long.

Parameters
----------
    files : list
        List of filenames to check
    minline : int
        Minimum number of lines
    namemaxlen : int
        Maximum length of filenames
    raisexc : bool
        Flag to set if raise an exception or just return an error value.

Returns
-------
    check : 0 or tuple
    0 if all files exist.
    If raisexc, an exception
    Otherwise, a tuple with the filename and: 
      1 if a filename is longer than the maximum namelength,
      2 if a file doesn't exist or has less lines than the minimum.
     -1 is return if None is passed as filename.
""";
  _name_='check_file';
  if(not isinstance(files, list)): 
    if(isinstance(files, str)):  files=[files];
    elif(files is None): return -1;
    else:  raise TypeError(_name_+": wrong arguments")
  for ifile in files:
    if(ifile is None): return (ifile,-1);
    size=get_num_lines(ifile);
    if(size<minline):
      if(raisexc):
        raise OSError("!!!ERROR: file {:} has not enough lines or doesn't exist! (size:{:d}; min:{:d})".format(ifile, size, minline));
      else:
        return (ifile,2);
    if(namemaxlen is None): continue;
    if(len(ifile)>namemaxlen):
      if(raisexc):
        raise SkZpipeError("the filename {:} is too long! Maximum length is {:} characters.\n".format(ifile, str(maxlenm)));
      else:
        return (ifile,1);
  return 0;


###
def clean_file(files=None, suff=None):
  """Delete files if they exist.

Parameters
----------
    files : str or tuple of str   or  list of (str or tuple od str)
        The filename or a tuple with (basename, extension) of a list of these to delete if existing.
    suff : str, None
        If present, an existing file will be rename adding this suffix instead of be deleting.
Returns
-------
    None
""";
  _name_='clean_file';
  if(suff is not None and not isinstance(suff, str)): raise TypeError(_name_+": 'suff' must be a string or None <{}>".format(repr(suff)));
  if(not isinstance(files, list)): 
    if(isinstance(files, (str,tuple))): 
      files=[files];
    else: raise TypeError(_name_+": 'files' must be a (list of) str or tuple of str <{}>".format(repr(files)));
  for ofile in files:
    if(isinstance(ofile, tuple)):
      if(all( isinstance(x, str) for x in ofile)): ofile=ofile[0]+ofile[1];
      #elif(not isinstance(ofile[0], str)): raise TypeError(_name_+": 'files' must be a (list of) str or tuple of str <{}>".format(repr(ofile)));
      else: raise TypeError(_name_+": 'files' must be a (list of) str or tuple of 2 str <{}> <{}>".format(repr(ofile), repr(files)));
      
    if(os.path.exists(ofile)):
      if(suff):
        shutil.move(ofile, ofile+suff);
      else:
        if(ofile.endswith('.als') or ofile.endswith('.pdf')): print("!!!!>", files, suff, "<!!!")
        os.unlink(ofile);


##################
##################
def fixpathprogram(progr=None, pathdir=None):
  """Fix to the program name adding an existing pathdiri, if it was not given with full path.

Parameters
----------
    progr : str
        Name of the program
    pathdir : str
        Alternative directory where the program is located. If not set, the value store in 'pathdir' option will be used.

Returns
-------
    progr : str
        The program name.
""";
  _name_='fixpathprogram';
  if(not progr or not isinstance(progr, str)): raise TypeError(_name_+": `progr` must be a string");
  if(pathdir and not isinstance(pathdir, str)): raise TypeError(_name_+": `pathdir` must be a string or None");

  if(os.path.sep not in progr):
    if(not pathdir): pathdir=_opt.SkZp_Opt['S']['pathdir'];
    if(pathdir):  progr=pathdir+os.path.sep+progr;
  return progr;


######
def proc_writeline(txt=None, proc=None, f_log=None):
  """Send a string to a program in execution through standard input and write it down in the log stream.

Parameters
----------
    txt : str
        Text to be sent

Returns
-------
    x
""";
  if(txt is None or proc is None): return 1;
  txt=str(txt);
  if(f_log is not None): f_log.write('=> '+txt+'\n');
  proc.stdin.write(bytes(txt+'\n','utf-8'));
#  proc.stdin.write(txt+'\n');
  proc.stdin.flush()
  if(f_log is not None): f_log.flush();
  return 0;


#####
def tell_progr(progr, mess, f_Log=None):
  """Execute an external program passing command through stdandard input.

Parameters
----------
    progr : str
        Name of the program to execute
    mess : list
        List of input for the program to be passed through standard input
    f_Log : str
        Name of the stream to log output.

Returns
-------
    x
""";
  with subprocess.Popen(progr, shell=False, stdin=subprocess.PIPE, stdout=f_Log) as proc:
    for imes in mess:
      proc_writeline(imes, proc, f_Log);


###
def get_output(cmd):
  """

Parameters
----------
    x : 
        X

Returns
-------
    x
""";
  if(cmd):
    proc=subprocess.run(cmd);
    if(proc.stderr): bpar.SkZp_Par['stderr'].write(proc.stderr.decode('utf-8'));
    return proc.stdout.decode('utf-8');
  else:
    return '';

###
def GetFileType(fname=None, fstream=None):
  """Create a signature of the format of the file

Parameters
----------
    fname : str or None
        Name of the file
    fstream : IOStream
        Object that support read method.

Returns
-------
    out : tuple of str
        Tuple of file format: (Main, sub-type)
""";
  _name_='GetFileType';
  if(fname is None and fstream is None): raise ValueError(_name_+": 'fname' and 'fstream' cannot be both undefined.");
  if(fname is not None and isinstance(fname,str)): raise TypeError(_name_+": 'fname' must be a string.");
  if(fname): fstream=open(fname);

  line=fstream.read();
  if(line.strip() == "NL    NX    NY  LOWBAD HIGHBAD  THRESH     AP1  PH/ADU  RNOISE    FRAD"):
    if(fname): ext=fname.split('.')[-1];
    line=fstream.read();
    nl=int(line.split()[0]);
    for ii in range(3 if(nl==2)else 2):
      line=fstream.read();
    num=len(line.split());
    if(nl == 2):
      if(num==4): return ("DAO","ap");
      else: return ("DAO","ap");
    elif(nl == 1):
      if(num==9): return ("DAO","als");
      elif(num==6): return ("DAO","coo");
      
    elif(nl == 3):
      if(ext=='lst'): return ("DAO","lst");
      elif(ext=='nst'): return ("DAO","nei");
      else:
        raise SkZpipeError("Unknown file type of DAO type", exclocus=_name_);
    

 
  ##
  if(fname): fstream.close();

############
def ProcedureRequiredMemory(procedure=None, argsize=None, ndigits=2):
  """Template of function and its Description

Parameters
----------
    procedure : str
        Name of the procedure.
    argsize : dict
        Dict with the information about the size of the arguments of the procedure
    ndigits : int
        Precision in decimal digits for the rounding

Returns
-------
   x : float
    Required memory by the procedure
""";
  _name_='ProcedureRequiredMemory';
  if(procedure == 'DAOallframe'):
    totsize=numpy.array(argsize['images']).sum()*3+argsize['other'];
  elif(procedure == 'stack'):
    totimg=numpy.array(argsize['images']).sum();
    totlst=numpy.array(argsize['lists']).sum();
    nimg,nlst=len(argsize['images']), len(argsize['lists']);
    totimg*= 3 if(argsize['improvepos']=='allframe') else 1.5;
    totsize=round(max(totimg, 2*totlst),2);
  else: raise ValueError(_name_+": Wrong value for 'procedure', not a recognized procedure.");
  return round(totsize, ndigits);

############
def FramedText(txt='', excl=False):
  """Create a frame of # around a text.

Parameters
----------
    txt : str
        Text to frame
    excl : bool
        Flag to add 3 exclamation marks before and after

Returns
-------
    Framed text
""";
  _name_='FramedText';
  if(not isinstance(txt,str)): raise TypeError(_name_+": Wrong type for input. It muct be a str");
  if(excl): txt="!!! "+txt+" !!!";
  frmtxt="#"*(len(txt)+4) + "\n# " + txt + " #\n" + "#"*(len(txt)+4);
  return frmtxt;

###
def WaitStop(names=[''], suff=''):
  """Check for signal to stop (temporarly or defenitely) the execution. The presence of a WAIT or *.WAIT file will pause the executio, while the presence of a STOP or *.STOP file will stop the execution. 

Parameters
----------
    names : list, str
       List of basenames for the .WAIT and .STOP
    suff : str
        Suffix for the '.WAIT' extension.
Returns
-------
    Time spent during the process.
""";
  _name_='WaitStop';
  initime=time.time();
  if(isinstance(names,str)): names=[names];
  if(not isinstance(names,list)): raise TypeError(_name_+": Wrong type for 'names'. It must be a list of str or a str.");
  if(any(not isinstance(name,str) for name in names) ): raise TypeError(_name_+": Wrong type for 'names'. It must be a list of str or a str. < {names} >".format(names=names));
  if(not isinstance(suff,str)): raise TypeError(_name_+": Wrong type for 'suff'. It must be a str.");
  for name in ['']+names:
    try:
      while(os.path.exists("WAIT"+suff) or os.path.exists(name+".WAIT"+suff)):
        time.sleep(10);
    except  KeyboardInterrupt :
      pass;
  for name in ['']+names:
    if(os.path.exists("STOP") or os.path.exists(name+".STOP")):
      print('\n'+FramedText("Obbedisco", excl=True), file=bpar.SkZp_Par['stdout']);
      print(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), file=bpar.SkZp_Par['stdout']);
      sys.exit(-1);
  return round(time.time()-initime, 1);


###
def read_until(fobj, txt, line=''):
  """Read from the given file object until the line contains the string in 'txt' or at least one of the string in the list/tuple 'txt'

Parameters
----------
    fobj : file object
        File object from where to read.
    txt : str, list, tuple
        String to look for in the read lines or a list/tuple with the string to look for.
    line : str
        Inicial value for the read line

Returns
-------
    The line that match the given string. Or '' if the end-of-file is reached before.
""";
  if(not line): line=fobj.readline()
  if(not isinstance(txt, (tuple,list))): txt=[txt];
  while(line and not any(tt in line for tt in txt)):
    line=fobj.readline()
  return line;


###
def SpeedUpTest():
  """Print a warning message if speed-up option is on.

Returns
-------
    Warning message.
""";
  _name_='SpeedUpTest';
  if( _opt.SkZp_Opt['I']['speedup']>0 ):
    print('\n'+FramedText("Speed-up activated: {:2d}".format(_opt.SkZp_Opt['I']['speedup']), excl=True)+'\n', file=bpar.SkZp_Par['stdout']);


###
def flush_out():
  """Flush standard output and error as defined internally in SkZp_Par['stdout'] and SkZp_Par['stderr'].

""";
  bpar.SkZp_Par['stdout'].flush();
  bpar.SkZp_Par['stderr'].flush();
  


###
def Check4space(minspace):
  """Check if on the current partition there is enough free space.

Parameters
----------
    minspace : int or float
        Minimum amount of MiB necesary.

    
""";
  if(minspace):
    statvfs=os.statvfs('./');
    frspace=(statvfs.f_bavail*statvfs.f_frsize)>>20;
    if(frspace<minspace):
      print("!!!ATTENTION: NOT ENOUGH FREE SPACE! ({:d}<{:d})\nDelete file WAIT after having freed enough memory\n".format(frspace, minspace), file=bpar.SkZp_Par['stdout']);
      with open("WAIT",'w') as f_tmp:
        f_tmp.write('');
      WaitStop();




############
def DictdataUpdate(olddict=None, newdict=None, override=False):
  """Update properly a dictionary with data from new one. It will update only if the item is new or if new value is not None. By default it updates only keys with value None.

Parameters
----------
    olddict : dict
        Dictionary to be updated
    newdict : dict
        Dictionary with the new values
    override : bool
        Flag to update also items with value not None

Returns
-------
    Tuple: number of new items, number of updatable items.
""";
  _name_='DictdataUpdate';
  if(not isinstance(olddict,dict)): raise TypeError(_name_+": 'olddict' must be a dict");
  if(not isinstance(newdict,dict)): raise TypeError(_name_+": 'newdict' must be a dict");
  if(not isinstance(override,bool)): raise TypeError(_name_+": 'override' must be a bool");
   #Update only if new value is not None
  newdata, updata={},{};
  for tag,val in newdict.items():
    if(tag in olddict):
      if(val is not None):
        if(olddict[tag] is None): newdata[tag]=val;
        elif(olddict[tag]==str(val)): newdata[tag]=val;
        else: updata[tag]=val;
    else: newdata[tag]=val;
  olddict.update(newdata);
  if(override):
    olddict.update(updata);
  return (len(newdata), len(updata));
    
######################
def ParameterHelp(param=None):
  """Print the description of a parameter

Parameters
----------
    par : str
        Name of the option

Returns
-------
    Value and description (if present);
""";
  _name_='ParameterHelp';
  for pardict in (bpar.SkZ_Par, bpar.DAO_Par):
    if(param in pardict):
      print("Parameter {par} is set as:".format(par=param), pardict[param], file=bpar.SkZp_Par['stdout'])
      if('_doc_' in pardict and param in pardict['_doc_']): print(pardict['_doc_'][param], file=bpar.SkZp_Par['stdout']);
      else: print("No description.", file=bpar.SkZp_Par['stdout'])
      return;
  print("The parameter '{par}' does not exist.".format(par=param), file=bpar.SkZp_Par['stdout']);
  return;


########################################################
########################################################
######
##LOCK
def LockRun(runfile=None):
  """Create a lock file

Parameters
----------
    runfile : str
        Basename to use for the lock file, adding the suffix set in SkZp_Opt['S']['lockext'].

Returns
-------
    True if the file is create, False/None otherwise.
""";
  if(runfile is None or runfile==''): return False;
  lockfile=runfile+_opt.SkZp_Opt['S']['lockext'];
  if(os.path.exists(lockfile)):
    raise SkZpipeError("it seems that there is already a SkZpipe running for the file!", exclocus=runfile);
  with open(lockfile, "w") as f_tmp:
    f_tmp.write("1");
    return True;
    

###
def UnLockRun(lock=False, runfile=None):
  """Remove the lock file

Parameters
----------
    lock : bool
        Flag for the lock status
    runfile : str
        Basename to use for the lock file, adding the extension set in SkZp_Opt['S']['lockext'].

Returns
-------
    True if nothing has to be done, False if the lock file is removed.
""";
  if(not lock or runfile is None or runfile==''): return True;
  lockfile=runfile+_opt.SkZp_Opt['S']['lockext'];
  clean_file([lockfile]);  ### MULTISTEP
  return False;

###
def LockRunCheck(entrylist=None, verb=False):
  """Create a lock file

Parameters
----------
    entrylist : list of str, None
        List of basenames to check for active lock files, adding the suffix set in option 'lockext'.
    verb : bool
        If to print to stdout the list.

Returns
-------
    output : list of str
        List of basenames with active lock files.
""";
  if(entrylist is None): entrylist=bpar.SkZp_Par['inputlist'];
  lockL=[entry for entry in entrylist if(os.path.exists(entry+_opt.SkZp_Opt['S']['lockext']))];
  if(lockL):
    if(verb or _opt.OptionGet('debug')): print("These entries has an active lock file", lockL, file=bpar.SkZp_Par['stdout']);
  return lockL;
  
##lock

##VIRCAM 
def VIRCAM_setstripeid(stripe=None):
  """Return the correct identificator (a-h) of the VIRCAM stripe

Parameters
----------
    stripe : str, int
        Identification of the "stripe" of a VIRCAM tile as a integer [1-8] or a letter [a-h,A-H]

Returns
-------
    Return the name of the stripe as a letter among a and h
""";
  _name_='VIRCAM_setstripeid';
  if(not isinstance(stripe,str) and not isinstance(stripe, int)): raise TypeError(_name_+": stripe must be a [a-h] character or a [1-8] integer");
  if(isinstance(stripe,str)):
    stripe=stripe.lower();
    if(not re.find('[a-h]',stripe)): raise ValueError(_name_+": stripe must be [a-h]");
  elif(stripe>8 or stripe<1): raise ValueError(_name_+": stripe must be between 1 and 8");
  else:
    stripe=chr(ord('a')+stripe-1);
  return stripe;
  

###
def VIRCAM_getstripeid(chip=None, offset=None):
  """Return the identificator of the stripe of the image in a VIRCAM tile

Parameters
----------
    chip : int
        Number of the chip
    offset : int
        Number of the offset

Returns
-------
    The letter [a-h] of the stripe
""";
  _name_='VIRCAM_getstripeid';
  return chr(((int(chip)-1)>>2)<<1+int((int(offset)-1)/3)+ord('a'));


###
def VIRCAM_getcenterpos(chip=None, offset=None):
  """Return the identificator of the stripe of the image in a VIRCAM tile

Parameters
----------
    x : 
        X

Returns
-------
    x
""";
  return (22.0*(((chip-1)%4)-1.5), 20.3*(((chip-1)>>2)-1.5));
##vircam



###
def FitsHeaderInfoClean(value, spacerepl):
  """

Parameters
----------
    value : str, float, integer
        Value of the header card

Returns
-------
    x
""";
  _name_="FitsHeaderInfoClean";
  if(not isinstance(value, str)): return value;
  if(' / ' in value):    value=value[0:value.rfind(' / ')];
  value=value.replace("'",'').strip().replace(' ', spacerepl);
  #Not string
  try:
    value= float(value) if('.' in value) else int(value);
  except ValueError:
    pass;
  return value;
  


###
def FitsHeaderInfoLineRead(line='', spacerepl=None):
  """Transform a line of a FITS header into a tuple.

Parameters
----------
    line : str
        Line from a FITS header containing the card.
    spacerepl : str
        String to replace internal spaces in the value of the card

Returns
-------
    out : tuple
        Tuple of two values: the card name and the value
""";
  _name_='FitsHeaderInfoLineRead';
  if(not isinstance(line, str)): raise TypeError(_name_+": 'line' must be a string");
  if(spacerepl is None): spacerepl=bpar.SkZp_Par['charconversion'][' '];
  if(not isinstance(spacerepl, str)): raise TypeError(_name_+": 'spacerepl' must be a string");
  line=line.strip();
  if(len(line)<3 or line[0]=='#' or not '=' in line): return ();
  tmpl=[s.strip() for s in line.split('=')];
  if(not tmpl[0] or not tmpl[1]): return ();
  tmpl[0]=re.sub('^HIERARCH','',tmpl[0]).strip();
  return ( tmpl[0], FitsHeaderInfoClean(tmpl[1], spacerepl) );


###
def FitsHeaderInfoRead(header=None, index=0, spacerepl=None):
  """Read the header of a image opening directly the image or using an existing header file.

Parameters
----------
    header : str, HDU
        Name of the image or of the text file where the header info were stored.
    index : int, str
        Number or name of the HDU from where read the header. -1 to retieve all the headers.
    spacerepl : str
        String to replace internal spaces in the value of the card

Returns
-------
    output: list
        A list of dictionaries with the header data.
""";
  _name_='FitsHeaderInfoRead';
  if(spacerepl is None): spacerepl=bpar.SkZp_Par['charconversion'][' '];
  if(not isinstance(spacerepl, str)): raise TypeError(_name_+": 'spacerepl' must be a string");
  hdrinfo={};
  if(not isinstance(index, (int,str))): raise TypeError(_name_+": 'index' have to be an integer or string");
#  if(isinstance(index, int) and index<0): raise TypeError(_name_+": 'index' have to be a no-negative integer or string");
  hdrinfo=[];
  try:
    if(isinstance(header,str)):
      if(re.search('\{ext}?$'.format(ext=_opt.OptionGet('fitsextension')), header)):
        if(isinstance(index,int)):
          if(index<0):
            with fits.pyfits.open(header) as hdul:
              for hdu in hdul:
                hdrinfo.append(dict(hdu.header));
          else: hdrinfo.append(dict(fits.pyfits.getheader(header, ext=index)));
        else:
          hdrinfo.append(dict( fits.pyfits.getheader(header, extname=index) ));
        for hdr in hdrinfo: #you can iterate because it containobject return by pointer, not value
          for tag in hdr:
            hdr[tag]=FitsHeaderInfoClean(hdr[tag], spacerepl);
      else:
#      elif(re.search('hdr$',header)):
        with open(header) as f_hdr:
          hdrinfo.append({});
          for line in f_hdr:
            line=FitsHeaderInfoLineRead(line, spacerepl);
            if(line):
              hdrinfo[0][line[0]]=line[1];
    elif(isinstance(header, (fits.pyfits.PrimaryHDU,fits.pyfits.hdu.image.ImageHDU,fits.pyfits.hdu.base.ExtensionHDU))):
      hdrinfo.append(dict(header.header));
      for hdr in hdrinfo: #you can iterate because it containobject return by pointer, not value
        for tag in hdr:
          hdr[tag]=FitsHeaderInfoClean(hdr[tag], spacerepl);
    else: raise TypeError(_name_+": `header` must be the name of the file (FITS or txt file with header info) or a HDU");
  except:
    raise;

  for key in ['', 'COMMENT']: #keys to be removed
    if(key in hdrinfo): del(hdrinfo[key]);  #it is a dict, so just 1 item for each key!!

  return hdrinfo;


###
def InputDataSetMJD(force=False, entrylist=None, datadict=None):
  """Calculate the Modified Julian Date for each entry.

Parameters
----------
    force : bool
        Force the calculation even if there is a value.
    entrylist : None, list
        List of input data entries. None for SkZp_Par['inputlist']
    datadict : None, dict
        Dictionary of input data (dictionary of dictionaries). None for SkZp_Par['inputdata']

Returns
-------
    None
""";
  _name_='InputDataSetMJD';
  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
  if(entrylist is None): entrylist=bpar.SkZp_Par['inputlist'];
  if(isinstance(entrylist, str)):
    if(entrylist is 'inputlist'): entrylist=bpar.SkZp_Par['inputlist'];
    elif(entrylist is 'runlist'): entrylist=bpar.SkZp_Par['runlist'];
    else: raise TypeError(_name_+": `entrylist` must be a list, None or a valid parameter name. <{}>".format(entrylist));
  if(not isinstance(datadict,  dict)): raise TypeError(_name_+": 'datadict' must be a dict. <{}>".format(datadict.__class__));
  if(not isinstance(entrylist, list)): raise TypeError(_name_+": 'entrylist' must be a list. <{}>".format(entrylist));
  for img in entrylist:
    if(force or datadict[img]['MJD'] is None):
      if(datadict[img]['DATE'] is not None and datadict[img]['TIME'] is not None):
        (year,mt,day)=( int(x) for x in datadict[img]['DATE'].split('-'))
        (hour,mn,sec)=( float(x) for x in datadict[img]['TIME'].split(':'))
        datadict[img]['MJD']=datetime.date(year,mt,day).toordinal()+(hour+mn/60.+sec/3600.)/24.+1721424-2400000.;

###
def InputDataSetNightNumber(relenum=True, force=False, entrylist=None, datadict=None):
  """Calculate the observation night number for each entry.

Parameters
----------
    relenum : bool
        True to set the night number as relative (the observation night will be enumerated); False to set the night number as temporal distance (MJD-MJD0+1). Option 'inputdata:#night_rel'
    force : bool
        Force the calculation even if there is a value.
    entrylist : None, list
        List of input data entries. None for SkZp_Par['inputlist']
    datadict : None, dict
        Dictionary of input data (dictionary of dictionaries). None for SkZp_Par['inputdata']

Returns
-------
    None
""";
  _name_='InputDataSetNightNumber';
  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
  if(entrylist is None): entrylist=bpar.SkZp_Par['inputlist'];
  if(isinstance(entrylist, str)):
    if(entrylist is 'inputlist'): entrylist=bpar.SkZp_Par['inputlist'];
    elif(entrylist is 'runlist'): entrylist=bpar.SkZp_Par['runlist'];
    else: raise TypeError(_name_+": `entrylist` must be a list, None or a valid parameter name.");
  if(not isinstance(datadict,  dict)): raise TypeError(_name_+": 'datadict' must be a dict.");
  if(not isinstance(entrylist, list)): raise TypeError(_name_+": 'entrylist' must be a list.");
  tjdL,nn = [],0;
  nit=_opt.OptionGet('inputdata:nightstart');
  for img in entrylist:
      if(datadict[img]['MJD'] is not None): tjdL.append(int(datadict[img]['MJD']-nit));
      if(datadict[img]['NIGHT'] is not None): nn+=1;
  if(len(entrylist)>len(tjdL)): print(_name_+": !!!WARNING!!! Not all the entries have a MJD set.", file=bpar.SkZp_Par['stdout'] )
  if(nn>0 and nn<len(entrylist)):
    print(_name_+": !!!WARNING!!! Some entries have already a NIGHT set: Possibility of inconsistency. Rerun with parameter `force` or option 'inputdata:#nightset' set to True.", file=bpar.SkZp_Par['stdout'] )
  if(_opt.SkZp_Opt['Flg']['inputdata:nightrel']):
    tjdL=sorted(list(set(tjdL)));
    for img in entrylist:
      if(force or datadict[img]['NIGHT'] is None):
        if(datadict[img]['MJD'] is not None):
          datadict[img]['NIGHT']=1+tjdL.index(int(datadict[img]['MJD']-nit));
  else:
    tjd0=min(tjdL);
    for img in entrylist:
      if(force or datadict[img]['NIGHT'] is None):
        if(datadict[img]['MJD'] is not None):
          datadict[img]['NIGHT']=1+int(datadict[img]['MJD']-nit)-tjd0;


###################################################
##GENERIC PROGRAM
def regfromcat(cat=None, nhdr=0, datapos=0, size1=0, size2=None, units=0, color=0, shape=0, output=None, addtext=None):
  """Generate a region file for SAOds9 from a catalog.

Parameters
----------
    cat : str
        Filename of the catalog
    nhdr : int
        number of lines of the initial header (to skip).
    datapos : 
        X
    size1 : float
        X
    size2 : float
        X
    units : int, str
        The unit to use. It can be an integer or a string: 0,'fk5'  [arcsec]; 1,'image'  [pxl].
    color : int, str
        The color of the regions. It can be an integer or a string: 0,'black'; 1,'white'; 2,'red'; 3,'green'; 4,'blue'; 5,'cyan'; 6,'magenta'; 7,'yellow'.
    shape : int, str
        The shape of the regions. It can be an integer or a string:  0,'circle'; 1,'box'; 2,'elipse'; -1,'text'.
    output : str
        Filename of the output region file.
    addtext : 
        a tuple with an additional text to be included to a geometric region. First element must be a string or the number of the column with the value.

Returns
-------
    x
  datapos:    it can be the number of the column with fisrt coordinate or a list/tuple with the number of the columns of first coordinates,
              of the two data to be used to calculate the dimensions of the region (if the second of these two is not given,
              it is assumed as the following column).
  size1,size2:    the size value can be provided as a single value of the size or as a list/tuple (-size0, a, data0) with 3 values
                  to calculate the size with size=size0+a(data0-data);
                  ellipse wants 2 values and box can have 1 or 2. 
""";
  _name_='regfromcat';
  if(not isinstance(cat,str) or not os.path.exists(cat)): raise IOError("regfromcat: no input file "+str(cat));
#Datapos
  if(isinstance(datapos, int)): datapos=(datapos-1, -1, -1);
  elif(isinstance(datapos, list) or isinstance(datapos, tuple)):
    if(len(datapos)==1): datapos=(datapos[0]-1, -1, -1);
    elif(len(datapos)==2): datapos=(datapos[0]-1, datapos[1]-1, datapos[1]);
    elif(len(datapos)==3): datapos=(datapos[0]-1, datapos[1]-1, datapos[2]-1);
    else: raise ValueError("regfromcat: Wrong value for datapos {:}".format(str(datapos)));
  else: raise TypeError("regfromcat: Wrong value for datapos {:}".format(str(datapos)));
#Size
  if(isinstance(size1, int)): size1=(size1, 0, 0);
  elif(isinstance(size1, list) or isinstance(size1, tuple)):
    if(len(size1)==1): size1=(size1[0], 0, 1);
    elif(len(size1)==2): size1=(size1[0], size1[1], size1[1]+1);
    elif(len(size1)!=3): raise ValueError("regfromcat: Wrong value for size1 {:}".format(str(size1)));
  else: raise TypeError("regfromcat: Wrong value for size1 {:}".format(str(size1)));
  if(size2 is None): size2=size1;
  else:
    if(isinstance(size2, int)): size2=(size2, 0, 0);
    elif(isinstance(size2, list) or isinstance(size2, tuple)):
      if(len(size2)==1): size2=(size2[0], 0, 1);
      elif(len(size2)==2): size2=(size2[0], size2[1], size2[1]+1);
      elif(len(size2)!=3): raise ValueError("regfromcat: Wrong value for size2 {:}".format(str(size2)));
    else: raise TypeError("regfromcat: Wrong type for size2 {:}".format(str(size2)));
#Unit
  systL=["fk5", "image", 'physical']; unitL=['"','', ''];
  if(isinstance(units, str)):
    units=units.lower();
    if('pxl' in units or 'pix' in units): units=1;
    elif(units in systL): units=systL.find(units);
  elif(units<0 or units>=len(systL)): raise ValueError("regfromcat: Wrong value for unit flag! {:}".format(str(units)));
#Shape
  shapeL=["circle", "box", "ellipse", "text"];
  if(isinstance(shape, str)):
    shape=shape.lower();
    if(shape in shapeL):
      shape=-1 if(shape=='text') else shapeL.index(shape);
    else: raise ValueError("regfromcat: Wrong value for shape flag! {:}".format(str(shape)));
  elif(isinstance(shape, int) and shape<-1 or shape>=len(systL)): raise ValueError("regfromcat: Wrong value for shape flag! {:}".format(str(shape)));
  if(shape==-1 and datapos[1]<0): raise ValueError("regfromcat: Wrong value for shape flag or missing a datapos value! (shape flag: {:} ; datapos: {:} )".format(str(shape), str(datapos))); 
#Color
  colorL=["black","white","red","green","blue","cyan","magenta","yellow"];
  if(isinstance(color, str)):
    color=color.lower();
    if(color not in colorL): raise ValueError("regfromcat: Wrong value for color flag! {:}".format(str(color)));
  elif(isinstance(color, int)):
    if(color<0 or color>=len(colorL)): raise ValueError("regfromcat: Wrong value for color flag! {:}".format(str(color)));
    else: color=colorL[color];
#AdditionaText
  if(shape==-1): addtext=None;
  if(addtext is not None):
    if( not isinstance(addtext, tuple)): raise TypeError("regfromcat: addtext must be None or a tuple of 2 elements (text, font size)");
    if((not isinstance(addtext[1], int) or addtext[1]<1) or (not isinstance(addtext[0], str) and not isinstance(addtext[0], int)) or addtext[1]<=0 ): raise ValueError("regfromcat: addtext must be None or a tuple of 2 elements (text, font size)");
  if(not output): output=cat+'.reg';

  with open(output, 'w') as f_out,  open(cat) as f_in:
    fsize=addtext[1] if(addtext) else size1[0];
    f_out.write("""# Region file format: DS9 version 4.0
global color={:} font="helvetica {:d} normal roman" select=1 highlite=1 dash=0 fixed=0 edit=1 move=0 delete=1 include=1 source=1
{:}
""".format(color, int(fsize), systL[units]));
    ii=0;
    for ii in range(nhdr):
      line=f_in.readline();
    if(ii+1<nhdr): raise SkZpipeError("Error! Not enough lines!", exclocus='regfromcat');
    for line in f_in:
      if(len(line)<5 or line[0]=='#'): continue;
      tmpl=line.strip().split();
      x=float(tmpl[datapos[0]]);  y=float(tmpl[datapos[0]+1]);
      if(shape>=0):
        data=(float(tmpl[datapos[1]]) if(datapos[1]>=0)else 0, float(tmpl[datapos[2]]) if(datapos[2]>=0)else 0);
        dim=[size1[0]+size1[1]*(size1[2]-data[0]), size2[0]+size2[1]*(size2[2]-data[1])];
        text= " text={{{:}}}".format(tmpl[addtext[0]-1]) if(addtext) else '';
        if(shape==0): f_out.write("circle({:.6f},{:.6f}, {:.3f}{:}) #tag={{{:}}}{:}\n".format(x, y, dim[0], unitL[units], output, text));
        else: f_out.write("{:}({:.6f},{:.6f}, {:.3f}{:},{:.3f}{:}) #tag={{{:}}}{:}\n".format( shapeL[shape], x, y, dim[0], unitL[units], dim[1], unitL[units], output, text));
      elif(0<=datapos[1]<len(tmpl)):
        f_out.write("# text({:.6f},{:.6f}) text={{{:}}}\n".format( x, y, tmpl[datapos[1]]));


################################
def idmod(fname=None, id0=0, skiprows=0, outfile=None):
  """Reenumerate the id in a file

Parameters
----------
    fname : str
        Name of input file
    id0 : int
        Zero-point for the ID (first ID is 'id0'+1). It must be non-negative.
    skiprows : int
        Number of initial rows to skip
    outfile : str
        Name of the output file. Default value is 'fname'+"_M"
    fname : 
        X

Returns
-------
""";
  _name_='';
  if(not isinstance(fname,str)): raise TypeError("idmod: fname must be a string.");
  check_file(fname, minline=skiprows);
  if(not isinstance(id0,int) or id0<0): raise TypeError("idmod: id0 must be a non-negative integer.");
  if(not isinstance(skiprows,int)): raise TypeError("idmod: skiprows must be an integer.");
  if(outfile is None): outfile=fname+'_M';
  with open(fname) as fin, open(outfile, 'w') as fout:
    for ii in range(skiprows):
      fout.write(fin.readline());
    for line in fin:
      idn=line.split(None,1)[0];
      lenfld=line.find(idn)+len(idn);
      frmt="{{:{:d}d}}".format(lenfld);
      id0+=1;
      fout.write(frmt.format(id0)+line[lenfld:])

#######################
def tableselect(infile=None, rules=None, outfile=None):
  """Select entries of a table according to values of the clumns
  rules= dictionary with the selection rules.
         The key  gives the number of the column, while the value gives the range. It is possible to provide also a string
         with simple arithmetic operation to be performed (e.g. '1+2', '5-2')
         A tuple will provides minimum and maximum values. A list will provide central position and maximum distance from it.
         the number of initial lines to skip can be given with the key 0, or 'header', or 'skip'. If the number is negative,
         the lines will not be included in the output file.
""";
  """

Parameters
----------
    x : 
        X

Returns
-------
    x
""";
  _name_='';
  _name_='tableselect';
  oper='*+-/#';
  oppatt='['+oper+']';
  check_file(infile);
  if(outfile is None): outfile=infile+"-S"; 
  if(not isinstance(rules, dict)): raise TypeError(_name_+": rules must be a dictionary");
  nhdr=0;rls={}; rlop={};
  for key in rules:
    if(key in [0, 'hedaer', 'skip']):
      if(not isinstance(rules[key], int)): raise TypeError(_name_+": rule for initial lines to skip must be an integer");
      if(nhdr): raise ValueError(_name_+": double rule");
      nhdr=rules[key];
    elif(isinstance(key, int) and key>0):
      if(not isinstance(rules[key], tuple) and not isinstance(rules[key], list)): raise TypeError(_name_+": selection rules must be a tuple or a list");
      rls[key]=rules[key] if(isinstance(rules[key], tuple)) else (rules[key][0]-rules[key][1], rules[key][0]+rules[key][1]);
    elif(isinstance(key, str) and len(re.findall(oppatt, key))==1):
      if(not isinstance(rules[key], tuple) and not isinstance(rules[key], list)): raise TypeError(_name_+": selection rules must be a tuple or a list");
      tmpl=re.split(oppatt, key);
      if(len(tmpl)!=2 or not isinteger(tmpl[0]) or not isinteger(tmpl[1])): raise ValueError(_name_+": wrong value for key in rules [{:}]".format(key));
      tmpl=[int(x) for x in tmpl];
      tmpl.insert(1,re.search(oppatt, key).group());
      tmpl=tuple(tmpl);
      rlop[key]=[tmpl,rules[key]] if(isinstance(rules[key], tuple)) else [tmpl,(rules[key][0]-rules[key][1], rules[key][0]+rules[key][1])];
    else:
      raise ValueError(_name_+": wrong value for key in rules.");
#  print(rls);
#  print(rlop);
  with open(infile) as fin, open(outfile, 'w') as fout:
    for ii in range(abs(nhdr)):
      line=fin.readline();
      if(nhdr>0): fout.write(line);
    nl=0;
    for line in fin:
      cols=line.split();
      cols.insert(0,0);
      for key in rls:
        if(not rls[key][0]<=float(cols[key])<=rls[key][1]):
          line='';
          break;
      for rule in rlop.values():
        if  (rule[0][1]=='+'): val=float(cols[rule[0][0]]) + float(cols[rule[0][2]]);  
        elif(rule[0][1]=='-'): val=float(cols[rule[0][0]]) - float(cols[rule[0][2]]);  
        elif(rule[0][1]=='*'): val=float(cols[rule[0][0]]) * float(cols[rule[0][2]]);  
        elif(rule[0][1]=='/'): val=float(cols[rule[0][0]]) / float(cols[rule[0][2]]);  
        elif(rule[0][1]=='#'): val=math.sqrt(float(cols[rule[0][0]])**2 + float(cols[rule[0][2]])**2);  
        if(not rule[1][0]<=val<=rule[1][1]):
            line='';
            break;
      if(line):
        fout.write(line);
        nl+=1;
  return nl;
      
#########################
def purgefile(infile=None, nhdr=0, text=None, outfile=None):
  """

Parameters
----------
    x : 
        X

Returns
-------
    x
""";
  _name_='';
  """Purge a file from lines with a specified text.
  nhdr= the number of initial lines to skip. If the number is negative, the lines will not be included in the output file.
""";
  _name_='purgefile';
  check_file(infile);
  if(outfile is None): outfile=infile+"-P"; 
  if(not isinstance(nhdr, int)): raise TypeError(_name_+": nhdr must be a integer.");
  if(not text): raise ValueError(_name_+": text is not defined or empty.");
  with open(infile) as fin, open(outfile, 'w') as fout:
    for ii in range(abs(nhdr)):
      line=fin.readline();
      if(nhdr>0): fout.write(line);
    nl, nr=0,0;
    for line in fin:
      if(text not in line):
        fout.write(line);
        nl+=1;
      else:
        nr+=1;
    return (nl, nr);

############
def sortbyfilter(iterable=None, filtermap=None):
  """Sort the input iterable according wavelength of the matched filter

Parameters
----------
    iterable : iterable
        Iterable with the object to sort
    filtermap : list, dict
        Dictionary or list that provide for each object the filter (by key for dictionry, by position for list).
        If not provide, `iterable` will be used (as list).

Returns
-------
    output : list
        List with the sorted objects
""";
  _name_='sortbyfilter';
  if(not isinstance(filtermap, dict)):
    iterable=list(iterable);
    if(not filtermap): filtermap=iterable.copy();
    filtermap=dict(zip(iterable, filtermap));
  if(isinstance(filtermap, dict)):
    return sorted(iterable, key=(lambda x : _db.SkZp_DB['passbands'][None].index(filtermap[x]) ));
  else: raise TypeError(_name_+": `filtermap` must be a list/tuple or a dictionary <{}>".format(repr(filtermap)));


###################################################
# INPUTDATA MANAGEMENT #
###################################################

############
def ReadGRH(instr=None, fileGRH=None):
  """

Parameters
----------
    instr : str, None
        Name of the instrument
    fileGRH : str
        Name of the file with gain, ron and maximum good datum value information.

Returns
-------
    x
""";
  _name_='ReadGRH';
  """Read for each line chip name, gain[e-/ADU], ron[e-], High Good Datum.
HGD can be a list of 'tag:value'.""";
  if(fileGRH is None): fileGRH=_opt.SkZp_Opt['S']['inputdata:gainronhighfile'];
  if(isinstance(fileGRH,str) and not os.path.exists(fileGRH)): raise IOError("ReadGRH: No input file "+fileGRH);
  if(instr is None):
    try:
      with open(fileGRH) as f_grh:
        print("Reading {:} ...".format(fileGRH), file=bpar.SkZp_Par['stdout']);
        nl=0;
        for line in f_grh:
          line=line.strip()
          if(len(line)<3 or line[0]=='#'):
            continue;
          tmpl=line.split()
          if(len(tmpl)<4): continue
          _opt.SkZp_Opt['D']['photo:gain'][tmpl[0]]=float(tmpl[1]);
          _opt.SkZp_Opt['D']['photo:ron'][tmpl[0]]=float(tmpl[2]);
          for hgd in tmpl[3:]:
            if(":" in hgd):
              tmpll=hgd.split(':')
              _opt.SkZp_Opt['D']['photo:high'][tmpl[0]+":"+tmpll[0]]=float(tmpll[1]);
            else:
              _opt.SkZp_Opt['D']['photo:high'][tmpl[0]]=float(hgd);
          nl+=1;
    except OSError:
      raise OSError("problems opening/reading "+fileGRH);
  elif(instr in _db.SkZp_DB['gainronhigh']):
    pass;
  else:
    raise SkZpipeError("No data for instrument "+instr);
    
  return nl;


def InputDataTagValueList(tag=None, entrylist=None, datadict=None, datatag=None):
  """Retrieve the list of values of the given tag among the entries in `entrylist` from dictioary database `datadict` if present in tag list `datatag`.

Parameters
----------
    tag : str
        Name of the tag
    entrylist : None, list, str
        List of input data entries. None for SkZp_Par['inputlist']
    datadict : None, dict
        Dictionary of input data (dictionary of dictionaries). None for SkZp_Par['inputdata']
    datatag : None, list
        List of the tags in input data. None for SkZp_Par['datatag']
Returns
-------
    output : list
        List of the values or None if tag is not in datatag.
""";
  _name_='InputDataTagValueList';
  if(not isinstance(tag, str)): raise TypeError(_name_+": 'tag' must be a str. <{}>".format(tag));
  if(entrylist is None): entrylist=bpar.SkZp_Par['inputlist'];
  if(isinstance(entrylist, str)):
    if(entrylist is 'inputlist'): entrylist=bpar.SkZp_Par['inputlist'];
    elif(entrylist is 'runlist'): entrylist=bpar.SkZp_Par['runlist'];
    else: raise TypeError(_name_+": `entrylist` must be a list, None or a valid parameter name. <{}>".format(entrylist));
  if(not isinstance(entrylist, (list,tuple))): raise TypeError(_name_+": 'entrylist' must be a list or a tuple. <{}>".format(entrylist));
  if(datatag is None): datatag=bpar.SkZp_Par['datatag'];
  if(not isinstance(datatag, (list,tuple))): raise TypeError(_name_+": 'datatag' must be a list or a tuple. <{}>".format(datatag));
  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
  if(not isinstance(datadict, dict)): raise TypeError(_name_+": 'datadict' must be a dict. <{}>".format(datadict.__class__));

  if(tag in datatag):
    return [datadict[fn][tag] for fn in entrylist];
  return None;

def InputDataTagValueSet(tag=None, entrylist=None, datadict=None, datatag=None):
  """Retrieve the set of values of the given tag among the entries in `entrylist` from dictioary database `datadict` if present in tag list `datatag`.

Parameters
----------
    tag : str
        Name of the tag
    entrylist : None, list
        List of input data entries. None for SkZp_Par['inputlist']
    datadict : None, dict
        Dictionary of input data (dictionary of dictionaries). None for SkZp_Par['inputdata']
    datatag : None, list
        List of the tags in input data. None for SkZp_Par['datatag']
Returns
-------
    output : set
        Set of the values or None if tag is not in datatag.
""";
  _name_='InputDataTagValueSet';
  ret=InputDataTagValueList(tag=tag, entrylist=entrylist, datadict=datadict, datatag=datatag);
  if(ret is None): return; 
  return set(ret);
  

###############################
##   Get Data From DataBase  ##
###############################
def GetFromDB_SkZp_Opt(instr=None, verb=True):
  """Import SkZp_Opt from internal database.

Parameters
----------
    instr : str
        Name of the instrument
    verb : bool
        Verbosity flag

Returns
-------
    0 on success, -1 if fails
""";
  _name_='DatabaseRetrieve for SkZp_Opt';
  if(not instr):
    if(_opt.SkZp_Opt['S']['instrument']): instr=_opt.SkZp_Opt['S']['instrument'];
  if(not instr or not isinstance(instr,str)): print(_name_+": instr [{:}] is not the name of an instrument stored in the internal dataBase".format(instr),  file=bpar.SkZp_Par['stderr']);

  if( instr in _db.SkZp_DB['SkZp_Opt']):
    if(verb):  print("Updating options for instrument {instr} with internal database.".format(instr=instr), file=bpar.SkZp_Par['stdout']);
    _opt.OptionCheckInput(options=_db.SkZp_DB['SkZp_Opt'][instr]);
    _opt.OptionSet(optdict= _db.SkZp_DB['SkZp_Opt'][instr]);
    return 0;
  return -1;
    

###
def GetFromDB_Par(pardict=None, instr=None, verb=True):  #NOT USE!!!
  """Import data from internal database of specific *_Par values.

Parameters
----------
    pardict : dict
        Dictionary with parameters to update
    instr : str
        Name of the instrument
    verb : bool
        Verbosity flag

Returns
-------
    output : bool
""";
  _name_='DatabaseRetrieve';
  exctxt=' for Par';
  if(not pardict or not isinstance(pardict, dict) or '_name_' not in pardict): raise TypeError(_name_+exctxt+": pardict must be a valid dictionary with the parameters to be updated");
  if(not instr):
    if(_opt.SkZp_Opt['S']['instrument']): instr=_opt.SkZp_Opt['S']['instrument'];
  if(not instr or not isinstance(instr,str)): raise TypeError("{name}{txt}: instr [{instr}] must be the name of an instrument stored in the internal dataBase".format(name=_name_, txt=exctxt, instr=instr));
  name=pardict['_name_'];

  if(":" in name):
    nameL=name.split(":");
    if(nameL[0] in _db.SkZp_DB and instr in _db.SkZp_DB[nameL[0]]):
      for tag in _db.SkZp_DB[nameL[0]][instr]:
        pardict[tag][nameL[1]]=_db.SkZp_DB[nameL[0]][instr][tag];      
  elif(name in _db.SkZp_DB and instr in _db.SkZp_DB[name]):
    for tag in _db.SkZp_DB[name][instr]:
      pardict[tag]=_db.SkZp_DB[name][instr][tag];
    return True;
  return False;
    


###
def GetFromDB_GRH(datadict=None, instr=None, verb=True):
  """Update data dictionary with data from internal database of Gain, RON, High good datum.

Parameters
----------
    datadict : dict
        Dictionary with data to update
    instr : str
        Name of the instrument
    verb : bool
        Verbosity flag

Returns
-------
    status : int
        0 if no error. -1 if there are no data
""";
  _name_='DatabaseRetrieve for gain, ron and high good datum';
  if(_opt.SkZp_Opt['Flg']['debug'] or _opt.SkZp_Opt['Flg']['verbose']): verb=True;
  exctxt=' for gain,ron,high';
  if(not isinstance(datadict, dict)): raise TypeError("DatabaseRetrieve{:}: datadict must be a dictionary.".format(exctxt));
  if('CHIP' not in datadict): raise SkZpipeError("The data dictionary doesn't have 'CHIP' key", exclocus=_name_);

  if(not instr):
    if(_opt.SkZp_Opt['S']['instrument']): instr=_opt.SkZp_Opt['S']['instrument'];
    elif('INSTRUMENT' in datadict): instr=datadict['INSTRUMENT'];
  if(not instr or not isinstance(instr,str)): raise TypeError("DatabaseRetrieve{:}: instr [{:}] must be the name of an instrument stored in the internal dataBase".format(exctxt, instr));

  if(instr not in _db.SkZp_DB['gainronhigh']):
#    if(verb): print("DatabaseRetrieve{:}: there are no data for instr [{:}] in the internal dataBase".format(' gain, ron and high good datum', instr), file=bpar.SkZp_Par['stdout']);   FIX THIS: It cannot print it for every image!
    return -1;
  if(verb and bpar.SkZp_Par['counter']['db_retr']==0):
    print(_name_+": reading data for instrument {instr} in the internal database".format(instr=instr), file=bpar.SkZp_Par['stdout']);
  bpar.SkZp_Par['counter']['db_retr']+=1;

  grhD={};
  if('GAIN' in _db.SkZp_DB['gainronhigh'][instr]):
    grhD['GAIN']=_db.SkZp_DB['gainronhigh'][ instr ]['GAIN'][ datadict['CHIP'] ];
  if('RON' in _db.SkZp_DB['gainronhigh'][instr]):
    grhD['RON']= _db.SkZp_DB['gainronhigh'][ instr ]['RON'][ datadict['CHIP'] ];
  if('HIGH' in _db.SkZp_DB['gainronhigh'][instr]):
    grhD['HIGH']=_db.SkZp_DB['gainronhigh'][ instr ]['HIGH'][ datadict['CHIP'] ];

 #Instrument fixing
  if(instr == 'VIRCAM:VVV'):
    grhD['GAIN']=round( float(grhD['GAIN'])*float(datadict['GAINCOR']), 6);
    if(grhD['GAIN']<=0): raise ValueError(_name_+": VVV gain returned zero or negative! <{gain}>".format(gain=grhD['GAIN']));
    grhD['HIGH']=round( _db.VVV_HGD(datadict), 2);
    if(grhD['HIGH']<=0): raise ValueError(_name_+": VVV high good value returned zero or negative! <{high>".format(high=grhD['HIGH']));
  elif(instr == 'GSAOI'):
    grhD['RON']=grhD['RON'][ datadict['FOWLER'] ];

 #Fixing and updating
  datadict['RON']=round(float(datadict['RON']) if(datadict['RON']) else grhD['RON'] , 6);

  if(datadict['GAIN']):
    datadict['GAIN']=round(float(datadict['GAIN']),6);
    datadict['HIGH']=round(grhD['HIGH']*grhD['GAIN']/datadict['GAIN'],2);
  else:
    datadict['GAIN']=round(grhD['GAIN'],6);
    datadict['HIGH']=round(grhD['HIGH'],2);
    
  return 0;


###
def DatabaseRetrieve(instr=None, entrylist=None, datadict=None, readmode=True, verb=True):
# 
#
  """Import data from internal database.

Parameters
----------
    instr : str, None
        Name of the instrument used to produce the data
    entrylist : None, list
        List of input data entries. None for SkZp_Par['inputlist']
    datadict : None, dict
        Dictionary of input data (dictionary of dictionaries). None for SkZp_Par['inputdata']
    readmode : bool
        Flag
    verb : bool
        Verbosity flag

Returns
-------
    x
""";
  _name_='DatabaseRetrieve';
  exctxt='';
  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
  if(entrylist is None): entrylist=bpar.SkZp_Par['inputlist'];
  if(isinstance(entrylist, str)):
    if(entrylist is 'inputlist'): entrylist=bpar.SkZp_Par['inputlist'];
    elif(entrylist is 'runlist'): entrylist=bpar.SkZp_Par['runlist'];
    else: raise TypeError(_name_+": `entrylist` must be a list, None or a valid parameter name.");
  if(not isinstance(datadict,  dict)): raise TypeError(_name_+": 'datadict' must be a dict.");
  if(not isinstance(entrylist, list)): raise TypeError(_name_+": 'entrylist' must be a list.");
  if(not instr and _opt.SkZp_Opt['S']['instrument']): instr=_opt.SkZp_Opt['S']['instrument'];
  instrS=InputDataTagValueSet(tag='INSTRUMENT');
  if(not instr and instrS is not None):
    if(len(instrS)==1): instr=tuple(instrS)[0];
  GetFromDB_SkZp_Opt(instr, verb=verb);
# #Skip if parameter flag says so
  if(readmode):
   #if instrument is not given as input, but its parameter is set, use that value
  #  if(not isinstance(instr,str)): raise TypeError("DatabaseRetrieve{:}: instr [{:}] must be the name of an instrument stored in the internal dataBase".format(exctxt, instr));
  #  GetFromDB_DAO_Par(p, instr);
    if(verb):  print("Updating input data with gain,ron and high good datum from internal database", file=bpar.SkZp_Par['stdout']);
    for ii,img in enumerate(entrylist):
      instr0=instr;
      if(instr0 and (not 'INSTRUMENT' in datadict[img] or not datadict[img]['INSTRUMENT'])): datadict[img]['INSTRUMENT']=instr0;
      if(not instr0 and 'INSTRUMENT' in datadict[img]):  instr0=datadict[img]['INSTRUMENT'];
     # input instr and header value are set, but different
      if(instr0 and 'INSTRUMENT' in datadict[img] and instr0!=datadict[img]['INSTRUMENT']):
        if(datadict[img]['INSTRUMENT'] not in instr0):
          print(_name_+': for image {img} the given instrument [{instr0}] is different from the one in the input data [{instr}].'.format(img=img, instr0=instr0, instr=datadict[img]['INSTRUMENT']), file=bpar.SkZp_Par['stderr']);
      if(not instr0 and (not 'INSTRUMENT' in datadict[img] or not datadict[img]['INSTRUMENT'])): raise SkZpipeError(_name_+': No instrument name is given.', exclocus=img);

      GetFromDB_GRH(datadict[img], instr0, verb=verb and ii==0);

    
      if(instr == 'VIRCAM:VVV'):
        chp=int(datadict[img]['CHIP']);
        off=int(datadict[img]['OFFSET']);
        datadict[img]['POSNAME']="{:};{:d}".format(int(chp)+0.3*(.5+abs(off-3.5)), off>>2);

##################################
##   Get Data From Fits Header  ##
##################################
def FitsHeaderInfoRetrieve(image=None, headertype=None, instr=None, headerext=None, extraheaderkey=None, extradatatag=None):
  """Retrieve data from Fits header of the given image. It returns a tuple with (dictionary with info from headers, list of additional datatag)

Parameters
----------
    image : str
        Full name (with extension) or basename (but the extension has to be the one in SkZp_Opt['S']['fitsextension']) of the image for which retrieve data from headers
    headertype : str,list
        The type of header ('chip', 'mos/mosaic') from which to retrieve the info
    instr : str
        Instrument for the image
    headerext : dict
        Dictionary giving the extension for each header type.
    extraheaderkey :  dict, None
        Dictionary that map the extra tags to their correspondig header card (key=tag; value=header card or how to get the value)
    extradatatag : list, None
        List of extra tag to be added in the desired orden. If it is not given, it is generated automatically.

Returns
-------
    A 2-element tuple: dictionary with info from headers; list of additional datatag.

Functions
---------
    FitsHeaderInfoRead
""";
  _name_='FitsHeaderInfoRetrieve';
  
  if(not isinstance(image, str)): raise TypeError(_name_+": 'image' must be a string");
  if(not os.path.exists(image)): 
    if(os.path.exists(image+_opt.SkZp_Opt['S']['fitsextension'])): image+=_opt.SkZp_Opt['S']['fitsextension'];
    else: raise IOError(_name_+": {img}({ext}) image does not exist!".format(img=image, ext=_opt.SkZp_Opt['S']['fitsextension']));

 #if instr is not given, use the one in options
  if(not instr): instr=_opt.SkZp_Opt['S']['instrument'];
  if(headerext is None): headerext={'chip':_opt.SkZp_Opt['S']['chipheaderext'], 'mos':_opt.SkZp_Opt['S']['mosheaderext']};

  with fits.pyfits.open(image) as fitso:
    nhdu=len(fitso);
  img=re.sub('\.fits?$', '', image);
  if(not headertype):
    if(nhdu==1):
      headertype= ['mos', 'chip'] if(os.path.exists(img+headerext['mos'])) else ['chip'];
    else:
      headertype= ['mos'];
#      headertype= ['mos', 'chip'];
  else:    
    headertype=[headertype] if(not isinstance(headertype, (tuple,list))) else list(headertype); 
    if(not all(tp in ('mos','mosaic','chip') for tp in headertype )): raise SkZpipeError("Wrong header type", exclocus=_name_);
    if('mosaic' in headertype): headertype[headertype.index('mosaic')]='mos'; 
    if(len(headertype)>=2):
      if('chip' not in headertype or len(headertype)>2): raise SkZpipeError("Wrong headertype list", exclocus=_name_)
      headertype=['mos', 'chip']; 
  if(headerext is None):  headerext={'chip':_opt.SkZp_Opt['S']['chipheaderext'], 'mos':_opt.SkZp_Opt['S']['mosheaderext']};
  if(not extraheaderkey): extraheaderkey=_opt.SkZp_Opt['D']['inputdata:extraheaderkey'].copy();
  if(not extradatatag): extradatatag=_opt.SkZp_Opt['L']['inputdata:extradatatag'].copy();
  if(not isinstance(extraheaderkey, dict) or not isinstance(extradatatag, list)): raise TypeError(_name_+": Wrong type for extraheaderkey (dict/None) or extradatatag (list/None)");
 
  for tag in extraheaderkey:
    if(tag not in extradatatag): extradatatag.append(tag);
  if(len(extradatatag)<len(extraheaderkey)): raise SkZpipeError(_name_+': something wrong with extraheaderkey and extradatatag.');

  hdrinfo, headerkeyD, hdrdata, datatag = {}, {}, {'HDRSRC':''}, [];
 #Read from database the headerkey definitions
  if('chip' in headertype):
    headerkeyD.update(**_db.SkZp_DB['headerkey'][None]['mos'], **_db.SkZp_DB['headerkey'][None]['chip']); #merging the 2 dict (python>=3.5)
  else:
    headerkeyD.update(**_db.SkZp_DB['headerkey'][None]['mos']); #merging the 2 dict (python>=3.5)
  
 #Read headers as spicified) and store cards => you need to know the INSTRUMENT
  if(len(headertype)==1):
    tmpd=FitsHeaderInfoRead(img+headerext[headertype[0]] if(os.path.exists(img+headerext[headertype[0]])) else image)[0];    #Which default? from image o extracted txt?
    if(tmpd):
      hdrinfo.update(tmpd);
      hdrdata['HDRSRC']=headertype[0];
  else:
    if(nhdu>1):
      if(headertype=='mos'):
        pass;
      else: raise SkZpipeWarning('Retrieving for chip from multi-HDU FITS not yet implemnted', exclocus=_name_);
    else:
      tmpd=FitsHeaderInfoRead(img+headerext['mos'])[0];
      if(tmpd):
        hdrinfo.update(tmpd);
        hdrdata['HDRSRC']='mos';
      flush_out();
      tmpd=FitsHeaderInfoRead(img+headerext['chip'] if(os.path.exists(img+headerext['chip'])) else image)[0];
      if(tmpd):
        hdrinfo.update(tmpd);
        hdrdata['HDRSRC']+='chip';

 #Set instr=INSTRUMENT if not given (headerkeyD contain the default values for _db.SkZp_DB['headerkey'])
  if(not instr and headerkeyD['INSTRUMENT'] in hdrinfo):  instr = hdrinfo[headerkeyD['INSTRUMENT']];


 ##Update headerkey list
 #from DB for that instrument
  if(instr in _db.SkZp_DB['headerkey']):
    for hdu in headertype:
      if(hdu in _db.SkZp_DB['headerkey'][instr]):
        headerkeyD.update(_db.SkZp_DB['headerkey'][ instr ][hdu]);
    datatag=_db.SkZp_DB['headerkey'][ instr ]['datatag'].copy();
 #from options
  for tag in headerkeyD:
    if(tag not in datatag): datatag.append(tag);
  if(len(datatag)<len(headerkeyD)): raise SkZpipeError(_name_+': something wrong with extraheaderkey and extradatatag.');
  if(extraheaderkey): headerkeyD.update(extraheaderkey);
  if(extradatatag):      datatag.extend(extradatatag);
  datatag+=['HDRSRC'];


# ##%%%%%##
#  def _RDH_get(tag=None, cardL=None):
#    """FitsHeaderInfoRetrieve internal command: convert the value of the tag to the right type (float or str) according to SkZp_Par['datatagtype']
#  Parameters
#  ----------
#      tag : str, None
#          Name of the tag
#      cardL : list
#          List with values to convert
#  Return
#  ------
#      List of coverted card values
#  """;
#    _name_='_RDH_get';
#    tmpv=[];
#    for card in cardL:
#      if(tag in bpar.SkZp_Par['datatagtype']['S']):
#        tmpv.append(str(card));
#      elif(tag in bpar.SkZp_Par['datatagtype']['N']):
#        try:
#          tmpv.append(float(card));
#        except:
#          tmpv.append(None);
#      elif(tag in bpar.SkZp_Par['datatagtype']['NL']):
#        try:
#          tmpv.append(float(card));
#        except:
#          tmpv,append(None);
#      else:
#        tmpv.append( card );
#    return tmpv;
 ##%%%%%##
  
 #START 
 #Retrieve selected info
  for tag in headerkeyD:
    hdrdata[tag]=_db.headerkeyread(tag, headerkeyD[tag], hdrinfo);

#    if(callable(headerkeyD[tag])): headerkeyD[tag]={'eval':headerkeyD[tag]};
#    if(isinstance(headerkeyD[tag], str)): headerkeyD[tag]={'cards':[headerkeyD[tag]]};
#    if(isinstance(headerkeyD[tag].get('cards'), str)): headerkeyD[tag]={'cards':[headerkeyD[tag]['cards']]};
#    if(not isinstance(headerkeyD[tag], dict)): raise TypeError(_name_+": the definition of tag '{tag}' is wrong.".format(tag=tag));
#    
#    hdrdata[tag]=None; #Initialization
#    cardL=[hdrinfo[fkey] for fkey in headerkeyD[tag]['cards'] if fkey in hdrinfo] if('cards' in headerkeyD[tag]) else [];
#    
#    if('rej' in headerkeyD[tag]):
#      cardL=[val for val in cardL if val not in headerkeyD[tag]['rej']]
#        
#    if(not cardL):
#      if('eval' in headerkeyD[tag]):  hdrdata[tag]=headerkeyD[tag]['eval'](hdrinfo);
#      if('def' in headerkeyD[tag] and hdrdata[tag] is None):   hdrdata[tag]=headerkeyD[tag]['def'];
#      continue;
#    cardL=_RDH_get(tag, cardL);
#    if('join' in headerkeyD[tag]): hdrdata[tag]=headerkeyD[tag]['join'].join([str(val) for val in cardL])
#    elif('eval' in headerkeyD[tag]):
#      if(headerkeyD[tag]['eval']=='mean'):      hdrdata[tag]=numpy.mean([float(x) for x in cardL]);
#      elif(callable(headerkeyD[tag]['eval'])):  hdrdata[tag]=headerkeyD[tag]['eval'](hdrinfo);
#      if('round' in headerkeyD[tag]):
#        hdrdata[tag]=  round(hdrdata[tag], headerkeyD[tag]['round']);
#    elif(len(cardL)==1):  hdrdata[tag]=cardL[0];
#    
#    if('def' in headerkeyD[tag] and  hdrdata[tag] is None):   hdrdata[tag]=headerkeyD[tag]['def'];
#
#    if(isinstance(hdrdata[tag], str)):
#      hdrdata[tag]=hdrdata[tag].strip();
#      if(hdrdata[tag]==''): hdrdata[tag]=None;

  #Check that listed tag has a entry in hdrdata
  for tag in datatag:
    hdrdata.setdefault(tag);

  return (hdrdata, datatag);


def MosaicHeaderInfoRetrieve(mosaic=None, instr=None, extraheaderkey=None, extradatatag=None):
  """Retrieve data from headers of the given mosaic. It returns a tuple with (dictionary with info from headers, list of additional datatag)

Parameters
----------
    mosaic : str
        Full name (with extension) or basename (but the extension has to be the one in SkZp_Opt['S']['fitsextension']) of the mosaic for which retrieve data from headers
    instr : str
        Instrument for the mosaic
    extraheaderkey :  dict, None
        Dictionary that map the extra tags to their correspondig header card (key=tag; value=header card or how to get the value)
    extradatatag : list, None
        List of extra tag to be added in the desired orden. If it is not given, it is generated automatically.

Returns
-------
    A 2-element tuple: dictionary with info from headers; list of additional datatag.

Functions
---------
    FitsHeaderInfoRead
    parameters.database.headerkeyread
""";
  _name_='MosaicHeaderInfoRetrieve';
  
  if(not isinstance(mosaic, str)): raise TypeError(_name_+": `mosaic` must be a string");
  if(not os.path.exists(mosaic)): raise IOError(_name_+": {img} mosaic does not exist!".format(img=mosaic));

  if(not instr): instr=_opt.OptionGet('instrument');

 #if instr is not given, use the one in options
  if(not extraheaderkey): extraheaderkey=_opt.SkZp_Opt['D']['inputdata:extraheaderkey'].copy();
  if(not extradatatag): extradatatag=_opt.SkZp_Opt['L']['inputdata:extradatatag'].copy();
  if(not isinstance(extraheaderkey, dict) or not isinstance(extradatatag, list)): raise TypeError(_name_+": Wrong type for extraheaderkey (dict/None) or extradatatag (list/None)");
 
  for tag in extraheaderkey:
    if(tag not in extradatatag): extradatatag.append(tag);
  if(len(extradatatag)<len(extraheaderkey)): raise SkZpipeError(_name_+': something wrong with extraheaderkey and extradatatag.');

 ##
  hdrinfo, hdrdata, datatag = {}, {}, [];
  headerkeyD = {'mos':{}, 'chip':{}};
 #Read from database the headerkey definitions
  headerkeyD['mos'].update(**_db.SkZp_DB['headerkey'][None]['mos']);
  headerkeyD['chip'].update( **_db.SkZp_DB['headerkey'][None]['chip']); #merging the 2 dict (python>=3.5)
  
 #Read headers as spicified) and store cards => you need to know the INSTRUMENT
  hdrinfo=FitsHeaderInfoRead(header=mosaic, index=-1);

 #Set instr=INSTRUMENT if not given (headerkeyD contain the default values for _db.SkZp_DB['headerkey'])
  if(not instr and headerkeyD['mos']['INSTRUMENT'] in hdrinfo[0]):  instr = hdrinfo[0][headerkeyD['mos']['INSTRUMENT']];

 ##Update headerkey list
 #from DB for that instrument
  if(instr in _db.SkZp_DB['headerkey']):
    for hdu in ('mos','chip'):
      if(hdu in _db.SkZp_DB['headerkey'][instr]):
        headerkeyD[hdu].update(_db.SkZp_DB['headerkey'][ instr ][hdu]);
    datatag=_db.SkZp_DB['headerkey'][ instr ]['datatag'].copy();
 #from options
  for tag in list(headerkeyD['mos'])+list(headerkeyD['chip']):
    if(tag not in datatag): datatag.append(tag);
  if(len(datatag)<len(headerkeyD)): raise SkZpipeError(_name_+': something wrong with extraheaderkey and extradatatag.');
  if(extraheaderkey): headerkeyD.update(extraheaderkey);
  if(extradatatag):      datatag.extend(extradatatag);
  
 #START 
 #Retrieve selected info
 #From HDU 0/mosaic header
  for tag in headerkeyD['mos']:
    hdrdata[tag]=_db.headerkeyread(tag, headerkeyD['mos'][tag], hdrinfo[0]);
 #From chip headers
  for tag in headerkeyD['chip']:
    tagvL=[]
    for header in hdrinfo[1:]:
      tagvL.append(_db.headerkeyread(tag, headerkeyD['chip'][tag], {**hdrinfo[0], **header}));
    if(not all( type(tagvL[0])==type(x) for x in tagvL) ): raise ValueError(_name_+": in mosaic {mosaic} return values for tag '{tag}' has different type for different chip! <{val}>".format(mosaic=mosaic, tag=tag, val=tagvL));
    if( all( tagvL[0]==x for x in tagvL) ): hdrdata[tag]=tagvL[0];
    elif(isinstance(tagvL[0],(float,int))):
      tmparr=numpy.array(tagvL);
      hdrdata[tag]=(tmparr.mean(), tmparr.std(), numpy.median(tmparr));
    else:  hdrdata[tag]=tagvL;
    

  #Check that listed tag has a entry in hdrdata
  for tag in datatag:
    hdrdata.setdefault(tag);

  return (hdrdata, datatag);

  ###@_______________________+---------------

###
def InputDataFromFitsHeader(entrylist=None, instr=None, listof='image', chipheaderext=None, mosheaderext=None, datadict=None, datatag=None, override=None):
  """Extract data from Fits Header.

Parameters
----------
    entrylist : None, list
        List of input data entries. None for SkZp_Par['inputlist']
    instr : str, None
        Instrument name
    listof : str
        If the inputdata contains information about images: 'image'
        If the inputdata contains list of mosaic names: 'mosaic'
    chipheaderext : str, None
        Extension of the extracted header of the chip
    mosheaderext : str, None
        Extension of the extracted header of the mosaic
    datadict : None, dict
        Dictionary of input data (dictionary of dictionaries). None for SkZp_Par['inputdata']
    datatag : None, list
        List of the tags in input data. None for SkZp_Par['datatag']
    override : bool, None
        Flag to determine if the data from FITS header have to override the existing data.

Returns
-------
    Tuple: number of extracted header from  chip, number of extracted header from mosaic

Functions
---------
    FitsHeaderInfoRetrieve
""";
  _name_='InputDataFromFitsHeader';
  if(not isinstance(listof,str)): raise TypeError(_name_+": `listof` must be a string ('image' or 'mosaic') <{}>".format(listof));
  if(not any( x in listof for x in ('image', 'mosaic'))): raise ValueError(_name_+": Wrong value for `listof` <{}>".format(listfor));
  if(chipheaderext is None): chipheaderext=_opt.SkZp_Opt['S']['chipheaderext'];
  if( mosheaderext is None):  mosheaderext=_opt.SkZp_Opt['S']['mosheaderext'];
  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
  if(entrylist is None): entrylist=bpar.SkZp_Par['inputlist'];
  if(isinstance(entrylist, str)):
    if(entrylist is 'inputlist'): entrylist=bpar.SkZp_Par['inputlist'];
    elif(entrylist is 'runlist'): entrylist=bpar.SkZp_Par['runlist'];
    else: raise TypeError(_name_+": `entrylist` must be a list, None or a valid parameter name.");
  if(datatag is None): datatag=bpar.SkZp_Par['datatag'];
  if(not isinstance(datadict,  dict)): raise TypeError(_name_+": 'datadict' must be a dict.");
  if(not isinstance(entrylist, list)): raise TypeError(_name_+": 'entrylist' must be a list.");
  if(not isinstance(datatag,   list)): raise TypeError(_name_+": 'datatag' must be a list.");
  if( override is None): override=_opt.SkZp_Opt['Flg']['inputdata:headeroverride'];

  print("Updating input data with extracted fits headers", file=bpar.SkZp_Par['stdout']);
  if(not instr): instr=_opt.SkZp_Opt['S']['instrument'];
  headerext={'chip':chipheaderext, 'mos':mosheaderext};
  nhdr={'chip':0, 'mos':0};
  datatag_old=datatag.copy();
  datatag_db=_db.SkZp_DB['headerkey'][None]['datatag'].copy()

#  nproc= _opt.SkZp_Opt['I']['mp:nproc'] if(_opt.SkZp_Opt['I']['mp:nproc']) else len(os.sched_getaffinity(0));
  nproc= len(os.sched_getaffinity(0));
 
#  with bclasses.MProc(nproc=nproc, narg=len(entrylist), method='pool', minproc=-1) as mpobj: 
#    retval=mpobj.pool.map(func=FitsHeaderInfoRetrieve, iterable=entrylist.copy());
#    retval=dict(zip(entrylist, retval)); #Now a dict img:(hdrdata, hdrdatatag)
#      
#  for img in entrylist:
#    datatag_db.extend([tag for tag in retval[img][1] if tag not in datatag_db])
#   #Aimed Update if new value is not None
#    DictdataUpdate(olddict=datadict[img], newdict=retval[img][0], override=override);
#    
#    for tp in nhdr:
#      if( tp in retval[img][0]['HDRSRC']): nhdr[tp]+=1;
#  retval.clear();

  for img in entrylist:
    hdrdata, hdrdatatag = FitsHeaderInfoRetrieve(image=img+'.fits', headertype=None, instr=instr, headerext=headerext);
    datatag_db.extend([tag for tag in hdrdatatag if tag not in datatag_db])
   #Aimed Update if new value is not None
    DictdataUpdate(olddict=datadict[img], newdict=hdrdata, override=override);
    
    for tp in nhdr:
      if( tp in hdrdata['HDRSRC']): nhdr[tp]+=1;

    if(_opt.SkZp_Opt['Flg']['instrumentset'] and instr):   datadict[img]['INSTRUMENT']=instr;
    
  ## Here set the merge among datatag from header and input file (the later are appended)
  datatag_db.extend([tag for tag in datatag_old if tag not in datatag_db]);
  datatag[:]=datatag_db;
  ##

  if('HDRSRC' in datatag):
    datatag.remove('HDRSRC');
  datatag.append('HDRSRC');

  return (nhdr['chip'], nhdr['mos']);


#############################################################
#############################################################

########################
# InputData Management #
########################
def InputDataUpdate(newdata=None, entries=None, taglist=None,   datadict=None, datatag=None, raisexc=True):
  """Update input data in `datadict` (default SkZp_Par['inputdata']) using additional data through `newdata`. It permits to add new tags, but does not add new entries. Entries present in `datadict` but not in `newdata` will have the values for the new tags set to None. To update specific tags, use InputDataTagUpdate.

Parameters
----------
    newdata : dict
        Dictionary with additional data to be included. 
    entries : None, list
        List with the entries to modify. Default None  for all.
    taglist : list of str
        Ordered list of the tag in `newdata`. If not provided, it will be retrieved from the dictionary
    datadict : None, dict
        Dictionary of inputdata (dictionary of dictionaries). None for SkZp_Par['inputdata']
    datatag : None, list
        Ordered list of the tags of each entry in datadict. None for SkZp_Par['datatag']

Returns
-------
    return : tuple 
    Number of updated entries, set of tags in common between `newdata` and `datadict`.
""";
  _name_='InputDataUpdate'; 

  if(not isinstance(newdata,  dict)): raise TypeError(_name_+": `newdata` must be a dict.");
  if(entries is not None and not isinstance(entries, list)): raise TypeError(_name_+": `entries` must be a list or None.");
  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
  if(datatag is None): datatag=bpar.SkZp_Par['datatag'];
  if(not isinstance(datadict,  dict)): raise TypeError(_name_+": `datadict` must be a dict.");
  if(not isinstance(datatag,   list)): raise TypeError(_name_+": `datatag` must be a list.");

  newlist=list(newdata.keys());
  tagset0=set(newdata[newlist[0]]);
  if('NAME' in tagset0): 
    if(newdata[newlist[0]]['NAME']!=newlist[0]): raise SkZpipeError(message="entry {it} in `newdata` has 'NAME' value different from its name <{name}>".format(it=newlist[0], name=newdata[newlist[0]]['NAME']), exclocus=_name_);
  for item in newlist[1:]:
    tagset=set(newdata[item]);
    if(tagset!=tagset0): raise SkZpipeError(message="`newdata` has entries with different set of tags <{ts} != {ts0}>".format(ts=tagset, ts0=tagset0), exclocus=_name_);
    if('NAME' in tagset): 
      if(newdata[item]['NAME']!=item): raise SkZpipeError(message="entry {it} in `newdata` has 'NAME' value different from its name <{name}>".format(it=item, name=newdata[item]['NAME']), exclocus=_name_);
  if(taglist is None): taglist=list(tagset0);

  newtag=tagset0-set(datatag);
  comtag=tagset0-newtag;
  updt=0;
  for img in datadict:
    if(img in newdata):
      datadict[img].update(newdata[img]);
      updt+=1;
    else:
      datadict[img].update(dict().fromkeys(newtag))
  datatag.extend(list(newtag));
    
  return updt, comtag;



########################
def InputDataSelect(select=None, atleastone=True, excludeNone=True, runlist=None,   datadict=None, entrylist=None, datatag=None, verb=True):
  """Select entries in input data `datadict`/`entrylist` to include in `runlist`  (default global parameter 'runlist').

Parameters
----------
    select : str, dict, list of str
        Selection options. 
        If a dict, the items can be:
          'suffix' : list of str
               List  of suffix of filename (entry name+suffix) that have to exist.
          'tag' : dict
               Dictionary where the keys are the names of the tags to use, while the values can be:
                 allowed value or list of allowed values (a compare == will be used);
                 callable that accepts the tag value as input and returning a bool.
          'mode' : str, list of str
              '.XYZ'       : if it is a str starting with a dot, it is meant as suffix (={'suffix':['.XYZ']}).
              'psfcal'     : rejecting entries that have not ENTRYTYPE='image:sci' and have not image (= 'suffix':[ SkZp_Opt['S']['fitsextension']] ).
              'stack'      : rejecting entries that have not ENTRYTYPE='image:sci' and have not files to create a stack image (= 'suffix':[ SkZp_Opt['S']['photo:psf:done'], '.als', '.psf', SkZp_Opt['S']['fitsextension'] ] ).
              'psfdone'    : same as 'stack'
              'srclst'     : rejecting entries that have not ENTRYTYPE='stack' and have not files to create a source list (= 'suffix':[ SkZp_Opt['S']['photo:psf:done'], '.psf', SkZp_Opt['S']['fitsextension'] ] ).
              'framephoto' : rejecting entries that have not ENTRYTYPE='stack' and have not a source list (= 'suffix':[ SkZp_Opt['S']['photo:psf:done'], '.als' ] ).
              'catalog'    : rejecting entries that have not ENTRYTYPE='image:sci' and have not files to create a catalog from '.alf'.
              'ctlg'       : as 'catalog'
              'exist'      : rejecting entries that have not fits.
              'standard'   : add option 'image:standard' to 'tag' key
        If a string, it indicate a 'mode' (see above). If list, a list of 'mode'.
    atleastone : tuple, list, str
        Flag to determine for which criteria is valid the 'at least one' rule:
          'tag'  :  selected if at least one of the tags has the right value (otherwise all the tags have to be satisfied).
          'suff' :  selected if at least one of the suffix is of an existing file (otherwise all the suffixes have to be satisfied).
    excludeNone : bool
        Flag to determine if a value of None for a tag is always reason to be rejected or not.
    runlist : None, list
        List where to store the list of the selected entries (output). None for global parameter 'runlist'.
        It will be cleared at the beginning.
    datadict : None, dict
        Dictionary of inputdata (dictionary of dictionaries). None for global parameter 'inputdata'.
    entrylist : None, list, str
        Ordered list of the entries to choose from. None for parameter 'inputlist'. Or the name of the parameter: 'runlist' for global parameter 'runlist', 'inputlist' for global parameter 'inputlist'.
    datatag : None, list
        List of the tags of input data. None for SkZp_Par['datatag']
    verb : bool
        Verbosity flag

Returns
-------
    x : int
        Number of selected entries
""";
  _name_='InputDataSelect'; 
  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
  if(entrylist is None): entrylist=bpar.SkZp_Par['inputlist'];
  if(isinstance(entrylist, str)):
    if(entrylist is 'inputlist'): entrylist=bpar.SkZp_Par['inputlist'];
    elif(entrylist is 'runlist'): entrylist=bpar.SkZp_Par['runlist'];
    else: raise TypeError(_name_+": `entrylist` must be a list, None or a valid parameter name.");
  if(runlist is None): runlist=bpar.SkZp_Par['runlist'];
  if(datatag is None): datatag=bpar.SkZp_Par['datatag'];
  if(not isinstance(datadict,  dict)): raise TypeError(_name_+": 'datadict' must be a dict.");
  if(not isinstance(entrylist, list)): raise TypeError(_name_+": 'entrylist' must be a list, None or a valid descriptor.");
  if(not isinstance(runlist, list)): raise TypeError(_name_+": 'runlist' must be a list.");
  if(not isinstance(datatag,   list)): raise TypeError(_name_+": 'datatag' must be a list.");

  selectD={'suffix':_opt.OptionGet('image:select:bysuffix'), 'tag':_opt.OptionGet('image:select:bytag'), 'mode':_opt.OptionGet('image:select:bymode')};
  if(not select and all( not selectD[x] for x in selectD)):
    runlist[:]=entrylist.copy();
    return len(runlist);
  if(isinstance(select,str)): select=[select];
  if(isinstance(select,list)): select={'mode':select};
  

  if(isinstance(select,dict)):
    if('mode' in select):
      if(not isinstance(select['mode'],list)): select['mode']=[select['mode']];
      for mode in select['mode']:
   ##TOO MUCH DAOPHOT DEPENDENT!!! MUST BE MORE GENERAL!!
        if(mode in ('psfcal')):
          selectD['tag'].update({'ENTRYTYPE':['image:sci']});
        elif(mode in ('stack', 'psfdone')):
          selectD['suffix'].extend( [ _opt.SkZp_Opt['S']['fitsextension'], _opt.SkZp_Opt['S']['photo:psf:done'], _opt.SkZp_Opt['S'  ]['stack:match:srcext'], '.psf' ] );   ##!!!! BIAS
          selectD['tag'].update({'ENTRYTYPE':['image:sci']});
        elif(mode in ('srclst')):
          selectD['suffix'].extend( [ _opt.SkZp_Opt['S']['fitsextension'], _opt.SkZp_Opt['S']['photo:psf:done'] ] );
          selectD['tag'].update({'ENTRYTYPE':['stack']});
        elif(mode in ('framephoto')):
          selectD['suffix'].extend( [ _opt.SkZp_Opt['S']['match:extension'], _opt.SkZp_Opt['S']['photo:ext:srclst'] ] );  
          selectD['tag'].update({'ENTRYTYPE':['stack']});
        elif(mode in ('ctlg', 'catalog')):
          selectD['suffix'].extend(['.alf']);   ##!!!! BIAS
          selectD['tag'].update({'ENTRYTYPE':['image:sci']});
        elif(mode in ('exist')):
          selectD['suffix'].extend([_opt.SkZp_Opt['S']['fitsextension']]);
        elif(mode in ('standard')):
          if(selectD['tag']):
            for tag,lval in _opt.OptionGet('image:standard').items():
              if(tag in selectD['tag']):
                selectD['tag'][tag]=list( set(select['tag'][tag] ) | set(lval) );
              else: selectD['tag'][tag]=lval;
          else: selectD['tag']=_opt.OptionGet('image:standard');
        elif(mode[0]=='.'):
          selectD['suffix'].append(select);
        else: raise ValueError(_name_+": `select` contain an invalid value <{}>".format(mode));
    if('suffix' in select):
      if(not isinstance(select['suffix'],list)): select['suffix']=[ select['suffix'] ];
      selectD['suffix'].extend(select['suffix']);
    if('tag' in select):
      if(not isinstance(select['tag'],  dict)): raise TypeError(_name_+": `select['tag']` must be a dict.");
      for tgg in select['tag']:
        if(not isinstance(select['tag'][tgg], list)): select['tag'][tgg]=[ select['tag'][tgg] ];
        selectD['tag'].setdefault(tgg.upper(), []);    #TAG NAME must be upper case!
        selectD['tag'][tgg.upper()].extend(select['tag'][tgg]);

  for tgg in selectD['tag']:
    if(tgg not in datatag): raise KeyError(_name_+": `select` contains tag <{tag}> that are not in input data (not in `datatag`)".format(tag=tgg));

 #Selecting
  runlist0=[];
  for img in entrylist: #Cycle over entries
    if(img not in datadict): raise KeyError(_name_+": entry {:} is not present in the input data.".format(img));
    
    skipflg=False;
    if('tag' in selectD):   # and not skipflg):  Not necessary
      for tgg in selectD['tag']: #Cycle over requested tag
        keepflg=False;
        for val in selectD['tag'][tgg]:
          if(excludeNone and datadict[img][tgg] is None): break; #default is to reject: keepflg=False
          check= val(datadict[img][tgg]) if(callable(val)) else (datadict[img][tgg].__class__(val)==datadict[img][tgg]);
          if(check):
            keepflg=True;
            break;
        if(not keepflg):
          if(verb): print("Skipping ", datadict[img]['NAME'], "[tag= {tag} : {val} ]".format(tag=tgg, val=datadict[img][tgg]), file=bpar.SkZp_Par['stdout']);
          skipflg=True;
          break;
    if(not skipflg and 'suffix' in selectD):
      for suf in selectD['suffix']:
        if(not os.path.exists(datadict[img]['NAME']+suf)):
          if(verb): print("Skipping ", datadict[img]['NAME'], "[missing {suff}]".format(suff=suf), file=bpar.SkZp_Par['stdout']);
          skipflg=True;
          break;
    if(not skipflg): runlist0.append(img);
  #
  runlist[:]=runlist0;
  return len(runlist);


########################
def InputDataTagUpdate(tags=None, entrylist=None, datadict=None, datatag=None):
  """Add or update tags for each given entry.

Parameters
----------
    tags : dict
        Dictionary with:
          key :  str
            the name of the new tag
          value : callable or str or number
            a callable that takes as input the input-data of an entry and return the value for the new tag; or a fix value (str or number).
    entrylist : None, list
        List of the entrylist to which add the new tags. None for all entrylist in SkZp_Par['inputlist']
    datadict : None, dict
        Dictionary of inputdata (dictionary of dictionaries). None for SkZp_Par['inputdata']
    datatag : None, list
        List of the tags of data. None for SkZp_Par['datatag']
""";
  _name_='InputDataTagUpdate';
  if(not isinstance(tags, dict)): raise TypeError(_name_+": 'tags' must be a dict");
  if(entrylist is None): entrylist=bpar.SkZp_Par['inputlist'];
  if(isinstance(entrylist, str)):
    if(entrylist is 'inputlist'): entrylist=bpar.SkZp_Par['inputlist'];
    elif(entrylist is 'runlist'): entrylist=bpar.SkZp_Par['runlist'];
    else: raise TypeError(_name_+": `entrylist` must be a list, None or a valid parameter name.");
  if(not isinstance(entrylist, list) and not isinstance(entrylist, tuple)): raise TypeError(_name_+": 'entrylist' must be a list or a tuple");
  if(datatag is None): datatag=bpar.SkZp_Par['datatag'];
  if(not isinstance(datatag, (list,tuple))): raise TypeError(_name_+": 'datatag' must be a list or a tuple.");
  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
  if(not isinstance(datadict, dict)): raise TypeError(_name_+": 'datadict' must be a dict.");

  for tg in tags:
    if(not isinstance(tg, str)): raise TypeError(_name_+": keys in 'tags' must be a string [{:}]".format(str(tags)));
    if(not callable(tags[tg]) and not isinstance(tags[tg], (str,int,float))): raise TypeError(_name_+": values in 'tags' must be a callable or a fix value (str or a number)");
   
  for tg in tags:
    for img in entrylist:
      datadict[img][tg]=tags[tg](datadict[img]) if(callable(tags[tg])) else tags[tg];
      
    if(tg not in datatag): datatag.append(tg);
  
  return;

########################
def InputDataImageStatAdd(statkey=None, ndigits=2, singletag=None, override=False, entrylist=None, datadict=None, datatag=None):
  """Add to input data image statistic information. It ca be adding/setting tags for each given entry, or a sigle one as a string with ;-separated values. The tag names will be in uppercase

Parameters
----------
    statkey : list of str
        List of the image statistics to add as single tags. Options are: 'mean', 'med', 'min', 'max', 'std'
    ndigits : int, list of int
        Precision in decimal digits (default 1 digit). One value for each key, or a global one.
    singletag : str
        The name of the single tag, if only a single tag is added/set.
    override : bool
        To change the value of an existing tag, even if its value is not None.
    entrylist : None, list
        List of the entrylist to which add the new tags. None for all entrylist in SkZp_Par['inputlist']
    datadict : None, dict
        Dictionary of inputdata (dictionary of dictionaries). None for SkZp_Par['inputdata']
    datatag : None, list
        List of the tags of data. None for SkZp_Par['datatag']
""";
  _name_='InputDataImageStatAdd';
  from .parameters.classes  import bclasses
  if(statkey is None): return;
  if(not isinstance(statkey, list)): raise TypeError(_name_+": 'statkey' must be a list <{}>".format(statkey));
  if(not isinstance(ndigits, int)):
    if(isinstance(ndigits, list)):
      if(not all(isinstance(x,int) for x in ndigits)): raise TypeError(_name_+": `ndigits` must be an int or a list od int");
    else: raise TypeError(_name_+": `ndigits` must be an int or a list od int");

  if(entrylist is None): entrylist=bpar.SkZp_Par['inputlist'];
  if(isinstance(entrylist, str)):
    if(entrylist is 'inputlist'): entrylist=bpar.SkZp_Par['inputlist'];
    elif(entrylist is 'runlist'): entrylist=bpar.SkZp_Par['runlist'];
    else: raise TypeError(_name_+": `entrylist` must be a list, None or a valid parameter name.");
  if(not isinstance(entrylist, list) and not isinstance(entrylist, tuple)): raise TypeError(_name_+": 'entrylist' must be a list or a tuple");
  if(datatag is None): datatag=bpar.SkZp_Par['datatag'];
  if(not isinstance(datatag, (list,tuple))): raise TypeError(_name_+": 'datatag' must be a list or a tuple.");
  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
  if(not isinstance(datadict, dict)): raise TypeError(_name_+": 'datadict' must be a dict.");
  if(isinstance(singletag, str)): singletag=singletag.upper();
  if(not isinstance(override, bool)): raise  TypeError(_name_+": `override` must be a bool");

  if(isinstance(ndigits, int)): ndigits=[ndigits]*len(statkey);
  elif(isinstance(ndigits, list)):
    if(len(ndigits)<len(statkey)): ndigits.extend( [ ndigits[-1]*(len(statkey)-len(ndigits)) ] );

  if(override): imglist=entrylist;
  else:
    imglist=[];
    for img in entrylist:
      if(singletag):
        if(datadict[img].get(singletag) is None): imglist.append(img);
      else:
        if(any( datadict[img].get(stk.upper()) is None for stk in statkey)): imglist.append(img);
        
  if(not imglist): return;
  nproc= len(os.sched_getaffinity(0));
  with bclasses.MProc(nproc=nproc, narg=len(imglist), method='pool', minproc=-1) as mpobj: 
    retval=mpobj.pool.map(func=fits.statimage, iterable=imglist.copy());
    retval=dict(zip(imglist, retval)); #Now a dict img:stat
  stkey=set(retval[imglist[0]].keys());
  err=set(statkey)-stkey;
  if(err): raise SkZpipeError(message="Some of the statistic keys doen't exist <{}>".format(err), exclocus=_name_);
  

  for img in imglist:
    vaL=[];
    for stk,nd in zip(statkey,ndigits):
      tag=stk.upper();
      stt=stk.lower();
      if(singletag): vaL.append(round(retval[img][stk], nd));
      else:
        if(override or (datadict[img].get(tag) is None)): datadict[img][tag] =round(retval[img][stk], nd);
    if(singletag and (override or (datadict[img].get(singletag) is None))): datadict[img][singletag]=";".join( [str(val) for val in vaL] );

  if(singletag): 
    if(singletag not in datatag): datatag.append(singletag);
  else: 
    for stk in statkey:
      tag=stk.upper();
      if(tag not in datatag): datatag.append(tag);
    
    

########################
def InputDataTagRemove(tag=None, entrylist=None, datadict=None, datatag=None):
  """Remove tags from a given inputdata dictionary.

Parameters
----------
    tag : 
        Iterable with the names of the tags.
    entrylist : None, list
        list of the entries to which add the tags. None for all entrylist in SkZp_Par['inputlist']
    datadict : None, dict
        Dictionary of inputdata (dictionary of dictionaries). None for SkZp_Par['inputdata']
    datatag : None, list
        List of the tags of input data. None for SkZp_Par['datatag']

Returns
-------
    List of removed tags.
""";
  _name_='InputDataTagRemove';
  if(entrylist is None): entrylist=bpar.SkZp_Par['inputlist'];
  if(isinstance(entrylist, str)):
    if(entrylist is 'inputlist'): entrylist=bpar.SkZp_Par['inputlist'];
    elif(entrylist is 'runlist'): entrylist=bpar.SkZp_Par['runlist'];
    else: raise TypeError(_name_+": `entrylist` must be a list, None or a valid parameter name.");
  if(not isinstance(entrylist, list) and not isinstance(entrylist, tuple)): raise TypeError(_name_+": `entrylist` must be a list or a tuple");
  if(not isinstance(tag, (list,tuple))): raise TypeError(_name_+": `tag` must be a dict");
  if(datatag is None): datatag=bpar.SkZp_Par['datatag'];
  if(not isinstance(datatag, (list,tuple))): raise TypeError(_name_+": 'datatag' must be a list or a tuple.");
  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
  if(not isinstance(datadict, dict)): raise TypeError(_name_+": 'datadict' must be a dict.");

  remL=[];
  for tg in tag:
    if(not isinstance(tg, str)): raise TypeError(_name_+": keys in `tag` must be a string [{:}]".format(str(tag)));
    if(tg not in datatag): continue;
    for img in entrylist:
      del datadict[img][tg];
    remL.append(tg);
    datatag.remove(tg)
  return remL;
  

###################
def InputDataEntryAdd(new=None, old=None, tags=None, entrytype=None, datadict=None, entrylist=None, datatag=None):
  """Add the entry 'new' in datadict (default SkZp_Par['inputdata']) and entrylist (default SkZp_Par['inputlist']) using eventually data from existing 'old' entry.

Parameters
----------
    new : str
        Name of the new entry
    old : str
        Existing entry of SkZp_Par['inputdata'] to be used as default values.
    tags : list, None
        List of tags to be copied in the new entry from the old one. None (default) means all; empty list means that all the filed will be set to None.
    entrytype : str
        Value for 'ENTRYTYPE' tag. None (default) to not change it.
    datadict : None, dict
        Dictionary of inputdata (dictionary of dictionaries). None for SkZp_Par['inputdata']
    entrylist : None, list
        list of the entries. None for SkZp_Par['inputlist']
    datatag : None, list
        List of the tags of input data. None for SkZp_Par['datatag']
Returns
-------
    Integer, None
        None if the entry is added without problems; if the entry already exists, its index in 'entrylist' is return.
""";
  _name_='InputDataEntryAdd';
  if(datadict is None and not all(xx is None for xx in (datadict, entrylist, datatag))): raise SkZpipeError("Error in given values: if `datadict` is None also entrylist and datatag must be None!", exclocus=_name_);
  if(datadict is None):  datadict =bpar.SkZp_Par['inputdata'];
  if(entrylist is None): entrylist=bpar.SkZp_Par['inputlist'];
  if(isinstance(entrylist, str)):
    if(entrylist is 'inputlist'): entrylist=bpar.SkZp_Par['inputlist'];
    elif(entrylist is 'runlist'): entrylist=bpar.SkZp_Par['runlist'];
    else: raise TypeError(_name_+": `entrylist` must be a list, None or a valid parameter name.");
  if(datatag is None):   datatag  =bpar.SkZp_Par['datatag'];
  if(not isinstance(new, str)): raise TypeError(_name_+": `new` {:} must be a str".format(str(new)));
  if(not isinstance(datadict,  dict)): raise TypeError(_name_+": `datadict` must be a dict.");
  if(not isinstance(entrylist, list)): raise TypeError(_name_+": `entrylist` must be a list.");
  if(not isinstance(datatag,   list)): raise TypeError(_name_+": `datatag` must be a list.");
  if(old is not None and old not in datadict): raise KeyError(_name_+": `old` entry {:} does not exist!".format(old));
  if(tags is not None and not isinstance(tags, list)): raise TypeError(_name_+": `tags` must be a list. <{}>".format(tags));
  if(entrytype is not None and not isinstance(entrytype, str)): raise TypeError(_name_+": `entrytype` must be a str or None <{}>".format(entrytype));

  
  ret=entrylist.index(new) if(new in entrylist) else None;

  if(old):
    if(tags is None):
      tmpd=copy.deepcopy(datadict[old]) 
    else:
      tmpd=dict().fromkeys(datatag);
      try:
        tmpd.update(dict((tag, datadict[old][tag]) for tag in tags));
      except:
        raise KeyError(_name_+": Wrong value for a tag to be copied! Tag {tag} doesn't exist!".format(tag=tag));
  else:
    tmpd=dict().fromkeys(datatag);
  datadict[new]=tmpd;
  datadict[new]['NAME']=new;
  if(new not in entrylist): entrylist.append(new);
  if(entrytype): datadict[new]['ENTRYTYPE']=entrytype;
  return ret;

###################
def InputDataEntryGet(entry=None, taglist=None, datadict=None, raisexc=False):
  """Get the data of an entry from the database in 'datadict' (default SkZp_Par['inputdata']). if `taglist` is provided, only the data of the tags in it will be returned.

Parameters
----------
    entry : str
        Name of the entry whose data has to be retrieved
    taglist : list
        Secuence of tags to extract. Default None for all
    datadict : None, dict
        Dictionary of inputdata (dictionary of dictionaries). None for SkZp_Par['inputdata']
    raisexc : bool
        Flag to set if raise an exception or just return an error value.

Returns
-------
    output : dict
        Dictionary with data of the entry
""";
  _name_='InputDataEntryUpdate';
  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
  if(not isinstance(entry, str)): raise TypeError(_name_+": 'entry' {:} must be a string".format(entry));
  if(not isinstance(datadict,  dict)): raise TypeError(_name_+": 'datadict' must be a dict.");
  if(entry not in datadict):
    if(raisexc):
      raise KeyError(_name_+": 'entry' {:} does not exist!".format(entry));
    else:
      print(_name_+": 'entry' {:} does not exist!".format(entry), file=bpar.SkZp_Par['stderr']);

  if(taglist):
    data=datadict.get(entry);
    if(data):
      return dict((tag, data.get(tag)) for tag in taglist);
    return data;
  else:
    return datadict.get(entry);

###################
def InputDataEntryUpdate(entry=None, newdata=None, datadict=None):
  """Update an entry of the database in 'datadict' (default SkZp_Par['inputdata']) with new data.

Parameters
----------
    entry : str
        Name of the entry to update
    newdata : dict
        Dictionary with the new data.
    datadict : None, dict
        Dictionary of inputdata (dictionary of dictionaries). None for SkZp_Par['inputdata']
""";
  _name_='InputDataEntryUpdate';
  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
  if(not isinstance(entry, str)): raise TypeError(_name_+": 'entry' {:} must be a string".format(entry));
  if(not isinstance(newdata, dict)): raise TypeError(_name_+": 'newdata' must be a dictionary");
  if(not isinstance(datadict,  dict)): raise TypeError(_name_+": 'datadict' must be a dict.");
  if(entry not in datadict): raise KeyError(_name_+": 'entry' {:} does not exist!".format(entry));
  if(any(tag not in datadict[entry] for tag in newdata)): raise SkZpipeError("A tag in 'newdata' is not present in the database! ({})".format(newdata), exclocus=_name_);
  if('NAME' in newdata and newdata['NAME']!=datadict[entry]['NAME']): raise SkZpipeError("It's not possible to change the value of NAME' tag! You have to create a new entry! ({})".format(newdata), exclocus=_name_);

  datadict[entry].update(newdata);

###################
def InputDataEntryDelete(name=None, datadict=None, entrylist=None):
  """Delete the entry 'name' from datadict (default SkZp_Par['inputdata']) and entrylist (default SkZp_Par['inputlist']);

Parameters
----------
    name : str,list,tuple (iterable)
        Name of the entry
    datadict : None, dict
        Dictionary of inputdata (dictionary of dictionaries). None for SkZp_Par['inputdata']
    entrylist : None, list
        list of the entries. None for SkZp_Par['inputlist']
""";
  _name_='InputDataEntryDelete';
  if(entrylist is None): entrylist=bpar.SkZp_Par['inputlist'];
  if(isinstance(entrylist, str)):
    if(entrylist is 'inputlist'): entrylist=bpar.SkZp_Par['inputlist'];
    elif(entrylist is 'runlist'): entrylist=bpar.SkZp_Par['runlist'];
    else: raise TypeError(_name_+": `entrylist` must be a list, None or a valid parameter name.");
  if(not isinstance(entrylist, list)): raise TypeError(_name_+": 'entrylist' must be a list.");
  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
  if(not isinstance(datadict,  dict)): raise TypeError(_name_+": 'datadict' must be a dict.");
  if(isinstance(name,str)): name=[name];
  for img in name:
    if(img in entrylist):
      del(datadict[name]);
      entrylist.remove(name);


###################
def InputDataIntegrityCheck(datadict=None, entrylist=None, datatag=None, raisexc=True):
  """check the integrity of the internal database 'datadict' (default SkZp_Par['inputdata']), 'entrylist' (default SkZp_Par['inputlist']), datatag (default SkZp_Par['datatag'])

Parameters
----------
    datadict : None, dict
        Dictionary of inputdata (dictionary of dictionaries). None for SkZp_Par['inputdata']
    entrylist : None, list
        list of the entries. None for SkZp_Par['inputlist']
    datatag : None, list
        List of the tags of input data. None for SkZp_Par['datatag']
    raisexc : bool
        Flag to set if raise an exception or just return an error value.
Returns
-------
    Integer, str
        0 if there are no problems. 1 if 'datadict' has keys not present in 'entrylist'. 2 if 'entrylist' has entries not present in 'datadict'. 
        If a entry has a difference 
""";
  _name_='InputDataIntegrityCheck';
  if(datadict is None and not all(xx is None for xx in (datadict, entrylist, datatag))): raise SkZpipeError("Error in given values: if 'datadict' is None also entrylist and datatag must be None!", exclocus=_name_);
  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
  if(entrylist is None): entrylist=bpar.SkZp_Par['inputlist'];
  if(isinstance(entrylist, str)):
    if(entrylist is 'inputlist'): entrylist=bpar.SkZp_Par['inputlist'];
    elif(entrylist is 'runlist'): entrylist=bpar.SkZp_Par['runlist'];
    else: raise TypeError(_name_+": `entrylist` must be a list, None or a valid parameter name.");
  if(datatag is None): datatag=bpar.SkZp_Par['datatag'];
  if(not isinstance(datadict,  dict)): raise TypeError(_name_+": 'datadict' must be a dict.");
  if(not isinstance(entrylist, list)): raise TypeError(_name_+": 'entrylist' must be a list.");
  if(not isinstance(datatag,   list)): raise TypeError(_name_+": 'datatag' must be a list.");

  setkeys=set(datadict);
  setlist=set(entrylist);
  settags=set(datatag);

  diff=setkeys-setlist;
  if(diff):
    if(raisexc): raise SkZpipeError("'datadict' has keys not present in 'entrylist'! <{}>".format(diff), exclocus=_name_);
    else:
      print(_name_, "Error: 'datadict' has keys not present in 'entrylist'! <{}>".format(diff), file=bpar.SkZp_Par['stderr']);
      return 1;
  diff=setlist-setkeys;
  if(diff):
    if(raisexc): raise SkZpipeError("'entrylist' has entries not present in 'datadict'! <{}>".format(diff), exclocus=_name_);
    else:
      print(_name_, "'entrylist' has entries not present in 'datadict'! <{}>".format(diff), file=bpar.SkZp_Par['stderr']);
      return 2;
  for img in entrylist:
    settagI=set(datadict[img]);
    diff=settags-settagI;
    if(diff):
      if(raisexc): raise SkZpipeError("The entry {img} has less tags! <{diff}>".format(img=img, diff=diff), exclocus=_name_);
      else:
        print(_name_, "Error: The entry {img} has less tags! <{diff}>".format(img=img, diff=diff), file=bpar.SkZp_Par['stderr']);
        return img;
    diff=settagI-settags;
    if(diff):
      if(raisexc): raise SkZpipeError("The entry {img} has more tags! <{}>".format(img=img, diff=diff), exclocus=_name_);
      else:
        print(_name_, "Error: The entry {img} has more tags! <{diff}>".format(img=img, diff=diff), file=bpar.SkZp_Par['stderr']);
        return img;

  return 0;

###################
  
#####################
def InputDataCheckFix(runlist=None, entrylist=None, datadict=None, datatag=None):
  """Check InputData values and fix format and values (it sould be run at the end of the data retrievement).

Parameters
----------
    runlist : None, list
        list of the entries to process. None for SkZp_Par['runlist']
    entrylist : None, list
        List of input data entries. None for SkZp_Par['inputlist']
    datadict : None, dict
        Dictionary of input data (dictionary of dictionaries). None for SkZp_Par['inputdata']
    datatag : None, list
        List of the tags in input data. None for SkZp_Par['datatag']
""";
  _name_='InputDataCheckFix';
  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
  if(entrylist is None): entrylist=bpar.SkZp_Par['inputlist'];
  if(isinstance(entrylist, str)):
    if(entrylist is 'inputlist'): entrylist=bpar.SkZp_Par['inputlist'];
    elif(entrylist is 'runlist'): entrylist=bpar.SkZp_Par['runlist'];
    else: raise TypeError(_name_+": `entrylist` must be a list, None or a valid parameter name.");
  if(runlist is None): runlist=bpar.SkZp_Par['runlist'];
  if(datatag is None): datatag=bpar.SkZp_Par['datatag'];
  if(not isinstance(datadict,  dict)): raise TypeError(_name_+": 'datadict' must be a dict.");
  if(not isinstance(entrylist, list)): raise TypeError(_name_+": 'entrylist' must be a list.");
  if(not isinstance(runlist, list)): raise TypeError(_name_+": 'runlist' must be a list.");
  if(not isinstance(datatag,   list)): raise TypeError(_name_+": 'datatag' must be a list.");

  for fn in entrylist:
    if(_opt.SkZp_Opt['Flg']['inputdata:aliasingfix']):
      if(datadict[fn]['INSTRUMENT'] in _db.SkZp_DB['alias']):
        for key in _db.SkZp_DB['alias'][datadict[fn]['INSTRUMENT']]:
          if(datadict[fn][key] in _db.SkZp_DB['alias'][ datadict[fn]['INSTRUMENT'] ][key]):
            datadict[fn][key]= _db.SkZp_DB['alias'][ datadict[fn]['INSTRUMENT'] ][key][ datadict[fn][key] ];


    if(isinteger(datadict[fn].get('BITPIX'))):
      if(abs(datadict[fn]['BITPIX'])!= 32 and datadict[fn]['ENTRYTYPE']=='image:sci'):  print(fn+": The image is not float(32bit): BITPIX={bit:d}! There could be problems with DAOPhot!\n".format(bit=int(datadict[fn]['BITPIX'])), file=bpar.SkZp_Par['stdout']);
    else:  print(_name_+": The image {fn}  has not tag BITPIX defined correctly ({bpix})! Rerun after header-data retrievement! \n".format(fn=fn, bpix=datadict[fn].get('BITPIX')), file=bpar.SkZp_Par['stdout']);

    scl,off=(),();
    if(datadict[fn].get('SCALE')):
      tmpf=getfloat(datadict[fn]['SCALE'], datadict[fn]['SCALE']);
      if(isinstance(tmpf,float)):
        scl=(round(tmpf,7),round(tmpf,7));
        datadict[fn]['SCALE']=scl[0];
      elif(';' in tmpf):
        scl=tuple( round(float(x),7) for x in tmpf.split(';') );
        datadict[fn]['SCALE']=";".join(str(x) for x in scl);

    if(datadict[fn].get('OFFSET')):
      tmpf=getfloat(datadict[fn]['OFFSET'], datadict[fn]['OFFSET']);
      if(isinstance(tmpf,float)):
        off=( round(tmpf,7), round(tmpf,7) );
        datadict[fn]['OFFSET']=off[0];
      elif(';' in tmpf):
        off=tuple( round(float(x),7) for x in tmpf.split(';') );
        datadict[fn]['OFFSET']=";".join( str(x) for x in off);
    
    datadict[fn]['OFFSETXY']="{x:.6f};{y:.6f}".format(x=off[0]/scl[0], y=off[1]/scl[1]) if(scl and off) else None;
    #
  if('OFFSETXY' not in datatag): datatag.append('OFFSETXY');

  return;

#################################
##   Get Data From Input File  ##
#################################
def InputDataReadExternalSource(inputfile=None, header=None, comment=None, minlen=1):
  """Reads input file 'inputfile' and return the hedaer and the data.

Parameters
----------
    inputfile : str, None
        The input external source (file or standard input). If inputfile='-' or None (default) then it will read from standard input and/or using filenames passed through command line. Other strings will be used as a filename.
    header : none, str, int
        Describe the header of the input:
          int : number of initial lines to be considered as header
          str : initial pattern that identifies the header. Header consists of just all the first lines that starts with this pattern.
          None : use 'headerfilepattern' parameter.
    comment : str
        Initial pattern that identifies a comment-out line that have not to be read. If None, it uses 'commentpattern' parameter.
    minlen : int
        Minimum length of a valid space-stripped input line.
Returns
----------
    out : tuple of list
        Tuple with: list of header lines, list of data lines.
  """;
  _name_='InputDataReadExternalSource';
  if(inputfile is None): inputfile='-';
  if(not isinstance(inputfile,str)): raise TypeError(_name_+": 'inputfile' must be a string or None.");
  if(inputfile != '-'): check_file([inputfile]);
#HEADER
  if(comment is None): comment=bpar.SkZp_Par['commentpattern'];
  if(header is None): header=bpar.SkZp_Par['headerfilepattern'];
  if(not isinstance(header,(str,int))): raise TypeError(_name_+": 'header' must be a string, a no-negative integer.");
  if(isinstance(header,int) and header<0): raise TypeError(_name_+": 'header' must be a no-negative integer (or a string).");

  datalines=[];
  headerlines=[]
  with (fileinput.input() if(inputfile=='-') else open(inputfile)) as f_in:
#READING HEADER
    if(isinstance(header,int)):
      for ii in range(header):
        headerlines.append(f_in.readline().strip());
    else:
      line=f_in.readline().strip();
      while(re.search('^'+header, line)):
        headerlines.append(line);
        line=f_in.readline().strip();
     #next line is read: to check if a valid data line
      if(not line.startswith(comment)):
        if(len(line)>=minlen):
          datalines.append(line);

#READING DATA
    for line in f_in:
      line=line.strip();
      if(re.search('^'+comment, line)): continue;
      if(len(line)<minlen): continue;
      datalines.append(line);

  return (headerlines, datalines);

########
def InputDataFileAnalyze(inputdata=None, header=None, comment=None, minlen=1):
  """Analyze the input file to try to understand for what the input file is for. It considers just first and second field of each line to see if the input file is for. It checks if the first field is a valid filename or basename, and then if it refers to a fits file, with 1 HDU (so an image) or more than 1 (a mosaic). It checks if the second field is a number or not. It uses InputDataReadExternalSource to extract info from a input file, removing header and comments.

Parameters
----------
    inputdata : str, list
        Name of the input file ('-' for standard input) or list of lines
    header, comment, minlen :
        See InputDataReadExternalSource

Returns
-------
    Tuple with:
        number of data lines, 
        tuple with how many of number of first fields: not a file, a file but not a fits, an image, a mosaic
        number of second fields that are numbers
        tuple with: if all the lines have same number of fields, the mean, min and max length.

Functions
---------
    InputDataReadExternalSource

""";
  _name_='InputDataFileAnalyze';

  if(comment is None): comment=bpar.SkZp_Par['commentpattern'];
  if(header is None): header=bpar.SkZp_Par['headerfilepattern'];
  dataL=InputDataReadExternalSource(inputfile=inputdata, header=header, comment=comment, minlen=minlen)[1] if(isinstance(inputdata, str)) else inputdata ;
  noex, fn, img, mos=0,0,0,0;
  fwhm=0;
  nlL=[];
  for line in dataL:
    tmpl=line.strip().split()+[None];
    if(tmpl[0].startswith(comment)): continue;
    nlL.append(len(tmpl)-1);
    ret=check_file(tmpl[0], raisexc=False);
    if(ret): ret=ret[1];
    if(ret==2):
      ret=check_file(tmpl[0]+_opt.SkZp_Opt['S']['fitsextension'], raisexc=False);
      if(ret): ret=ret[1];
      if(ret==0 or ret==1):
        try:
          with fits.pyfits.open(tmpl[0]+_opt.SkZp_Opt['S']['fitsextension']) as fitso:
            nhdu=len(fitso);
        except OSError:
          nhdu=0;
      else: nhdu=-1;
    elif(ret==0 or ret==1):
      try:
        with fits.pyfits.open(tmpl[0]) as fitso:
          nhdu=len(fitso);
      except OSError:
        nhdu=0;
    val=getfloat(tmpl[1]);
    if(nhdu<0): noex+=1;
    elif(nhdu==0): fn+=1;
    elif(nhdu==1): img+=1;
    else: mos+=1;
    if(val != None): fwhm+=1;
  allsame=all(nlL[0]==x for x in nlL);
  arrnl=numpy.array(nlL);
    
  return(len(dataL), (noex, fn, img, mos), fwhm, (allsame, round(arrnl.mean(),1), arrnl.min(), arrnl.max()) );
    

#######################
def InputDataFromFile(inputfile=None, taglist=None, tagconv=None, mode='w', listof='image', runlist=None, entrylist=None, datadict=None, datatag=None):
  """Reads input file 'inputfile' and retrieves the image information.

Parameters
----------
    inputfile : str, None
        The input information. If inputfile='-' or None (default) then it will read from standard input and/or using filenames passed through command line. If inputfile is another string, it will be used as a filename.
    taglist : list of str
        List of tag of the data. If it is not given, it will use the very first line as list of tags. It is suggested to comment out this line with a '# '
    tagconv : list
        List of conversion specifiers of the tags. If it is not given, it will use the second line as list of format.
        It is suggested to comment out this line with a '#% '. Usable specifiers: int, float, str.
    mode : str
        'w' to create new set of data, 'a' to append/update the set of data,
    listof : str
        If the inputfile contain information about images: 'image'
        If the inputfile contain list of mosaic names: 'mosaic'
    runlist : None, list
        List of the entries to process. None for SkZp_Par['runlist']
    entrylist : None, list
        List of input data entries. None for SkZp_Par['inputlist']
    datadict : None, dict
        Dictionary of input data (dictionary of dictionaries). None for SkZp_Par['inputdata']
    datatag : None, list
        List of the tags in input data. None for SkZp_Par['datatag']

Tags
----------
    Mandatory tags for images:\n\t  NAME=name of the image witout extension .fits\n\t  FWHM=seeing/fwhm
    Other tags see documentation for parameter 'datatag'  
 
Returns
-------
    Number of entries.

Functions
---------
    InputDataReadExternalSource

""";
#        'u' to update entries in an existing set of data ????
  _name_='InputDataFromFile';
  if(inputfile is None):    inputfile= sys.argv[1] if(len(sys.argv)==2) else '-';
  if(not isinstance(inputfile,str)): raise TypeError(_name_+": `inputfile` must be a string or None <{}>".format(inputfile) );
  if(not re.search('[wa]', mode)): raise ValueError(_name_+": Wrong value for `mode` ('w' to create a new set, 'a' to append/update) <{}>".format(mode));
  if(not isinstance(listof,str)): raise TypeError(_name_+": `listof` must be a string ('image' or 'mosaic') <{}>".format(listof));
  if(not any( x in listof for x in ('image', 'mosaic'))): raise ValueError(_name_+": Wrong value for `listof` <{}>".format(listfor));

  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
  if(not isinstance(datadict,  dict)): raise TypeError(_name_+": 'datadict' must be a dict.");
  if(entrylist is None): entrylist=bpar.SkZp_Par['inputlist'];
  if(isinstance(entrylist, str)):
    if(entrylist is 'inputlist'): entrylist=bpar.SkZp_Par['inputlist'];
    elif(entrylist is 'runlist'): entrylist=bpar.SkZp_Par['runlist'];
    else: raise TypeError(_name_+": `entrylist` must be a list, None or a valid parameter name.");
  if(not isinstance(entrylist, list)): raise TypeError(_name_+": 'entrylist' must be a list.");
  if(runlist is None): runlist=bpar.SkZp_Par['runlist'];
  if(not isinstance(runlist, list)): raise TypeError(_name_+": 'runlist' must be a list.");
  if(datatag is None): datatag=bpar.SkZp_Par['datatag'];
  if(not isinstance(datatag,   list)): raise TypeError(_name_+": 'datatag' must be a list.");

  inputdata={};
  inputlist=[];
 #END initialization

  if(taglist is None and _opt.SkZp_Opt['DL']['inputdata:taglist']):
    if(_opt.SkZp_Opt['DL']['inputdata:taglist'].get(inputfile)):  taglist=_opt.SkZp_Opt['DL']['inputdata:taglist'][inputfile];
  if(taglist is not None):
    if(isinstance(taglist, list)):
      taglist=[x.upper() for x in taglist];
      bpar.SkZp_Par['datatag0missing']=set(bpar.SkZp_Par['datatag0'])-set(taglist);
      if(bpar.SkZp_Par['datatag0missing']): print(_name_, "Warning! Some fundamental tags are missing", bpar.SkZp_Par['datatag0missing'], file=bpar.SkZp_Par['stderr']);
    else:
      raise SkZpipeError("taglist must be a list or not defined (=None)", _name_);

  print("Reading input file data", file=bpar.SkZp_Par['stdout']);

 ##%%%%%##
  def _IDFF_readtag(line=''):
    """function to read the header with tag list.
  Parameters
  ----------
      line : str
          Line of text with sequence of tags.
  Return
  ------
      List of tags
  """;
    _name_='InputDataFromFile';
    tagl=line.strip('# ').upper().split();   ## strip('# ') => remove from start and end every '#' or ' '
    for ii in range(len(tagl)):
      tagl[ii]=tagl[ii].upper();
    if(any(tag not in tagl for tag in bpar.SkZp_Par['datatag0'])): raise SkZpipeError("missing needed tag ("+",".join(bpar.SkZp_Par['datatag0'])+") in {taglist}".format(taglist=tagl)+bpar.SkZp_Par['_doc_']['datatag'], _name_);
    return tagl;
 ##%%%%%##
  def _IDFF_line(line='', tag=[]):
    """function to read a line from input data source, matching the tags in 'tag' with info from 'line'.
  Returns: dict with InputData
  Parameters
  ----------
      line : str
          Text with the image information.
      tag : list
          List of the tags corresponding to info in 'line' (same order).
  Return
  ------
      Dictionary with image retrieved information. The values are in the type given by parameter 'datatagtype'.
  """;
    _name_='InputDataFromFile';
    datadict=dict(zip(tag, [None if(datum=='None') else datum for datum in line.split()]));

    datadict['NAME']=re.sub('\{}?$'.format(_opt.OptionGet('fitsextension')),'',datadict['NAME']);
    if('.' in datadict['NAME']): raise SkZpipeError(_name_+": NAME field has a dot inside: "+datadict['NAME']);
    tmpd=bpar.SkZp_ParDef['datadict'].copy(); #take a copy of the default values
    tmpd.update(datadict); #update the default values with the given values
    datadict=tmpd;

    if(datadict['CHIP'] is None):
      chipnum=_opt.OptionGet('chipnum'); 
      if(chipnum not in (None,'')): datadict['CHIP']=chipnum;
    if(not datadict['INSTRUMENT']):
       instr=_opt.OptionGet('instrument');
       if(instr): datadict['INSTRUMENT']=instr;

   #fix the value according the type
    for tag in datadict:
      if(datadict[tag] is not None and tag in bpar.SkZp_Par['datatagtype']):
        try:
          if(callable(bpar.SkZp_Par['datatagtype'][tag])):
            datadict[tag]=bpar.SkZp_Par['datatagtype'][tag](datadict[tag]);
          elif(isinstance(bpar.SkZp_Par['datatagtype'][tag], str)):
            tmpt=(datadict[tag],) if(isinstance(datadict[tag], str)) else tuple( datadict[tag] );
            datadict[tag]=bpar.SkZp_Par['datatagtype'][tag].format(*tmpt);
        except:
          print(datadict['NAME'], tag, datadict[tag], file=bpar.SkZp_Par['stdout']);
          raise;
          
    return datadict;
 ##%%%%%##

  if(taglist is None):
    (hdrL, dataL)=InputDataReadExternalSource(inputfile=inputfile, header=1, comment=None, minlen=3);
    if('image' in listof):
      taglist=_IDFF_readtag(hdrL[0]);
    else: taglist=['NAME'];
  else: 
    (hdrL, dataL)=InputDataReadExternalSource(inputfile=inputfile, header=0, comment=None, minlen=3);

  
  for line in dataL:
    tmpd=_IDFF_line(line, taglist);  #inputline + tag = dict
     
    #
    if(tmpd['NAME'] in inputlist):
      print("\t!!!The image {img} is already present! Overwriting the information.".format(img=tmpd['NAME']), file=bpar.SkZp_Par['stderr']);
      inputdata.update({tmpd['NAME']:tmpd});
    else:
      inputdata.update({tmpd['NAME']:tmpd});
      inputlist.append(tmpd['NAME']);
  
  if(mode=='w'):
    datadict.clear();
    datadict.update(inputdata);
    entrylist[:]=inputlist;
    runlist[:]=inputlist.copy();
  elif(mode=='a'):
    datadict.update(inputdata);
    for entry in inputlist:
      if(entry not in entrylist): entrylist.append(entry);
      if(entry not in runlist): runlist.append(entry);
  #AND 'u' ?????
  nd=len(inputdata);
  inputdata={};
  inputlist=[];
  datatag[:]=taglist;
  #
  return nd;

    
##############
def InputDataDefaultFix(entrylist=None, datadict=None, datatag=None, instr=None): #InputDataImageStatAdd
  """Initialize or fix the tag values in input data to have values for all the tag in SkZp_ParDef['datatag'] and SkZp_Par['datatag']. If not set, the value of the tag is set to None.

Parameters
----------
    entrylist : None, list
        List of images. None for all entrylist in SkZp_Par['inputlist']
    datadict : None, dict
        Dictionary of inputdata. None for SkZp_Par['inputdata']
    datatag : None, list
        List of the tags of data that has to be write down. None for SkZp_Par['datatag']
    instr : str, None
        Name of the instrument used to produce the mosaic.
""";
  _name_='InputDataDefaultFix';
  if(entrylist is None): entrylist=bpar.SkZp_Par['inputlist'];
  if(isinstance(entrylist, str)):
    if(entrylist is 'inputlist'): entrylist=bpar.SkZp_Par['inputlist'];
    elif(entrylist is 'runlist'): entrylist=bpar.SkZp_Par['runlist'];
    else: raise TypeError(_name_+": `entrylist` must be a list, None or a valid parameter name.");
  if(not isinstance(entrylist, (list,tuple))): raise TypeError(_name_+": 'entrylist' must be a list or a tuple.");
  if(datatag is None): datatag=bpar.SkZp_Par['datatag'];
  if(not isinstance(datatag, (list,tuple))): raise TypeError(_name_+": 'datatag' must be a list or a tuple.");
  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
  if(not isinstance(datadict, dict)): raise TypeError(_name_+": 'datadict' must be a dict.");

 #Adding other tags from default list and set them to None
  for tag in bpar.SkZp_ParDef['datatag']:
    if(tag not in datatag):
      datatag.append(tag);
 ##%%%%%##
  def _roundvalue(tag=None, rnd=6):
    tmpv=datadict[image].get(tag);
    if(tmpv):
      if(isinstance(tmpv, str) and ';' in tmpv): datadict[image][tag]=';'.join([str(round(float(x),rnd)) for x in tmpv.split(';')]);
      else: datadict[image][tag]=round(float(tmpv),rnd);
 ##%%%%%##
  bpar.SkZp_Par['instruments']={};
 #Initialization of default tag
  for image in entrylist:
    for tag in datatag:
      datadict[image].setdefault(tag);
      if(datadict[image][tag]==''): datadict[image][tag]=None;
#    if(datadict[image]['IMGSTAT'] is None):
#      if(os.path.exists(image+".fits")):
#        statD=fits.statimage(image+'.fits');
#        datadict[image]['IMGSTAT']="{:.1f};{:.2f}".format(statD['med'], statD['std']);
    tmpv=datadict[image].get('INSTRUMENT');
    if(tmpv): 
      bpar.SkZp_Par['instruments'].setdefault(tmpv, 0);
      bpar.SkZp_Par['instruments'][tmpv]+=1;
   
    _roundvalue('SCALE');
    _roundvalue('OFFSET');
  


   #FIXING my mess!
    if(datadict[image]['ENTRYTYPE']=='image'): datadict[image]['ENTRYTYPE']='image:sci';
    if(datadict[image]['ENTRYTYPE']=='sci-image'): datadict[image]['ENTRYTYPE']='image:sci';
    if(datadict[image]['ENTRYTYPE']=='stack-image'): datadict[image]['ENTRYTYPE']='stack';

  InputDataImageStatAdd(statkey=['med','mean','std'], ndigits=[1,1,2], singletag='IMGSTAT', override=False, entrylist=entrylist, datadict=datadict, datatag=datatag);

    
#  if(not _opt.SkZp_Opt['S']['instrument'] and len(bpar.SkZp_Par['instruments'])==1): _opt.SkZp_Opt['S']['instrument']=instr;




##################
#Extract hdu from mosaic

###
def ExtractFromMosaic(inputdata=None, mode='w', sortby=None, instr=None,  entrylist=None, datadict=None, datatag=None, autoremove=True, entrytype='image:sci'):  
  """Extract images from a mosaic/multi-hdu FITS.

Parameters
----------
    inputdata : dict, list of dict, list of str, str
        Input source: a filename ('-' for stadard input and/or using filenames passed through command line) or a list of dictionaries or a dictionary, or a list the filename of the mosaics.
              The format of the input file is:
                 mosaic-filename  output-name  what-to-extract(list of chips, area, ...)
              The dictionary must have the forma:
                 {'mosaic': mosaic-filename, 'outname': output-name, 'chip': what-to-extract}
            
              mosaic-filename : str
                it must contain the extension

              output-name : str
                It can contain shortcuts like:
                  %f : filename of the mosaic;
                  %F : a short version of the mosaic (instrument dependent; if not defined, just like %f);
                  %w : workname stored in the parameter 'workname';
                  %n : sequential enumeration of the entries
             
              what-to-extract : 
                Format of input in file:
                  A |-separated list of pairs of keyword and extractiong info, separated by a colon.
                  The key-words and extracting info must be:
                    ##:a comma-separated list of chip numbers;  or  a semicolon-separated list to describe an interval of chip numbers: #initial;#final[;step]. Default value for step is 1.
                    #n:a comma-separated list of chip ids/names (string)  or  a semicolon-separated list to describe an intervalof chip ids: prefix;#initial;#final;step. stap is optional and its default value for step is 1.
                    area: a semicolon-separated list of comma-separated lists giving equatorial coordinates of the center and radius in arcmin of the area to extract
                    part: a comma-separated list of part of the mosaic with names instrument dependent (e.g. stripes for VIRCAM)
                  Same format can be used for option 'image:extract:select'.
                Format of input in dictionary (key 'chip'):
                  a list of chip numbers or IDs; 
                  a tuple or a list of tuples to define an interval of chips: (#initial, #final[, step]). Default value for step is 1. In the case of an interval of chip IDs, first element is the prefix, e.g. (prefix,#initial;#final[;step]).
                  a dictionary with format {'key-word': info}. The pair key:values must be:
                    '##'    : a list of chip numbers; or a tuple to describe an interval (same as above).
                    '#n'    : a list of chip names; or a tuple to describe an interval (same as above).
                    'area' : a list of tuples or a tuple giving equatorial coordinates of the center and radius in arcmin of the area to extract
                    'part' : a list of part of the mosaic with instrument-dependent names (e.g. from a to b for stripes in VIRCAM)
    mode : str
        Mode for the actualization: 'w' to create new set of data, 'a' to append/update to an existing the set of data)

    sortby : str
        Header keys used to sort the data
    instr : str, None
        Name of the instrument used to produce the mosaic.
    entrylist : None, list
        List of input data entries. None for SkZp_Par['inputlist']
    datadict : None, dict
        Dictionary of input data (dictionary of dictionaries). None for SkZp_Par['inputdata']
    datatag : None, list
        List of the tags in input data. None for SkZp_Par['datatag']
    autoremove : bool
        Flag to remove automatically rejected images
    entrytype : str
        Value for the ENTRYTYPE tag

Returns
-------
    Tuple (list,dict) with the list of the images and a dictionary of dictionaries of the image info.

Functions
---------
    startime
    WaitStop
    namereplacepattern
    FitsHeaderInfoRetrieve

  """;
  _name_="ExtractFromMosaic";
  if(inputdata is None): inputdata='-';
  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
  if(not isinstance(datadict,  dict)): raise TypeError(_name_+": 'datadict' must be a dict.");
  if(entrylist is None): entrylist=bpar.SkZp_Par['inputlist'];
  if(isinstance(entrylist, str)):
    if(entrylist is 'inputlist'): entrylist=bpar.SkZp_Par['inputlist'];
    elif(entrylist is 'runlist'): entrylist=bpar.SkZp_Par['runlist'];
    else: raise TypeError(_name_+": `entrylist` must be a list, None or a valid parameter name.");
  if(not isinstance(entrylist, list)): raise TypeError(_name_+": 'entrylist' must be a list.");
  if(datatag is None): datatag=bpar.SkZp_Par['datatag'];
  if(not isinstance(datatag,   list)): raise TypeError(_name_+": 'datatag' must be a list.");

  #instr
  if(instr is not None  and not isinstance(instr,str)): raise TypeError(_name_+": 'instr' must be a string, or None.");
  if(not instr):  instr=_opt.SkZp_Opt['S']['instrument'];
  #mode
  if(not re.search('[wa]', mode)): raise ValueError(_name_+": Wrong value for 'mode': 'w' to create a new set, 'a' to append/update");
  #sortby
  if(sortby and not isinstance(sortby,str)): raise TypeError(_name_+": 'sortby' must be a string, or None.");
  #inputdata
  if(not isinstance(inputdata,(str, list, dict))): raise TypeError(_name_+": 'inputdata' must be a string, None, a list of dict or a dict.");
  autoremove=bool(autoremove);
  if(_opt.SkZp_Opt['Flg']['debug']): autoremove=False;

 ##%%%%%##
  def _EFM_chipdict(line=''):
    """function for Extract images from a mosaic/multi-hdu FITS to transform input text into dict for chip selection""";
    _name_="ExtractFromMosaic";
    line=line.strip();
    if(not line): return {};
    tmpd=dict((key,[]) for key in ['#', 'part', 'area']);
    tmpl=line.split('|');
   #FIXING
    if(len(tmpl)==1 and not ':' in tmpl[0]):
      tmpl[0]="##:"+tmpl[0];
    for bit in tmpl:
      if(not ':' in bit): raise SkZpipeError("'chip' info from input file doesn't have the format key:value.", exclocus=_name_);
      (key,value)=bit.split(':');
      if(re.search('^#.*', key)):
        key=key[1:];
        if(not key or key=='#'): #List/tuple of chip numbers
          if(';' in value):
            chpl=value.split(';');
            if(len(chpl)!=3): chpl+=[1];
            chpl=[tuple(int(x) for x in chpl)];
          else: chpl=[int(chp) for chp in value.split(',')];
        elif(key=='n'): #List/tuple of chip names
          if(';' in value):
            chpl=value.split(';');
            if(len(chpl)!=4): chpl+=[1];
            chpl=[ (chpl[0], )+tuple(int(x) for x in chpl[1:]) ];
          else: chpl=value.split(',');
        tmpd['#'].extend(chpl);
      elif(key=='area'):
        tmpd['area'].extend([tuple( float(x) for x in xx.split(',') ) for xx in value.split(';') ]);
      elif(key=='part'):
        tmpd['part'].extend( value.split(','));
    for key in list(tmpd.keys()):
      if(not tmpd[key]): del(tmpd[key]);
    return tmpd;
 ##%%%%%##
  
 ##INPUTDATA => list of dict
  
  if(_opt.SkZp_Opt['Flg']['debug']):
    startime("Reading inputdata...");
  else:
    print("Reading inputdata...", file=bpar.SkZp_Par['stdout']);
  if(isinstance(inputdata,str)):
   #FIRST: if from file, translate it into dict form
    inputfile=inputdata;
    inputdata=[];
    dataL=InputDataReadExternalSource(inputfile=inputfile, header=None, comment=None, minlen=minlen)[1];
    for line in dataL:
      tmpl=line.split();
      tmpd={'mosaic':tmpl[0], 'outname':None, 'chip':None};
      if(len(tmpl)>1):
        tmpd['outname']=tmpl[1];
        if(len(tmpl)>2): tmpd['chip']="|".join(tmpl[2:]);
      if(tmpd['outname']=='-'): tmpd['outname']=None;
      if(tmpd['chip']):
        tmpd['chip']=_EFM_chipdict(tmpd['chip']);  ##%%%
      inputdata.append(tmpd);
  elif(isinstance(inputdata,dict)): inputdata=[inputdata];
  elif(isinstance(inputdata,list) and all(isinstance(x,str) for x in inputdata)): inputdata=[{'mosaic':x} for x in inputdata];

  ###FROM NOW  inputdata = list of dicts with extracting information
  mosinfo={};
  chipselectopt=_EFM_chipdict(_opt.OptionGet('image:extract:select')); ##%%%  #Get rules from options and put them as dict

 #Fixing inputdata and extracting info from mosaic header
  print("Fixing inputdata...", file=bpar.SkZp_Par['stdout']);
 #INPUTDATA DICT filling and fixing
  for inp in inputdata:
    if(not isinstance(inp, dict)): raise TypeError(_name_+": Wrong type for 'inputdata' (it should  be a list dict by now).");
   #Fix missing entry in dictionary
    for tag in ('outname','chip'):
      if(tag not in inp): inp[tag]=None;
    if(inp['outname']=='-'): inp['outname']=None;
    if(not all(tag  in inp for tag in ('mosaic','outname','chip'))): raise SkZpipeError("inputdata doesn't have all the needed keys", exclocus=_name_);

   #Fix 'chip' entry: From list/tuple to dict {'#':[], 'part':[], 'area':[]}
    #No value => default
    if(not inp['chip']): inp['chip']=copy.deepcopy({'#':[], 'part':[], 'area':[]});
    #List
    if(isinstance(inp['chip'], list)): inp['chip']={'#':inp['chip']};
    #Tuple  => Interval of chips (start, end, step=1)
    elif(isinstance(inp['chip'], tuple)):
      if(isinstance(inp['chip'][0], str)):
        inp['chip']= [inp['chip']+(1,)] if(len(inp['chip'])<4) else [inp['chip']];
      else:
        inp['chip']= [inp['chip']+(1,)] if(len(inp['chip'])<3) else [inp['chip']];
      inp['chip']={'#': inp['chip']};

    # 'chip' entry NOW should be only a dict and its entry '#' a list
    if(not isinstance(inp['chip'], dict)):  raise TypeError(_name_+": Wrong type for 'chip' entry in 'inputdata': it should  be a dict by now. > {:} <".format(str(inp['chip'])) ); 

   # '#': List of chip
   #Opt chipselect : #
    if(_opt.OptionGet('image:extract:select')):
      if('#' in chipselectopt and chipselectopt['#']): inp['chip']['#']=chipselectopt['#'].copy();
    if('#' in inp['chip']):  #Starting to transform the extracting info into just list of chips
      if(not isinstance(inp['chip']['#'], list)): raise TypeError(_name_+": '#' entry of 'chip' entry in 'inputdata' should  be a list by now."); 
      chpl=[];
      for chp in inp['chip']['#']: #merging all the entries in a single list
        if(isinstance(chp, tuple)): 
          if(isinstance(chp[0], str)):
            chpl.extend([ chp[0]+str(x) for x in range(chp[1], chp[2]+1, chp[3]) ]);
          else:
            chpl.extend(list( range(inp['chip'][0], inp['chip'][1]+1, inp['chip'][2] if(len(inp['chip'])==3) else 1)) );
        else: chpl.append(chp);
      inp['chip']['#']=chpl;
    #all the entry are list

   # 'part': List of sensor part
   # 'area': List of sky areas
    for key in ('part', 'area'):
      inp['chip'].setdefault(key, []);
      if(not isinstance(inp['chip'][key], list)): inp['chip'][key]=[ inp['chip'][key] ];
      if(_opt.OptionGet('image:extract:select')):
        if(key in chipselectopt and chipselectopt[key]): inp['chip'][key].extend( chipselectopt[key].copy() );


   #NOW 'chip':'#' is a list of chip: 'area' and 'part' will refer to this chip

    #Removing empty values
    for key in ['#', 'part', 'area']:
      if(not inp['chip'][key]): del(inp['chip'][key]);

   #Extracting info from header
    if(inp['mosaic'] not in mosinfo):
      check_file(inp['mosaic']);
      mosinfo[inp['mosaic']]=FitsHeaderInfoRetrieve(image=inp['mosaic'], headertype='mos')[0];
  
# Sort by hdr entry defined in 'sortby' variable
  if(sortby):
    print("Sorting input list by header card {:}.".format(tag), file=bpar.SkZp_Par['stdout']);
    if(isinstance(sortby,str)): inputdata.sort(key=lambda inp : mosinfo[ inp['mosaic'] ][sortby]);

####################################################
# Starting actual selection
  for inp in inputdata:
    WaitStop();
   #get list of EXTNAME in the mosaic
    lstext=fits.listextname(inp['mosaic']); # For chip selection
    nhdu=len(lstext); # For chip selection
    instrm=instr;
    if(not instrm): instrm=mosinfo[inp['mosaic']].get('INSTRUMENT');

  ###############  
  #Selecting chip

   #set 'chip' default= all (mosaic dependent)
    if(not inp['chip']): inp['chip']={'#':list(range(1,nhdu))};
    elif('#' not in inp['chip']): inp['chip']['#']=list(range(1,nhdu));
    elif( not inp['chip']['#']): inp['chip']['#']=list(range(1,nhdu));
    else:
      for chp in inp['chip']['#']:
        #This check should be correct, without bug
        if(isinstance(chp, int)):
          if(chp<1 or chp>=nhdu): raise ValueError(_name_+": Wrong value for chip ({:d}) in mosaic {:}".format(chp, inp['mosaic']));
        elif(isinstance(chp,str)):
          if(chp not in lstext): raise ValueError(_name_+": Wrong value for chip/extname ({chip}) in mosaic {mos} {extl}".format(chip=chp, mos=inp['mosaic'], extl=lstext));
        else: raise TypeError(_name_+": Wrong type for 'chip' key for mosaic {:}.".format(inp['mosaic']));

   #by area
    if('area' in inp['chip'] and inp['chip']['area']):
      newchipl=[];
      for area in inp['chip']['area']:
        (xx,yy)=mathfunct.eq2plane(radec=area[:2], radec0=(mosinfo[inp['mosaic']]['RA'], mosinfo[inp['mosaic']]['DEC']), theta=_db.SkZp_DB['chipselect'][instrm]['posang'](mosinfo[inp['mosaic']]));
        chipl=[];
        for chip in inp['chip']['#']:
          (xpos,ypos)=_db.SkZp_DB['chipselect'][instrm]['pos']({**mosinfo[inp['mosaic']], 'CHIP':chip});
          if((xpos-xx)**2+(ypos-yy)**2<area[2]**2): chipl.append(chip);
        newchipl.extend(chipl);
      inp['chip']['#']=newchipl;

   #by being in a particular 'part' of the mosaic
    if('part' in inp['chip'] and inp['chip']['part']):
      newchipl=[];
      for part in inp['chip']['part']:
        newchipl.extend([ chip for chip in inp['chip']['#'] if( part == _db.SkZp_DB['chipselect'][instrm]['part']({**mosinfo[inp['mosaic']], 'CHIP':chip}) ) ]);
      inp['chip']['#']=newchipl;
      

################################## 
# Check uniformity in Observation Sets

  if(_opt.SkZp_Opt['Flg']['image:select:check']):
   #RUN Instrument specific check
    if(instr in _db.SkZp_DB['obs_set_check']):    _db.SkZp_DB['obs_set_check'](inputdata, mosinfo);
  
     #Additional check for uniformity if not instrument is set
    elif(_opt.SkZp_Opt['Flg']['image:select:uniform']):
      chipset=set();
      for inp in inputdata:
        if(inp['chip']['#']): chipset|=set(inp['chip']['#']);
      chipset=tuple(chipset);
      for inp in inputdata:
        if(inp['chip']['#']): inp['chip']['#']=chipset;
    
    
          
####################################################
# STARTING  extracting
  if(_opt.SkZp_Opt['Flg']['debug']): startime("Extracting chips");
  imgcounter, imglist, imgdict = 0, [], {};
  for inp in inputdata:
    WaitStop();
   #get list of EXTNAME in the mosaic
    instrm=instr;
    if(not instrm): instrm=mosinfo[inp['mosaic']].get('INSTRUMENT');

    print('Mosaic -->', inp['mosaic'], ':', end='', file=bpar.SkZp_Par['stdout']);
    if(not inp['chip']['#']):
      print("No chips to extract. Skipping to the next!\n", file=bpar.SkZp_Par['stdout']);
      continue;
  #################
   #set outname
    imgcounter+=1;
    imgcnt=str(imgcounter).zfill(3);
    chipext=False;

    if(not inp['outname']): inp['outname']='%F';
    if('%f' in inp['outname'].lower()): chipext=True;  #If outname is '%f' or '%F' set to add chip ID 
    flagL=re.findall('%.', inp['outname']);
    if(len(flagL)!= len(set(flagL))): raise SkZpipeError("a flag in the output name is repetited in {:} for mosaic {:}.".format(inp['outname'], inp['mosaic']), exclocus=_name_);
    inp['outname']=_opt.namereplacepattern(inp['outname'], {'%f':inp['mosaic'], '%F':_db.SkZp_DB['namepattern'][instrm if(instrm in _db.SkZp_DB['namepattern']) else None]['%F'](inp['mosaic']), '%n':imgcnt, '%w':str(_opt.SkZp_Opt['S']['workname']) }); #??? Not really updatable

  #ACTUAL Extracting chips
    if(len(inp['chip']['#'])>1): chipext=True;
    if(chipext): inp['outname']+="_{chip}";
    for chip in inp['chip']['#']: # ['chip']['#'] can be any iterator
      bname=inp['outname'].format( chip=str(chip).zfill(2) if(isinstance(chip, int)) else chip );
      fname=bname+'.fits';
      flag='e';
      if(not os.path.exists(fname) or _opt.SkZp_Opt['S']['inputdata:action']=='extractforce'):
        fits.extractchip(inp['mosaic'], chip, fname);
        flag='n';
      print(" {fname} ({flag}) ".format(fname=fname, flag=flag), end='', file=bpar.SkZp_Par['stdout']);
      statD=fits.statimage(fname, typeoutput='dict');
      if(_opt.SkZp_Opt['Flg']['image:autochipreject']):
        if(statD['max']-statD['min']<1000):
          print('[max-min<1000! Rejected!]  ', file=bpar.SkZp_Par['stdout']);
          if(autoremove): os.unlink(fname);
          continue;
      imglist.append(bname);
      imgdict[bname]={'NAME': bname, 'FWHM': None, 'ENTRYTYPE': entrytype};
    print('', file=bpar.SkZp_Par['stdout']);
  
  #############################################################################
  if(mode=='w'):
    entrylist.clear();
    datadict.clear();
  entrylist.extend(imglist);
  datadict.update(imgdict);
   #

  return (imglist, imgdict);



###########
def InputDataInitialize(inputdata=None, action=None, taglist=None, mode='w', select=None, options=None, optfiles=[], instr=None, readheader=None, headeroverride=None, readdatabase=None, readjustfile=None, forceMJD=None, forcenight=None, statkey=None, statndigits=2, statsingletag=None, statoverride=False, sortby=None, verb=True, force=False):
  """Run the functions to read option files, to get input data and extract info from headers and internal database. 
At the end it reload the data from option files (if someone changes values from headers and database).
If the initialization has already been done (SkZp_Par['initializingflag']==True), it will not be operated.
Essentially a front-end function.

Parameters
----------
    inputdata : str, None
        Input file
    action : str, None
        Action to operate with the input data. If undetermined (None), the function determines if the input data are for already-extracted images or to extract them.
            None/''      : The procedure decides by itself (Default)
            info         : Just generate the internal information database.
            extract      : The images are extracted from mosaic.
            extractforce : The images are extracted even the image already exist
    taglist : list
        List of the tag of the info inside 'inputdata' input data.
    mode : str
        Mode for the creation of the internal data: 'w' to create a new, 'a' to append/update
    select : str, dict, list of str
        Selection options (input for InputDataSelect, see it). 
    options : dict
        Dictionary with additional options
    optfiles : list
        List of option files
    readheader : bool
        Flag to determine if to read image headers, or just the input file
    headeroverride : bool
        Flag to determine if the data from FITS header have to override the existing data
    readdatabase : bool
        Flag to determine if to read the internal database, or just the input file
    readjustfile : bool
        Flag to determine if to read just the input file (if True, it sets readdatabase and readjustfile to False);
    forceMJD : bool
        If the MJD has to be recalculates even if there is a valid value.
    forcenight : bool
        If the night number has to be recalculates even if there is a valid value.
    statkey : list of str
        List of the image statistics to add as single tags. Options are: 'mean', 'med', 'min', 'max', 'std'
    statndigits : int, list of int
        Precision in decimal digits (default 1 digit). One value for each key, or a global one.
    statsingletag : str
        The name of the single tag, if only a single tag is added/set.
    statoverride : bool
        To change the value of an existing tag, even if its value is not None.
    sortby : str
        Inputdata tag used to sort the data
    verb : bool
        Enable full verbosity
    force : bool
        Force the initialization even if it is already done (parameter 'initializingflag')

Functions
---------
    OptionRead
    InputDataFromFile
    ExtractFromMosaic
    InputDataDefaultFix
    InputDataFromFitsHeader
    InputDataSetMJD
    InputDataSetNightNumber
    DatabaseRetrieve
    InputDataImageStatAdd
    InputDataSelect
    OptionReload
    InputDataCheckFix

""";
  _name_='InputDataInitialize';

  if(sortby and not isinstance(sortby, str)): raise TypeError(_name_+": `sortby` must be the name of a tag");


  #READING OPTIONS
  _opt.OptionRead(optfiles, options=options);

  if(_opt.SkZp_Opt['I']['errorhide']):
    if(_opt.SkZp_Opt['I']['errorhide']>0):
      bpar.SkZp_Par['stderr']=open(os.devnull,"w");
    else:
      sys.stderr=open(os.devnull,"w");
  if(_opt.SkZp_Opt['I']['errorhide']!=-1 and _opt.SkZp_Opt['Flg']['errorshutup']):
      sys.stderr=open(os.devnull,"w");
 #END OPTIONS

  if(not force and bpar.SkZp_Par['initializingflag']):
    if(verb): print("InputData already initialized! Skipping.", file=bpar.SkZp_Par['stdout']);
    return;
  bpar.SkZp_Par['store4later']={};

  if(readheader is None):   readheader  =_opt.SkZp_Opt['Flg']['inputdata:readheader'];
  if(readdatabase is None): readdatabase=_opt.SkZp_Opt['Flg']['inputdata:readdatabase'];
  if(readjustfile is None): readjustfile=_opt.SkZp_Opt['Flg']['inputdata:readjustfile'];
  if(readjustfile): readheader, readdatabase=False, False;
  if(not action): action=_opt.OptionGet('inputdata:action');

  if(inputdata is None): inputdata='-';
  if(not action):
    (num, filean, fwhman, lenlines)=InputDataFileAnalyze(inputdata=inputdata);
#        number of data lines, 
#        tuple with how many of number of first fields: not a file, a file but not a fits, an image, a mosaic
#        number of second fields that are numbers
#        tuple with: if all the lines have same number of fields, the mean, min and max length.
    try:
      if(num==filean[3]):
        action='extract';
        if(lenlines[1]==1 and not _opt.OptionGet('image:extract:select')):
          action='info:mosaic';
      elif(num==filean[2]==fwhman or num==(filean[0]+filean[2])==fwhman):
        action='info:image';
        if(not lenlines[0]): raise SkZpipeError(); #The lines has not same length
      else: raise SkZpipeError(); #Anomalous
    except:
      raise SkZpipeError("""The input file is anomalous: 
There are {num:d} lines {notnl} containing the same number of fields {tup}: 
  in {nofile:d} the first field does not refer to a filename or a basename of image; 
  in {fname:d} the first field refers to a file but not to a FITS file;
  in {img:d} the first field refers to an image
  in {mos:d} the first field refers to a multi-HDU FITS
  in {fwhm:d} the second field is not a number (so not a valid FWHM)
The input file to extract images should have as first field the mosaic
The input file to elaborate images should have as first field the image base name and second filed the FWHM.
""".format(num=num, notnl='' if(lenlines[0])else 'not', tup=lenlines[1:], nofile=filean[0], fname=filean[1], img=filean[2], mos=filean[3], fwhm=fwhman), exclocus='Inizialization');
  flush_out();

  if(action.startswith('extract')):
    # ExtractFromMosaic(inputdata=None, mode='w', sortby=None, instr=None, autoremove=True):
    ExtractFromMosaic(inputdata=inputdata, mode=mode, sortby=sortby, instr=instr, autoremove=True);
    if(not readheader):
      print('WARNING!!! Images are estracted by mosaics and options saying to not extract data from headers! The flag is changed to True.', file=bpar.SkZp_Par['stdout']);
      readheader=True;
    if(not readdatabase):
      print('WARNING!!! Images are estracted by mosaics and options saying to not extract data from internal database!', file=bpar.SkZp_Par['stdout'], end='');
      if(bpar.SkZp_Par['saferunbit']&1):
        print(" The flag is changed to True (saferun['base']=1).", file=bpar.SkZp_Par['stdout']);
        readdatabase=True;
      else: print('', file=bpar.SkZp_Par['stdout']);
    listof='image';
  elif(action.startswith('info')):
    listof= 'mosaic' if('mosaic'in action) else 'image';
    #InputDataFromFile(inputfile=None, taglist=None, mode='w')
    InputDataFromFile(inputfile=inputdata, taglist=taglist, mode=mode, listof=listof);
  else:
    raise ValueError(_name_+": wrong value for `action` (see help function or option 'inputdata:action') <{}>".format(action))
  flush_out();

  InputDataDefaultFix(instr=instr); 
  flush_out();

 #If retrieve data from fits header
  if(forceMJD is None): forceMJD=_opt.SkZp_Opt['Flg']['inputdata:mjdset'];
  if(forcenight is None): forcenight=_opt.SkZp_Opt['Flg']['inputdata:nightset'];
  if(readheader):
    if(verb): print('Reading FITS headers...', file=bpar.SkZp_Par['stdout']);
    #InputDataFromFitsHeader(instr=None, chipheaderext=None, mosheaderext=None)
    InputDataFromFitsHeader(instr=instr, override=headeroverride, listof=listof);
    #InputDataSetMJD(force=False):
    InputDataSetMJD(forceMJD);
    InputDataSetNightNumber(relenum=True, force=forcenight)
    flush_out();
  else:
    if(forceMJD or _opt.SkZp_Opt['Flg']['inputdata:mjdfix']):
      InputDataSetMJD(forceMJD);
    if(forcenight or _opt.SkZp_Opt['Flg']['inputdata:nightfix']):
      InputDataSetNightNumber(relenum=True, force=forcenight);
    flush_out();

 #If retrieve data from internal database


  #DatabaseRetrieve(instr=None)
  DatabaseRetrieve(instr=instr, readmode=readdatabase, verb=verb);
  flush_out();

  InputDataImageStatAdd(statkey=statkey, ndigits=statndigits, singletag=statsingletag, override=statoverride);

 #Select runlist according to all input data=file+header
  nsel=InputDataSelect(select=select);
  if(nsel<1): raise SkZpipeError("No entries selected in 'runlist'!!!", exclocus=_name_);

  #Reload previously read Options
  _opt.OptionReload(optfiles);
  flush_out();

  InputDataCheckFix();
#  InputDataSort();
  if(sortby):
    if(sortby in bpar.SkZp_Par['datatag']):
      bpar.SkZp_Par['inputlist'].sort(key=lambda entry : bpar.SkZp_Par['inputdata'][ entry ][ sortby ])
    else:
      print("WARNING in "+_name_+": `sortby` must be the name of a tag" );
  SpeedUpTest();

  bpar.SkZp_Par['initializingflag']=True;
  if(instr): _opt.SkZp_Opt['S']['instrument']=instr;



########################
def InputDataSplitByTag(tag=None, oper=None, sep=':', entrylist=None, datadict=None, datatag=None):
  """Separate images in 'entrylist' (default SkZp_Par['inputlist']) according to the value of 'tag' in inputdata database

Parameters
----------
    tag : str, list, None
        Name or list of names of the tags to be used to separate the file list, following the order of the tags. If None, a list with all the entrylist is return.
    oper : callable, list, None
        Function or list of functions to be applied on the tag value to determined how to separate the entrylist. None to use directly the value. If 'tag' is a list', 'oper' must be a list of same size.
    sep : str
        Separator used in case 'tag' is a list.
    entrylist : None, list, str
        Ordered list of the entries to choose from. None for parameter 'inputlist'. Or the name of the parameter: 'runlist' for parameter 'runlist', 'inputlist' for parameter 'inputlist'.
    datadict : None, dict
        Dictionary of inputdata (dictionary of dictionaries). None for SkZp_Par['inputdata']
    datatag : None, list
        List of the tags of input data. None for parameter 'datatag'

Returns
-------
    A 2-element tuple with: list of values of the tag; dictionary where the keys are the values of the tag and the values are list of the images with that value.
    If 'tag' is a list, the values in the list and keys of the dictionary are a ordered composition of the values of the tags, separated by 'sep'.
""";
  _name_='InputDataSplitByTag';
  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
  if(entrylist is None): entrylist=bpar.SkZp_Par['inputlist'];
  if(datatag is None): datatag=bpar.SkZp_Par['datatag'];
  if(isinstance(entrylist, str)):
    if(entrylist is 'inputlist'): entrylist=bpar.SkZp_Par['inputlist'];
    elif(entrylist is 'runlist'): entrylist=bpar.SkZp_Par['runlist'];
    else: raise TypeError(_name_+": `entrylist` must be a list, None or a valid parameter name. <{}>".format(entrylist));
  if(not isinstance(datadict,  dict)): raise TypeError(_name_+": `datadict` must be a dict.");
  if(not isinstance(entrylist, list)): raise TypeError(_name_+": `entrylist` must be a list.");
  if(not isinstance(datatag,   list)): raise TypeError(_name_+": `datatag` must be a list.");
  if(not isinstance(sep, str)): raise TypeError(_name_+": `sep` must be a string.");

  if(tag is not None and not isinstance(tag, (str,list))): raise TypeError(_name_+": `tag` must be a string, None or a list of string");
  if(isinstance(tag, list)):
    for tg in tag:
      if(not isinstance(tg, str)): raise TypeError(_name_+": `tag` must be a string, None or a list of string");
    if(len(tag)==1): tag==tag[0];
  if(not tag): return([None], {None:entrylist.copy()})
  
  if(isinstance(oper, list)):
    for opr in oper:
     if(opr is not None and not callable(opr)): raise TypeError(_name_+": `oper` must be a callable, or None, or a list of callables or None");
    if(len(oper)==1): oper==oper[0];
  else:
    if(oper is not None and not callable(oper)): raise TypeError(_name_+": `oper` must be a callable, or None, or a list of callables or None");
  
 ##%%%%%##
  def _IDSBT_split(tag=None, entrylist=None, oper=None):
    tag=tag.upper();
  
    if(tag not in datatag): raise KeyError(_name_+": tag {:} is not present in the input data.".format(tag));
    tagl=[]; tagd={};
    try:
      for fn in entrylist:
        if(fn not in datadict): raise KeyError(_name_+": file {:} is not present in the input data.".format(fn));
        val=datadict[fn][tag];
        if(oper is not None): val=oper(val);
        if(val not in tagl):
          tagl.append(val);
          tagd[val]=[];
        tagd[val].append(fn);
    except TypeError:
      raise TypeError(_name_+": entrylist must be an itarable or None");
    tagl.sort();
    return (tagl, tagd);
  ###
  if(isinstance(tag, str)):
    return _IDSBT_split(tag=tag, entrylist=entrylist, oper=oper);
  else:
    if(not isinstance(oper, list)):
      oper=[oper]*len(tag);
    elif(len(tag)!=len(oper)): ValueError(_name_+": `oper` and `tag` must contain the same number of members.");
    valL1,fileD1=_IDSBT_split(tag=tag[0], entrylist=entrylist, oper=oper[0]);
    for tg, opr in zip(tag[1:],oper[1:]):
      valL0,fileD0=[],{};
      for val1 in valL1:
        valL2,fileD2=_IDSBT_split(tag=tg, entrylist=fileD1[val1], oper=opr);
        for val2 in valL2:
          valL0.append(sep.join([val1,val2]));
          fileD0[valL0[-1]]=fileD2[val2];
        
      valL1,fileD1=valL0,fileD0;
    return (valL1,fileD1);
     

########################
def InputDataWrite(outfile=None, mode='w', style='all', select=None, atleast=None, entrylist=None, datadict=None, datatag=None, newtag=None): # backupfile
  """Write the input data into a file.

Parameters
----------
    outfile : str
        Output filename. If it starts with a plus '+', it will be considered as a suffix for the default value SkZp_Opt['S']['inputdata:file'].
    mode : str
        The mode in which the file is opened (same as 'mode' in open built-in function; only 'w' and 'a').
    style : str
        Type of the output: ASCII table ('txt') or HTML file ('html') or 'all' for both output
    entrylist : None, list, str
        Ordered list of the entries to choose from. None for parameter 'inputlist'. Or the name of the parameter: 'runlist' for parameter 'runlist', 'inputlist' for parameter 'inputlist'.
    select : dict, None
        As `select` of InputDataSelect
    atleast : bool
        Flag to select images that satisfy at least one of the values (True) or all the values (False) 
    datadict : None, dict
        Dictionary of inputdata (dictionary of dictionaries). None for SkZp_Par['inputdata']
    datatatatag : None, list
        List of the tags of data that has to be write down. None for SkZp_Par['datatag']
    newtag : dict,None
        Dictionary with the definition of data field not present in datadict, but included in datatag. The key must be the tag name, the values a callable that takes as input the input data dictionary of the entry.
""";
  _name_='InputDataWrite';
  if(entrylist is None): entrylist=bpar.SkZp_Par['inputlist'];
  if(isinstance(entrylist, str)):
    if(entrylist is 'inputlist'): entrylist=bpar.SkZp_Par['inputlist'];
    elif(entrylist is 'runlist'): entrylist=bpar.SkZp_Par['runlist'];
    else: raise TypeError(_name_+": `entrylist` must be a list, None or a valid parameter name.");
  if(not isinstance(entrylist, (list,tuple))): raise TypeError(_name_+": 'entrylist' must be a list or a tuple.");
  if(datatag is None): datatag=bpar.SkZp_Par['datatag'];
  if(not isinstance(datatag, (list,tuple))): raise TypeError(_name_+": 'datatag' must be a list or a tuple.");
  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
  if(not isinstance(datadict, dict)): raise TypeError(_name_+": 'datadict' must be a dict.");

  if(outfile is None): outfile=_opt.SkZp_Opt['S']['inputdata:file'];
  if(not isinstance(outfile,str)): raise TypeError(_name_+": 'outfile' must be a string or None");
  if(outfile[0]=='+'): outfile=_opt.SkZp_Opt['S']['inputdata:file']+outfile[1:];
  if(mode not in ('w','a')): raise ValueError(_name_+": Wrong value for 'mode'. It must be 'w' or 'a'.");
  if(style is None): style='all';

  if(select):
    tmpl=[];
    InputDataSelect(select=select, runlist=tmpl, entrylist=entrylist, datadict=datadict, datatag=datatag, atleast=atleast);
    entrylist=tmpl;
 
  everynlines=_opt.OptionGet('inputdata:headerdataevery');
  if(style in ['txt', 'all']):
    backupfile(outfile, keep=False if(mode=='w') else True);
    with open(outfile, mode) as f_out:
      headertxt='# '+'\t'.join(datatag)+'\n';
      ii=0;
      for fn in entrylist:
        if(ii%everynlines==0): f_out.write(headertxt);
        for tag in datatag:
          if(tag in datadict[fn]):
            val=datadict[fn][tag];
          elif(tag in newtag):
            val=newtag[tag](datadict[fn]);
          else: raise SkZpipeError("The tag '{}' doesn't exist!".format(tag), exclocus=_name_)
          f_out.write(str(val)+'\t');
        f_out.write('\n');
        ii+=1;
  if(style in ['html', 'all']):
    if(not re.search('\.html?$', outfile)): outfile+=".html";
    backupfile(outfile, keep=False if(mode=='w') else True);
    with open(outfile, mode) as f_out:
      td_tag='<td align=center>';
      tdfile_tag='<td align=left>';
      tr_tag='<tr>';
      f_out.write('<HTML>\n<body>\n<table>\n');
      headertxt='{:} {:}'.format(tr_tag, tdfile_tag) + '</td> {:}'.format(td_tag).join(datatag) + "</td></tr>\n ";
      ii=0;
      for fn in entrylist:
        if(ii%everynlines==0): f_out.write(headertxt);
        f_out.write("\n {:} {:} {:} </td>".format(tr_tag,tdfile_tag, fn));
        for tag in datatag[1:]:
          if(tag in datadict[fn]):
            val=datadict[fn][tag];
          elif(tag in newtag):
            val=newtag[tag](datadict[fn]);
          else: raise SkZpipeError("The tag '{}' doesn't exist!".format(tag), exclocus=_name_)

          f_out.write(td_tag+str(val)+'</td>');

#        for tag in datadict[fn]:
#          if(tag not in datatag):
#            f_out.write("</td>"+td_tag+str(datadict[fn][tag])+'</td>');
        f_out.write('</tr>\n');
        ii+=1;
      f_out.write("\n</table></body></HTML>");

####
def InputDataWrite_wfailed(outfile=None, mode='w', style='all', select=None, atleast=None, entrylist=None, datadict=None, datatag=None, newtag=None):
  """Write the input data into the file `outfile` and the entries that terminate with error into file `outfile`+'_err'. Front-end for InputDataWrite.

Parameters
----------
    outfile : str
        Output filename. It it starts with a dot, it will be considered as a suffix for the default value SkZp_Opt['S']['inputdata:file'].
    mode : str
        The mode in which the file is opened (same as 'mode' in open built-in function; only 'w' and 'a').
    style : str
        Type of the output: ASCII table ('txt') or HTML file ('html') or 'all' for both output
    entrylist : None, list, str
        Ordered list of the entries to choose from. None for parameter 'inputlist'. Or the name of the parameter: 'runlist' for parameter 'runlist', 'inputlist' for parameter 'inputlist'.
    select : dict, None
        As `select` of InputDataSelect
    atleast : bool
        Flag to select images that satisfy at least one of the values (True) or all the values (False) 
    datadict : None, dict
        Dictionary of inputdata (dictionary of dictionaries). None for SkZp_Par['inputdata']
    datatatatag : None, list
        List of the tags of data that has to be write down. None for SkZp_Par['datatag']
    newtag : dict,None
        Dictionary with the definition of data field not present in datadict, but included in datatag. The key must be the tag name, the values a callable that takes as input the input data dictionary of the entry.

Functions
---------
    InputDataWrite
""";
  _name_='InputDataWrite_wfailed';
  if(outfile is None): outfile=_opt.SkZp_Opt['S']['inputdata:file'];
  if(not isinstance(outfile,str)): raise TypeError(_name_+": 'outfile' must be a string or None");
  if(outfile[0]=='.'): outfile=_opt.SkZp_Opt['S']['inputdata:file']+outfile;

  InputDataWrite(outfile=outfile, mode=mode, style=style);
  InputDataWrite(outfile=outfile+'_err', entrylist=bpar.SkZp_Par['errorlist'], mode=mode, style=style);


###
def InputDataPrint(outfile=None, entrylist=None, datadict=None, datatag=None):
  """print the input data to a file object with a write(string) method in text mode.

Parameters
----------
    outfile : File object
        Stream object. Default value SkZp_Par['stdout'].
    entrylist : None, list
        List of images/inputdata entries. None for all entrylist in SkZp_Par['inputlist']
    datadict : None, dict
        Dictionary of inputdata. None for SkZp_Par['inputdata']
    datatag : None, list
        List of the tags of data. None for SkZp_Par['datatag']
""";
  _name_='InputDataPrint';
  if(entrylist is None): entrylist=bpar.SkZp_Par['inputlist'];
  if(isinstance(entrylist, str)):
    if(entrylist is 'inputlist'): entrylist=bpar.SkZp_Par['inputlist'];
    elif(entrylist is 'runlist'): entrylist=bpar.SkZp_Par['runlist'];
    else: raise TypeError(_name_+": `entrylist` must be a list, None or a valid parameter name.");
  if(not isinstance(entrylist, (list,tuple))): raise TypeError(_name_+": 'entrylist' must be a list or a tuple.");
  if(datatag is None): datatag=bpar.SkZp_Par['datatag'];
  if(not isinstance(datatag, (list,tuple))): raise TypeError(_name_+": 'datatag' must be a list or a tuple.");
  if(datadict is None): datadict=bpar.SkZp_Par['inputdata'];
  if(not isinstance(datadict, dict)): raise TypeError(_name_+": 'datadict' must be a dict.");
  if(outfile is None): outfile=bpar.SkZp_Par['stdout'];
  if(not hasattr(outfile, 'write')): raise TypeError(_name_+": outfile must be an object with a write(string) method.");
 
  everynlines=_opt.OptionGet('inputdata:headerdataevery');
  headertxt='# '+'\t'.join(datatag)+'\n';
  ii=0;
  for fn in entrylist:
    if(ii%everynlines==0): print(headertxt, end='', file=outfile);
    for tag in datatag:
      print(str(datadict[fn][tag])+'\t', end='', file=outfile);
#    for tag in datadict[fn]:
#      if(tag not in datatag):
#       print(str(datadict[fn][tag])+'\t', end='', file=outfile);
    print(file=outfile);
    ii+=1;

######################
def InputDataInitWrite(inputdata=None, action=None, taglist=None, mode='w', select=None, options=None, optfiles=[], instr=None, readheader=None, readdatabase=None, readjustfile=None, forceMJD=False, statkey=None, statndigits=2, statsingletag=None, statoverride=False, outfile=None, style='all', atleast=None, datatag=None, newtag=None, verb=False):
  """Initialize input data and write them down in a file.
See documentation for:
  InputDataInitialize
  InputDataWrite


Parameters
----------
    inputdata : str, None
        Input file
    taglist : list
        List of the tag of the info inside 'inputdata' input data.
    mode : str
        Mode for the creation of the internal data: 'w' to create a new, 'a' to append/update
    select : str 
        Selection options to discharge images without mandatory caracteristics).
    optfiles : list
        List of option files
    readheader : Bool
        Flag to determine if to read image headers, or just the input file
    readdatabase : Bool
        Flag to determine if to read the internal database, or just the input file
    readjustfile : bool
        Flag to determine if to read just the input file (if True, it sets readdatabase and readjustfile to False);
    forceMJD : bool
        If the MJD has to be recalculates even if there is a valid value
    outfile : str, None
        Filename for inputdata storage archive.
    style : str
        Style for the storing of InputData
    datatag : None, list
        List of the tags of data that has to be write down. None for SkZp_Par['datatag']
    newtag : dict,None
        Dictionary with the definition of data field not present in datadict, but included in datatag. The key must be the tag name, the values a callable that takes as input the input data dictionary of the entry.
    verb : bool
        Enable full verbosity
""";
  _name_='InputDataInitWrite';

  # InputDataInitialize(inputdata=None, action=None, taglist=None, mode='w', select=None, options=None, optfiles=[], instr=None, readheader=None, headeroverride=None, readdatabase=None, readjustfile=None, forceMJD=False, statkey=None, statndigits=2, statsingletag=None, statoverride=False, verb=True):
  InputDataInitialize(inputdata=inputdata, action=action, taglist=taglist, mode=mode, select=select, options=options, optfiles=optfiles, instr=instr, readheader=readheader, readdatabase=readdatabase, readjustfile=readjustfile, forceMJD=forceMJD, statkey=statkey, statndigits=statndigits, statsingletag=statsingletag, statoverride=statoverride, verb=verb);
  # InputDataWrite(output=None, style='all'):
  InputDataWrite(outfile=outfile, mode='w', style=style, atleast=atleast, datatag=datatag, entrylist=bpar.SkZp_Par['runlist'], newtag=newtag ); #, datadict=None, ):
  
InputDataInitializeWrite=InputDataInitWrite;
