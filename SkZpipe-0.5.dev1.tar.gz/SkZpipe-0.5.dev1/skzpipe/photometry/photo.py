import os, subprocess, sys, shutil, math, re, time
import datetime, glob, fileinput, tarfile, copy
import tempfile, traceback

from ..exceptions import *
from ..parameters  import basicpar as bpar
from ..parameters import options as _opt
from ..parameters.classes import bclasses
from ..parameters.classes import fileclass 
from .. import functions as funct




############
#Photo_Proc#
############



class PhotoProc(bclasses.Image):
  """Class to process an image using DAOPhot. Subclass of PhotoProc.

Parameters
----------
    data : dict
        Dictionary with  information about the image
    runtype : str
        Name of the type of processing to apply.
    flag : str
        Flag for
    options : dict
        Dictionary with options as in internal option database

Attributes
----------


""";
  SkZp_Opt={};
  fn=None;
  psfhwhm=(0,0);
  offx=None;
  offy=None;
  step='';
  runtype='';
  mstep=False;
  auto=True;

  lockfile='';
  lock=False;
  niter=-1;
  logfile={};
  oldbkup='';
  #outxt,runtime,runtimeT=[],[],[];
  stdout=bpar.SkZp_Par['stdout'];
  stderr=bpar.SkZp_Par['stderr'];
  error=None;

  psfopt='';
  fitt=0;
  firstap=0;
  var=0;
  maxapmag=0;
  PickCounter={};
  PsfCounter={};
  nstar={'tot':0, 'psf0':0, 'psf':0};
  #PsfLst=[];
  newstar=False;
  newstarfile='';
  suffD={};

 ###
  def OptionGet(self, option=None, verb=True, raisexc=True):
    """Method version of options.OptionGet to use the class copy of options""";
    return _opt.OptionGet(option=option, verb=verb, optiondb=self.SkZp_Opt, raisexc=raisexc);

  def OptionPrint(self, option=None, verb=True):
    """Method version of options.OptionPrint to use the class copy of options""";
    return _opt.OptionPrint(option=option, verb=verb, optiondb=self.SkZp_Opt);

  def OptionSet(self, option=None, value=None, optdict=None):
    """Method version of options.OptionSet to use the class copy of options""";
    return _opt.OptionSet(option=option, value=value, optdict=optdict, optiondb=self.SkZp_Opt);

  def OptionFixCheck(self, raisexc=True):
    """Method version of options.OptionFixCheck to use the class copy of options""";
    return _opt.OptionFixCheck(optiondb=self.SkZp_Opt, raisexc=raisexc);
  def OptionPhotoFix(self, raisexc=True):
    """Method version of options.OptionPhotoFix to use the class copy of options""";
    return _opt.OptionPhotoFix(optiondb=self.SkZp_Opt, raisexc=raisexc);
  
 ###

  def SetLocSkZp_Opt(self, options=None, reset=False):   #RAISE SkZpipeErr
    """Set the local copy of option database

Parameters
----------
    options : dict
        Additional options to be set
    reset : bool
        Flag to reset an already existing class option database

""";
    if(self.SkZp_Opt):
      if(not reset):
        print("Class options already set. Use parameter `reset` to reset them or OptionSet method.", file=self.stdout);
        return;
    self.SkZp_Opt=copy.deepcopy(_opt.SkZp_Opt);
    #Reading options from image_name.opt
    _opt.OptionReadFile(self.fname+".opt", optiondb=self.SkZp_Opt);
    #Reading options passed during creation
    self.OptionSet(optdict=options);
    self.OptionPhotoFix();
      

#####

  def __init__(self, data=None, runtype='photo', flag='', options=None):
    """Initializing an object of Class PhotoProc

""";
    super().__init__(data);

    self.fn=self.fname;
   #deepcopy of SkZp_Opt and set opt for the image
    self.SetLocSkZp_Opt(options=options);

    self.stdout=bclasses.OutputPipe(otype='out');
    self.stderr=bclasses.OutputPipe(otype='err');

    self.suffD={'img':self.SkZp_Opt['S']['fitsextension'], 'src':None, 'aph':None, 'psf':None, 'fph':None, 'imgs':None, 'fileclass':fileclass.basefile.PhotoFile};

    if(os.path.exists(self.fn+".SKIP")):
      raise SkZpipeSkip("", exclocus=self.fn);
    if(not os.path.exists(self.fn+self.suffD['img'])):
      raise IOError("!!!ERROR: The image {:}{:} doesn't exist!".format(self.fn, self.suffD['img']));
    if(self.fwhm<=0): raise ValueError(self.fn+" has a no-positive FWHM");
      

    if(re.search(self.suffD['img']+'$', self.fn)): self.fn=self.fn.split(self.suffD['img'])[0];

#    self.fns=self.fn+self.suffD['imgs'];
    self.outxt=[];
    self.runtime=[];
    self.runtimeT=[];
    self.logfile={};
    self.PickCounter={};
    self.PsfCounter={};
    self.nstar={'tot':0, 'psf0':0, 'psf':0};


    if(self.hgd==None): self.hgd=0;
    if(self.gain==None): self.gain=0;
    if(self.ron==None): self.ron=0;


    hgdM,gainM,ronM={},{},{}
    if(self.hgd==0):
      if(self.chip in hgdM):
        self.hgd=hgdM[self.chip]
      elif("{}:{}@{}".format(self.chip,self.filter,self.exptime) in hgdM):
        self.hgd=hgdM["{}:{}@{}".format(self.chip,self.filter,self.exptime)];
    if(self.hgd==0):
      raise SkZpipeError("High good datum has a wrong value <{}>".format(self.hgd), exclocus=self.fn);

    if(self.gain==0):
      if(self.chip in gainM):
        self.gain=gainM[self.chip]
      elif("{}:{}@{}".format(self.chip,self.filter,self.exptime) in gainM):
        self.gain=gainM["{}:{}@{}".format(self.chip,self.filter,self.exptime)];
    if(self.gain==0):
      raise SkZpipeError("Gain has a wrong value <{}>".format(self.gain), exclocus=self.fn);

    if(self.ron==0):
      if(self.chip in ronM):
        self.ron=ronM[self.chip]
      elif("{}:{}@{}".format(self.chip,self.filter,self.exptime) in ronM):
        self.ron=ronM["{}:{}@{}".format(self.chip,self.filter,self.exptime)];
    if(self.ron==0):
      raise SkZpipeError("Ron has a wrong value <{}>".format(self.ron), exclocus=self.fn);
  
    ##STARTING OPT###

    self.lockfile=self.fn+self.SkZp_Opt['S']['lockext'];
    if('force' in flag):
      funct.clean_file([self.lockfile]);
  ###END _INIT_####


#  def UpdateStoreFile(self):  #OUTXT
#    with open(self.fn+self.SkZp_Opt['S']['SkZp_log'], "a") as f_tmp:    #SkZpLOG 
#      if(self.runtype=='psfcal'):
#        f_tmp.write("{:8} {:d}   {:f}   {}\n".format(self.step, self.niter, self.PsfCounter['chi2'], datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')));
#      elif(self.runtype=='srclst'):
#        f_tmp.write("{:8} {:d}   {:f}   {}\n".format(self.step, self.niter,                       0, datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')));
      
    
  def LockRun(self):
    if(os.path.exists(self.lockfile)):
      raise SkZpipeError("it seems that there is already a SkZp_pipeline running for the file {}!".format(self.fn), exclocus=self.fn);
    with open(self.lockfile, "w") as f_tmp:
      self.lock=True;
      f_tmp.write("1");
    
  def UnlockRun(self):
    if(self.lock):
      funct.clean_file([self.lockfile]);  ### MULTISTEP
      self.lock=False;

  def StoreLog(self):
    if(self.logfile):
      list_log=[];
      for tag in self.logfile:
        if(os.path.exists(self.logfile[tag])): list_log.append(self.logfile[tag]);
      if(list_log):
        if(self.error or self.SkZp_Opt['Flg']['debugging:log']):
          with tarfile.open('Log.{}.{}_{}{:02d}_{}.tar.bz2'.format(self.fn, self.runtype, self.step, self.niter, datetime.datetime.now().strftime('%Y%m%d%H%M%S')), 'w:bz2') as tarlog:
            for logf in list_log:
              tarlog.add(logf)
        funct.clean_file(list_log);
      self.logfile.clear();
  
  def close(self):
    if(self.fn):
      self.StoreLog();
      runtime=sum(self.runtimeT);
      print(runtime,":",self.runtimeT, file=self.stdout);
      self.UnlockRun();
    self.fn=None;
    self.stdout.close();
    self.stderr.close();

  def exit_right(self):
    """Exit with success
""";
    if(self.fn):
      if(self.runtype == 'psfcal'):
        if(self.psfhwhm[0]>0 and self.psfhwhm[1]>0):
          if('PSFFWHM'  in bpar.SkZp_Par['datatag']): funct.InputDataEntryUpdate(entry=self.fn, newdata={'PSFFWHM': round(sum(self.psfhwhm),4) });
          if('PSFELLIP' in bpar.SkZp_Par['datatag']): funct.InputDataEntryUpdate(entry=self.fn, newdata={'PSFELLIP':round(1-min(self.psfhwhm)/max(self.psfhwhm), 6) }) ;
        if(not os.path.exists(self.fn+self.SkZp_Opt['S']['photo:psf:done'] )):
          with open(self.fn+self.SkZp_Opt['S']['photo:psf:done'], 'w') as f_tmp:
            f_tmp.write("{}\n".format(self.PsfCounter.get('chi2')));
      elif(self.runtype == 'srclst'):
        shutil.copy2(self.fn+self.suffD['fph'], self.fn+self.SkZp_Opt['S']['photo:ext:srclst']);
        if(not os.path.exists(self.fn+self.SkZp_Opt['S']['photo:srclst:done'] )):
          with open(self.fn+self.SkZp_Opt['S']['photo:srclst:done'], 'w') as f_tmp:
            f_tmp.write("{lenf}\n".format(lenf=funct.get_num_lines(self.fn+self.SkZp_Opt['S']['photo:ext:srclst'])));

  def exit_wrong(self):
    """Exit with failure
""";
    if(self.fn):
      if(self.SkZp_Opt['Flg']['debug']): print("CHECK RUNTYPE", self.runtype,  "\nCHECK STEP", self.step, file=self.stdout)
      if(self.runtype=='psfcal'): #If to calculate PSF
        funct.clean_file([(self.fn,self.suffD['fph']), (self.fn,self.suffD['psf'])], suff='_dbg' if(self.SkZp_Opt['Flg']['debug']) else None);
      elif(self.runtype=='srclst'): #if to calculate source list
        funct.clean_file([(self.fn,self.SkZp_Opt['S']['photo:ext:srclst'])], suff='_dbg' if(self.SkZp_Opt['Flg']['debug']) else None);
      elif(self.runtype=='photo'): #if to obtain photometry
        if(self.step=='GetFph'):                #psf-fitting
          funct.clean_file([(self.fn,self.SkZp_Opt['S']['photo:ext:fitting'])], suff='_dbg' if(self.SkZp_Opt['Flg']['debug']) else None);
        elif(self.step=='GetAph'):              #aperture
          funct.clean_file([(self.fn,self.SkZp_Opt['S']['photo:ext:aperture'])], suff='_dbg' if(self.SkZp_Opt['Flg']['debug']) else None);


  def __exit__(self, exc_type, exc_value, exc_tb):
    if(exc_type!=None):
      self.exit_wrong();
      self.close();
      return False;
    else:
      self.exit_right();
      self.close();

  def __enter__(self):
    return self;

#  def __del__(self):
#    self.close();

  def flush_out(self):
    self.stdout.flush();
    self.stderr.flush();
  ##END Special Methods###

  def SetOutput(self, output=None, default=None):
    """Return filename according two rules: if 'output' is not given, 'default' is used; if output starts with a dot ('.'), it will be used as extension and concatenate to the image name.

Parameters
----------
    output : str, None
        String with the filename or the extension.
    default : str, None
        String with the default value for filename or extension.

Return
------
    x : str
        Filename.
""";
    _name_='PhotoProc.SetOutput';
    if(output is None): output=default;
    if(not isinstance(output, str)): raise TypeError(_name_+": output must be  the filename or the extension with initial dot (e.g. .als)");
    if(output[0]=='.'): output=self.fn+output;
    return output;

  def ChangeRuntype(self, runtype=None):
    if(runtype):
      self.runtype=runtype;
      print("runtype set to", runtype, file=self.stdout);
      return self.runtype;

 ###
  def applymagcorr(self, suff=None, ftype=None, exptime=False, apcorr=False, atmext=(0,0), extra=(0,0), output='', outsuff=''):
    """Apply all the classical magnitude correction: exposure time, airmass correction, aperture correction. It is possible to apply an additional extra correction.

Parameters
----------
    suff : str
        Suffix of the file to which applying the corrections (this has to be given. 
    ftype : 
        File type (if the extension is not standard).
    exptime : bool
        Flag to determine if to apply exposure time correction (value obtain from tag:EXPTIME)
    apcorr : bool
        Flag to determine if to apply aperture correction (value obtain from tag:APCORR)
    atmext : float, tuple of float
        Atmospheric extinction coefficient and its error to be used for the airmass correction (0 for no correction).
    extra : float, tuple of float
        Additional correction that is add to the source magnitude
    output : str
        Name of the file where store the corected photometry.
    outsuff : str
        Suffix add to the input name if `output` is not provide. Default `suff`+'_0'
""";
    _name_='PhotoProc.applycorrection';
    if(not isinstance(suff, str)): raise TypeError(_name_+": `suff` must be a string <{}>".format(repr(suff)));
#    if(not isinstance(ftype)): raise TypeError(_name_+": `` must be a <{}>".format());
    if(not isinstance(exptime, bool)): raise TypeError(_name_+": `exptime` must be a bool <{}>".format(repr(exptime)));
    if(not isinstance(apcorr, bool)): raise TypeError(_name_+": `apcorr` must be a bool <{}>".format(repr(apcorr)));
    if(not isinstance(atmext, (float, tuple))): raise TypeError(_name_+": `atmext` must be a float or a tuple of two floats <{}>".format(repr(atmext)));
    if(isinstance(atmext, float)): atmext=(atmext,0.);
    if(not isinstance(extra, (int,float, tuple))): raise TypeError(_name_+": `extra` must be a float or a tuple of two floats <{}>".format(repr(extra)));
    if(isinstance(extra, float)): extra=(extra,0.);
    if(output is not None and not isinstance(output, str)): raise TypeError(_name_+": `output` must be a string <{}>".format(repr(output)));
    if(not isinstance(outsuff, str)): raise TypeError(_name_+": `outsuff` must be a string <{}>".format(repr(outsuff)));

    if(not output):  output=self.fn+(outsuff if(outsuff) else suff+'_0');

    error=0;
    if(exptime):
        if(not self.exptime or not isinstance(self.exptime, float)): raise ValueError(_name_+": 'exptime' has wrong value <{}>".format(self.exptime), exclocus=self.fname);
        exptime= 1;
    else: exptime= 0;
    if(apcorr):
        if(not self.apcorr or not isinstance(self.apcorr, tuple)): raise SkZpipeError(_name_+": 'apcorr' has wrong value<{}>".format(self.apcorr), exclocus=self.fname);
        apcorr= 1;
    else: apcorr= 0;
    corr=exptime*2.5*math.log(self.exptime, 10) + apcorr*self.apcorr[0]  -atmext[0]*self.airmass +extra[0];
    error=extra[1];

    with self.suffD['fileclass'](ftype=ftype, fname=self.fn+suff) as phofile:
      phofile.read();
      phofile.magshift(magshift=corr, error=error);
      phofile.writefile(output, overwrite=True);
    print("applying mag corr for:", "exptime {:.6f};".format(2.5*math.log(self.exptime, 10)) if(exptime) else'', "apcorr {};".format(self.apcorr[0]) if(apcorr) else'', "airmass {};".format(-atmext[0]*self.airmass) if(atmext) else'', "other {};".format(extra[0]) if(extra[0]) else'',file=self.stdout);




