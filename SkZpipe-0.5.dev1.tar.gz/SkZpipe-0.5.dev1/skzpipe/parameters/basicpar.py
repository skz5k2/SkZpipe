
import os, re, collections, sys;

from ..exceptions import *

########################
##  READING FUNCTIONS ##
########################
def RF_dict_obj(txt='', vobj=str, kobj=str):
  tmpd=dict( tuple(y.split(':')) for y in re.split(";|,",txt) );
  retd={};
  for key,val in tmpd.items():
    retd[kobj(key)]=vobj(val);
  return retd;

def isnumber(x):
  try:
    float(x);
    return True;
  except (ValueError,TypeError):
    return False;





##################
##  PARAMETERS  ##
##################
#Declarations
SkZp_Par={'_name_':'SkZp_Par'};   SkZp_Par['_doc_']={'_name_':'SkZp_Par:_doc_'};
SkZp_ParDef={'_name_':'SkZp_ParDef'}; SkZp_ParDef['_doc_']={'_name_':'SkZp_ParDef:_doc_'}; 
#SkZp_ParTxT={'_name_':'SkZp_ParTxT'}; SkZp_ParTxT['_doc_']={'_name_':'SkZp_ParTxT:_doc_'}; 

DAO_Par={'_name_':'DAO_Par'};  DAO_Par['_doc_']={'_name_':'DAO_Par:_doc_'};

#########################

SkZp_Par['_skeys_']=['_funct_', '_name_', '_doc_', '_keys_', '_type_'];

#Definitions

SkZp_Par['datatag0']=['NAME', 'FWHM', 'ENTRYTYPE'];
SkZp_Par['datatag0missing']=set();
SkZp_ParDef['datatag']=SkZp_Par['datatag0']+['HIGH', 'GAIN', 'RON', 'CHIP', 'EXPTIME', 'FILTER', 'PSFFWHM', 'PSFELLIP', 'AIRMASS', 'SKY', 'MJD', 'NIGHT', 'DATE', 'TIME', 'RA', 'DEC', 'INSTRUMENT', 'OBJECT', 'MAGZPT', 'NX', 'NY', 'BITPIX', 'EXPID', 'IMGQUAL', 'OBSSET', 'SCALE', 'TELESCOPE', 'SITENAME', 'SITEALT', 'SITELAT', 'SITELONG', 'EQUINOX', 'STKOFF', 'AV,SM', 'DATASEC', 'OVERSCAN', 'IMGSTAT', 'APCORR', 'SKZP_FLG'];

SkZp_Par['datatag']=[];    SkZp_Par['_doc_']['datatag']="""List of tag used in 'inputdata'
  Usable tags:
Mandatory:
  NAME       = name of the image witout extension .fits (This has to be present)
  FWHM       = seeing/fwhm (This has to be present)
  ENTRYTYPE  = type of the entry ( see parameter 'entrytypelist')
Following:
  GAIN       = gain
  RON        = read-out noise in e-
  HIGH       = High Good Datum
  CHIP       = number of the sensor
  EXPTIME    = exposure time in sec
  FILTER     = filter
  PSFFWHM    = FWHM measured with PSF calculation
  PSFELLIP   = Ellipticity (1-b/a) measured with PSF calculation
  AIRMASS    = airmass
  SKY        = Sky level
  MJD        = Julian date
  NIGHT      = number of observation night
  DATE       = observation date
  TIME       = observation time
  RA         = right ascension of the pointing
  DEC        = declination of the pointing
  INSTRUMENT = instrument used
  OBJECT     = Description of the observation, object of the observation (check to remove the filter name, since it is stored with its tag)
  MAGZPT     = magnitude zero point
  NX         = number of columns
  NY         = number of rows
  EXPID      = identification of the exposure
  IMGQUAL    = quality of the image
  STKOFF     = stack offset from master frame
  AV,SM      = averaged,summed value for DAOPhot:find
""";
SkZp_Par['datatagtype']={**dict( (tag,str) for tag in ('NAME', 'ENTRYTYPE', 'CHIP', 'FILTER', 'DATE', 'TIME', 'AV,SM', 'INSTRUMENT', 'STKOFF', 'EXPID', 'OBJECT', 'OBSSET', 'OFFSET', 'OFFSETXY', 'TELESCOPE', 'SITENAME', 'EQUINOX', 'DATASEC', 'IMGSTAT') ),
                         **dict( (tag,float) for tag in ('FWHM', 'GAIN', 'RON', 'HIGH', 'EXPTIME', 'PSFFWHM', 'PSFELLIP', 'AIRMASS', 'SKY', 'MJD', 'MAGZPT', 'RA', 'DEC', 'SITEALT', 'SITELAT', 'SITELONG' )),
                         **dict( (tag,lambda x: int(float(x))) for tag in ('NX', 'NY', 'BITPIX', 'IMGQUAL', 'NIGHT') ),
                         **dict( (tag,lambda x: x if(isinstance(x,str)) else ';'.join(x)) for tag in ('SCALE', 'OVERSCAN', 'APCORR') ),
                        };
#                         **dict((tag,float) for tag in ('FWHM':3, 'GAIN':6, 'RON':6, 'HIGH':6, 'EXPTIME':6, 'PSFFWHM':6, 'PSFELLIP':6, 'AIRMASS':6, 'SKY':6, 'MJD':6, 'MAGZPT':6, 'RA':6, 'DEC':6, 'SITEALT':6, 'SITELAT':6, 'SITELONG':6)),
SkZp_Par['_doc_']['datatagtype']="""Dictionary with for each tagname with information to handle the tag value:
    string : the tag value will be processed with str.format method.
    callable : the tag value will be processed as parameter.""";

SkZp_Par['entrytypelist']=['raw', 'image:sci', 'image:std','stack', 'mosaic', 'bias', 'dark', 'cat:photo', 'cat:std'];                 SkZp_Par['_doc_']['entrytypelist']="List of valid values for 'ENTRYTYPE' tag";

SkZp_ParDef['datadict']=dict(zip(SkZp_ParDef['datatag'], [None]*len(SkZp_ParDef['datatag'])));
SkZp_Par['_doc_']['def:datadict']="Dictionary with the default values of tag in SkZp_ParDef['datatag']";

inputdata,inputlist,runlist={},[],[];
SkZp_Par['inputdata']={};                         SkZp_Par['_doc_']['inputdata']="Dictionary with the input data for each image";
SkZp_Par['inputlist']=[];                         SkZp_Par['_doc_']['inputlist']="Ordered list of the images in 'inputdata'";
SkZp_Par['runlist']=[];                           SkZp_Par['_doc_']['runlist']="Ordered list of the images to process (subset of 'inputlist')";

SkZp_Par['inputfile']=[];                         SkZp_Par['_doc_']['inputfile']="Ordered list of input files used to create 'inputdata'";

SkZp_Par['initializingflag']=False;               SkZp_Par['_doc_']['initializingflag']="""If the data have been initialized. To avoid a second initialization""";
SkZp_Par['saferunbit']=1;                    SkZp_Par['_doc_']['saferunbit']="""Bit-flag for safety of the run, calculated from option 'saferun'.""";

SkZp_Par['counter']={'db_retr':0};                SkZp_Par['_doc_']['counter']="Dictionary of counters";

SkZp_Par['instruments']={};                       SkZp_Par['_doc_']['instrument']="Dictionary with the name of the instruments used for the data and the number of images associated to them";
SkZp_Par['store4later']={};                       SkZp_Par['_doc_']['store4later']="Dictionary with as key  a identifier (e.g. the name of the variable), as value the object associated to that identifier. A store to avoid to recalculate periodically certain objects. It is reset at each full initialization.";

### OPTION FILES ##
SkZp_Par['optfilenames']=["SkZpipe.opt", "skzpipe.opt", "SkZ_pipeline.opt"];   SkZp_Par['_doc_']['optfilenames']="List with the filenames of the basic files with options";
SkZp_Par['optfilelist']=[];                       SkZp_Par['_doc_']['optfilelist']="List with the names option files in reading order.";
SkZp_Par['optfiledata']={};                       SkZp_Par['_doc_']['optfiledata']="Dictionary with the option inside the read option files.";
SkZp_Par['_doc_']['optfile']="""Example of option file""";
SkZp_ParDef['optfile']="""
#instrument=None
#optfiles=[ADDITIONAL OPTFILE]

#readdatabase=0
#inputdata:readheader=0
#readjustfile=1
#hidestandarderror=1
#debug=1

#chipselect=area:ra,dec,radius
#maxnumproc=0

#photo:thre:psfcal=3
#photo:thre:srclst=4
#photo:thre:photo=3
#photo:Steps:psfcal=Ground,AddFph,AddFph,AddFph,Refine
#photo:Steps:srclst=Ground,AddFph,AddFph,AddFph,Refine
#photo:Steps:photo=GetFph
#timeout=allstar:36000

#photo:psf:starinit=400
#photo:psf:starmax=200
#photo:psf:starmin=50
#photo:psf:psfradius=15
#photo:DAO:varpsf=-1,1,2,3
#photo:DAO:psfdef=MOFFAT35
#photo:DAO:psfother=MOFFAT25,PENNY1,MOFFAT15,PENNY2,GAUSSIAN,ALLPSF
#photo:DAO:psfothergood=2

#allstarinput=nei
#workname=%d

#stackbytag=[TAG]
#tackmatchcreate=[MODE]
""";
#####

### OUTPUT ##
SkZp_Par['errorhistory']={};    SkZp_Par['_doc_']['errorhistory']=""".""";
SkZp_Par['errorlist']=[];    SkZp_Par['_doc_']['errorhistory']="""List of entries that had problems during the last procedure""";

SkZp_Par['stdout']=sys.stdout;    SkZp_Par['_doc_']['stdout']="""Object used as standard output""";
SkZp_Par['stderr']=sys.stderr;    SkZp_Par['_doc_']['stderr']="""Object used as standard error""";

SkZp_Par['mp:nproc']=None;    SkZp_Par['_doc_']['mp:nproc']="""number of processor used""";
SkZp_Par['mp:availmemfrac']=0.85;   SkZp_Par['_doc_']['mp:availmemfrac']="""Fraction of available memory to use""";

SkZp_Par['chipheaderext']='.chdr';   SkZp_Par['_doc_']['chipheaderext']="""Extension for header of the chip""";
SkZp_Par['mosheaderext']='.mhdr';   SkZp_Par['_doc_']['mosheaderext']="""Extension for header of the mosaic""";

SkZp_Par['charconversion']={'.':'_', ' ':'_', '%d': lambda :os.path.basename(os.getcwd()) };       SkZp_Par['_doc_']['charconversion']="""For names: map to trasform certain characters or patterns""";

SkZp_Par['extractkey']=['##', 'area', 'part'];   SkZp_Par['_doc_']['extractkey']="""Keys used in the chip-extraction procedure""";


SkZp_Par['commentpattern']='#';   SkZp_Par['_doc_']['commentpattern']="""Pattern to mark a commented line in a file""";
SkZp_Par['headerfilepattern']=SkZp_Par['commentpattern'];   SkZp_Par['_doc_']['headerfilepattern']="""Pattern to mark a header line in a file""";

SkZp_Par['select']={};   SkZp_Par['_doc_']['select']=""".""";

SkZp_Par['stdfield']=None;   SkZp_Par['_doc_']['stdfield']="""Class to manage standard fields. It is set by photometry.standards submodules""";


SkZp_Par['checksleepbreak']={'daophot':2, 'allstar':10}; 
SkZp_Par['runtimewarn']={'daophot':3600, 'allstar':86400}; 
SkZp_Par['timeout']={'daophot':3600<<5, 'allstar':86400<<2}; 



#PHOTO
SkZp_Par['photo:StepL']=["Ground", "AddCoo", "AddFph", "ChkAdd", "Refine", "GetFph", "GetAph"];  SkZp_Par['_doc_']['photo:StepL']="""""";
SkZp_Par['photo:Steps']=dict(zip(SkZp_Par['photo:StepL'], range(len(SkZp_Par['photo:StepL']))));  SkZp_Par['_doc_']['photo:Steps']="""""";

SkZp_Par['photo:runtypelist']=['psfcal', 'photo','srclst'];  SkZp_Par['_doc_']['photo:runtypelist']="""""";

SkZp_Par['photo:hgdcorrection']=0.8;                    SkZp_Par['_doc_']['photo:hgdcorrection']="The high good value will be multiplied by this value to avoid fluctuations due to flat correction , for example";

SkZp_Par['script']={'pathscript':None, 'scriptname':None, 'scriptype':None, 'runtype':None, 'steps':None}; SkZp_Par['_doc_']['script']="""Information about the run script: path, name, type, runtype""";

