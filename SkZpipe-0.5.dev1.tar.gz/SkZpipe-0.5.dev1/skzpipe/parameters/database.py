import os, re, math, io, numpy;
from copy import deepcopy;
from collections import ChainMap

#from .basicpar import SkZp_ParDef
from .basicpar import *
from . import options  as _opt;

################
##  DATABASE  ##
################
SkZp_DB={'_name_':'SkZp_DB', '_doc_':{}};
SkZp_DB['listofinstruments']=['GSAOI', 'IMACS_Short-Camera', 'IMACS_Long-Camera', 'VIRCAM', 'VIRCAM:VVV', 'Direct/4Kx4K-4', 'DECam', 'Tucan'];

SkZp_DB['headerkey']={};      #Which cards read from headers and how
SkZp_DB['namepattern']={};    #How use format to generate name for extracted images or workname
SkZp_DB['chipselect']={};     #Info for chip selection
SkZp_DB['orientation']={};    #Spacial orientation of the camera
SkZp_DB['nopsfzone']={};      #Part of sensors not touse for PSF calculation
SkZp_DB['badpixelarea']={};   #part of the sensor with bap pixeles
SkZp_DB['passbands']={};      #List of passband of the cameras
SkZp_DB['alias']={};          #alias: for passbands, chip names, ...
SkZp_DB['gainronhigh']={};    #Gain, RON and high good values
SkZp_DB['SkZp_Opt']={};       #Option for specific instrument
SkZp_DB['obs_set_check']={};  #Check for data set (to avoid incomplete data subset)

###############
## HEADERKEY ##
###############
SkZp_DB['_doc_']['headerkey']="""Provide information about how to calculate the values of the tags in the inputdata dictionary using information in FITS header cards.
  They given as a dictionary where the key is the tag name and the value the way to determine the tag value from header information.
  They are grouped in 'mos' and 'chip', according to if they are present in the header of the chips or the hdu 0 (actually they will read toghether, so the separation is not really important).
  Card key names have to be without HIERARCH prefix, that is automatically eliminated by pyfits/internal functions.
  Callables must have as input the header dict, so the keys must be the card names, not the tags.

Format for the value
--------------------
  - a string with the name of the header dard key to be read.
  - a callable
  - a dictionary with:
    'cards' : list of str
        A list of cards to use
    'rej' : list 
        A list of values to reject card values.
    'eval' : str or callable
        A callable, that use the header dictionary ['cards' list] as input to produce the final value;
        A string that describe the action, as:
               'mean' for the mean of the values from 'cards'.
    'round' : int
        Number of decimal digit to leave for the rounding.
    'join' : str
        A character(string) that will be used to join the card values.
    'def'  : default values.

""";

def headerkeyread(tag=None, card=None, hdrinfo=None):
  """Get the value for a tag from header data.

Parameters
----------
    tag : str
        Name of the tag
    card : dict or str or callable
        Information on manage the header data
    hdrinfo : dict
        Header data

Returns
-------
    output : value
        Ruturn the value to be store in the tag. None for no value.

Provide information about how to calculate the values of the tags in the inputdata dictionary using information in FITS header cards.
  They given as a dictionary where the key is the tag name and the value the way to determine the tag value from header information.
  They are grouped in 'mos' and 'chip', according to if they are present in the header of the chips or the hdu 0 (actually they will read toghether, so the separation is not really important).
  Card key names have to be without HIERARCH prefix, that is automatically eliminated by pyfits/internal functions.
  Callables must have as input the header dict, so the keys must be the card names, not the tags.

Format for the value
--------------------
  - a string with the name of the header dard key to be read.
  - a callable
  - a dictionary with:
    'cards' : list of str
        A list of cards to use
    'rej' : list 
        A list of values to reject card values.
    'eval' : str or callable
        A callable, that use the header dictionary ['cards' list] as input to produce the final value;
        A string that describe the action, as:
               'mean' for the mean of the values from 'cards'.
    'round' : int
        Number of decimal digit to leave for the rounding.
    'join' : str
        A character(string) that will be used to join the card values.
    'def'  : default values.

""";
  _name_='database.headerkeyread';
  if(callable(card)): card={'eval':card};
  if(isinstance(card, str)): card={'cards':[card]};
  if(isinstance(card.get('cards'), str)): card={'cards':[card['cards']]};
  if(not isinstance(card, dict)): raise TypeError(_name_+": the definition of tag '{tag}' is wrong.".format(tag=tag));
 ##%%%%%##
  def _RDH_get(tag=None, cardL=None):
    """FitsHeaderInfoRetrieve internal command: convert the value of the tag to the right type (float or str) according to SkZp_Par['datatagtype']
  Parameters
  ----------
      tag : str, None
          Name of the tag
      cardL : list
          List with values to convert
  Return
  ------
      List of coverted card values
  """;
    _name_='_RDH_get';
    tmpv=[];
    for card in cardL:
      if(tag in SkZp_Par['datatagtype']):
        try:
          if(callable(SkZp_Par['datatagtype'][tag])):
            tmpv.append( SkZp_Par['datatagtype'][tag](card) );
          elif(isinstance(SkZp_Par['datatagtype'][tag], str)):
            tmpt=(card,) if(isinstance(card, str)) else tuple( card );
            tmpv.append( SkZp_Par['datatagtype'][tag].format(*tmpt) );
        except:
          tmpv.append(None);
      else:
        tmpv.append( card );
    return tmpv;
 ##%%%%%##


  outdata=None; #Initialization
  cardL=[hdrinfo[fkey] for fkey in card['cards'] if fkey in hdrinfo] if('cards' in card) else [];

  if('rej' in card):
    cardL=[val for val in cardL if val not in card['rej']]

  if(not cardL):
    if('eval' in card):  
      try:
        outdata=card['eval'](hdrinfo);
      except Exception as exc:
        outdata=None;
        if(_opt.OptionGet('debugging:log')): print('eval', tag, card, file=SkZp_Par['stderr']);
    if('def' in card and outdata is None):   outdata=card['def'];
  cardL=_RDH_get(tag, cardL);
  if('join' in card): outdata=card['join'].join([str(val) for val in cardL])
  elif('eval' in card):
    if(card['eval']=='mean'):      outdata=numpy.mean([float(x) for x in cardL]);
    elif(callable(card['eval'])): 
      try:
        outdata=card['eval'](hdrinfo);
      except Exception as exc:
        outdata=None;
        if(_opt.OptionGet('debugging:log')): print('eval', tag, card, file=SkZp_Par['stderr']);
    if('round' in card):
      outdata=  round(outdata, card['round']);
  elif(len(cardL)==1):  outdata=cardL[0];

  if('def' in card and  outdata is None):   outdata=card['def'];

  if(isinstance(outdata, str)):
    outdata=outdata.strip();
    if(outdata==''): outdata=None;

  return outdata;



SkZp_DB['headerkey'][None]={ 'mos':{'INSTRUMENT':'INSTRUME', 'OBJECT':'OBJECT', 'AIRMASS':'AIRMASS', 'RA':'RA', 'DEC':'DEC', 'FILTER':'FILTER', 'MJD':'MJD-OBS', 'DATE':'DATE-OBS', 'TIME':'TIME-OBS', 
                                   'EXPTIME':'EXPTIME', 'TELESCOPE':'TELESCOP', 'SITENAME':'SITENAME', 'SITEALT':'SITEALT', 'SITELAT':'SITELAT', 'SITELONG':'SITELONG', 'EQUINOX':'EQUINOX', 'EXPID': 'None'},
                           'chip':{'NX':'NAXIS1', 'NY':'NAXIS2', 'BITPIX':'BITPIX', 'GAIN':'EGAIN', 'RON':'ENOISE', 'SCALE':'SCALE', 'MAGZPT':'MAGZPT', 'OVERSCAN':{'join': ';', 'cards':['NOVERSCN','NBIASLNS']}, 'DATASEC':'DATASEC', 'BIASSEC':'BIASSEC', 'SKY': 'None' },
                          'datatag':SkZp_ParDef['datatag']};
 #GSAOI
SkZp_DB['headerkey']['GSAOI']={ 'mos':{'FILTER':{'rej':('Clear'), 'cards':['FILTER1','FILTER2']}, 'OFFSET':{'join': ';', 'cards':['POFFSET','QOFFSET']}, 'EXPID':'DATALAB', 'FOWLER':'LNRS', 'TELESCOPE':'TELESCOP', 'SITENAME':'OBSERVAT', 'SITEALT':{'def':2722}, 'SITELAT':{'def', -30.24075}, 'SITELONG':{'def', -70.7366933}},
                               'chip':{'CHIP':'FRMNAME', 'SCALE':{'join': ';', 'cards':['XSCALE','YSCALE']}, 'GAIN':'GAIN', 'RON':'RDNOISE'},
                              'datatag':['OFFSET'] };
 #Swope
SkZp_DB['headerkey']['Direct/4Kx4K-4']={ 'mos':{},
                                        'chip':{'DATE':'UT-DATE', 'TIME':'UT-TIME', 'CHIP':'OPAMP', 'FILTER':{'rej':['open','Open','Free_slot'], 'cards':'FILTER'}, 'RA':'RA-D', 'DEC':'DEC-D', 'OFFSET':{'join':';', 'cards':['CHOFFX','CHOFFY']}, 'BINNING':'BINNING', },
                                     'datatag':['OFFSET', 'BINNING', ] };

 #Baade
SkZp_DB['headerkey']['IMACS_Short-Camera']={ 'mos':{'DATE':'UT-DATE', 'TIME':'UT-TIME'},
                                        'chip':{'CHIP':'CHIP', 'FILTER':{'rej':['open','Open','Free_slot'],'cards':['FILTER']}, 'RA':'RA-D', 'DEC':'DEC-D', 'OFFSET':{'join':';', 'cards':['CHOFFX','CHOFFY']}, 'EXPID':'FILENAME',
                                                'ROTANGLE':'ROTANGLE', 'BINNING':'BINNING', 'DISPERSER':'DISPERSR', 'FOCUS':'DETFOCUS', 'READSPEED':'SPEED', },
                                     'datatag':['OFFSET', 'ROTANGLE', 'BINNING', 'DISPERSER', 'FOCUS', 'READSPEED', ] };
SkZp_DB['headerkey']['IMACS_Long-Camera']={ 'mos':{'DATE':'UT-DATE', 'TIME':'UT-TIME'},
                                        'chip':{'CHIP':'CHIP', 'FILTER':{'rej':['open','Open','Free_slot'],'cards':['FILTER']}, 'RA':'RA-D', 'DEC':'DEC-D', 'OFFSET':{'join':';', 'cards':['CHOFFX','CHOFFY']}, 'EXPID':'FILENAME',
                                                'ROTANGLE':'ROTANGLE', 'BINNING':'BINNING', 'DISPERSER':'DISPERSR', 'FOCUS':'DETFOCUS', 'READSPEED':'SPEED', },
                                     'datatag':['OFFSET', 'ROTANGLE', 'BINNING', 'DISPERSER', 'FOCUS', 'READSPEED', ] };

 #VIRCAM
SkZp_DB['headerkey']['VIRCAM']    ={ 'mos':{'DATE':(lambda hdrd: hdrd['DATE-OBS'].split('T')[0] ), 'TIME':(lambda hdrd: hdrd['DATE-OBS'].split('T')[1] ), 'TILE':'OBJECT',
                                           'AIRMASS':{'eval':'mean', 'cards':['ESO TEL AIRM START','ESO TEL AIRM END'], 'round':6}, 'FILTER':'ESO INS FILT1 NAME',
                                            'DIT':'ESO DET DIT', 'NDIT':'ESO DET NDIT', 'OFFSET':'OFFSET_I', 'POSANG':'ESO TEL POSANG', 'OBNAME':'ESO OBS NAME', 'SITELAT':'ESO TEL GEOLAT', 'SITELONG':'ESO TEL GEOLON', 'SITEALT':'ESO TEL GEOELEV', 'SITENAME':{'def':'PARANAL'}, 'SCALE':{'def':0.341}, 'TELESCOPE':{'def':'VISTA'}, }, 
                                    'chip':{'CHIP':'ESO DET CHIP NO', 'SUBSECT':(lambda hdrd: chr((((hdrd['ESO DET CHIP NO']-1)>>2)<<1)+int((hdrd['OFFSET_I']-1)/3)+ord('a')) ), },
                                 'datatag':['DIT', 'NDIT', 'OFFSET', 'POSNAME', 'TILE', 'OBNAME', 'SUBSECT'] };
 #VIRCAM:VVV
SkZp_DB['headerkey']['VIRCAM:VVV']=deepcopy(SkZp_DB['headerkey']['VIRCAM']);
SkZp_DB['headerkey']['VIRCAM:VVV']['mos'].update({'CASUVERS':'CASUVERS', 'ESOGRADE':'ESOGRADE', 'OBSTATUS':'OBSTATUS', 'OBTYPE':(lambda hdrd:  re.sub('\d', '', hdrd['ESO OBS NAME'])[0:2] ), 'OBSSET':(lambda hdrd:hdrd['ESO OBS NAME'][:4]) });
SkZp_DB['headerkey']['VIRCAM:VVV']['chip'].update({'GAINCOR':'GAINCOR', 'SKY':'SKYLEVEL', 'FWHM':'SEEING', 'ELLIPTIC':'ELLIPTIC', 'MAGZPT':'MAGZPT', 'FOV':{'join':'-', 'cards':['OBJECT','OFFSET_I','ESO DET CHIP NO']} });
SkZp_DB['headerkey']['VIRCAM:VVV']['datatag']=['GAINCOR', 'ELLIPTIC', 'DIT', 'NDIT', 'OFFSET', 'POSNAME', 'TILE', 'OBNAME', 'OBTYPE', 'SUBSECT', 'CASUVERS', 'ESOGRADE', 'OBSTATUS'];

 #DECAM
SkZp_DB['headerkey']['DECam']={ 'mos':{'EQUINOX':'TELEQUIN', 'DIMMSEE':'DIMMSEE', 'MAGZERO':'MAGZERO', 'PHOTFLAG':'PHOTFLAG', 'EXPID':'RECNO', 'PROCTYPE':'PROCTYPE',
                                       },
                               'chip':{'CHIP':'EXTNAME', 'SKY':'SKYBRITE', 'SKYSIGMA':'SKYSIGMA'},
                            'datatag':['DIMMSEE', 'MAGZERO', 'PHOTFLAG', 'PROCTYPE',   'SKYSIGMA'] };

  #Tucan
SkZp_DB['headerkey']['Tucan']={ 'mos':{}, #'DATE':(lambda hdrd: hdrd['DATE-OBS'].split('T')[0] ), 'TIME':(lambda hdrd: hdrd['DATE-OBS'].split('T')[1] )},
                               'chip':{'ENTRYTYPE':'FRAME', 'FRAME':'FRAME', 'CCD-TEMP':'CCD-TEMP', 'DATE':(lambda hdrd: hdrd['DATE-OBS'].split('T')[0] ), 'TIME':(lambda hdrd: hdrd['DATE-OBS'].split('T')[1] ), 'CHIP':{'def':'X'}},
                            'datatag':['FRAME', 'CCD-TEMP'] };
##


############################
## EXTRACTING FROM MOSAIC ##
############################
##
###################################
## CHIP SELECTION
SkZp_DB['_doc_']['chipselect']="""Dictionary with keys 'part', 'pos', 'posang', 'reject' with callable to be used during chip selection procedure. """;
SkZp_DB['chipselect'][ 'VIRCAM'     ]= {'part':( lambda xdict: chr((((int(xdict['CHIP'])-1)>>2)<<1)+int((int(xdict['OFFSET'])-1)/3)+ord('a'))   ),
                                         'pos':( lambda xdict: ( 16.7*(((int(xdict['CHIP'])-1)%4)-1.5), 22.*(((int(xdict['CHIP'])-1)>>2)-1.5) ) ),
                                      'posang':( lambda xdict: (90-float(xdict['POSANG'])) ), };
SkZp_DB['chipselect'][ 'VIRCAM:VVV' ]= deepcopy(SkZp_DB['chipselect']['VIRCAM']);

def _DECam_chippos_(chip=None):
  chipgap, chipsize =(153, 201), (4096,2048);
  chippos0={ '1':(-3.0*(chipgap[0]+chipsize[0])*0.27/60,  0.5*(chipgap[1]+chipsize[1])*0.27/60),   '2':(-2.0*(chipgap[0]+chipsize[0])*0.27/60,  0.5*(chipgap[1]+chipsize[1])*0.27/60),   '3':(-(chipgap[0]+chipsize[0])*0.27/60, 0.5*(chipgap[1]+chipsize[1])*0.27/60),    '4':(0.0, 0.5*(chipgap[1]+chipsize[1])*0.27/60),   '5':((chipgap[0]+chipsize[0])*0.27/60, 0.5*(chipgap[1]+chipsize[1])*0.27/60),   '6':(2.0*(chipgap[0]+chipsize[0])*0.27/60, 0.5*(chipgap[1]+chipsize[1])*0.27/60),   '7':(3.0*(chipgap[0]+chipsize[0])*0.27/60, 0.5*(chipgap[1]+chipsize[1])*0.27/60),
 '8':(-2.5*(chipgap[0]+chipsize[0])*0.27/60,  1.5*(chipgap[1]+chipsize[1])*0.27/60),   '9':(-1.5*(chipgap[0]+chipsize[0])*0.27/60,  1.5*(chipgap[1]+chipsize[1])*0.27/60),  '10':(-0.5*(chipgap[0]+chipsize[0])*0.27/60,  1.5*(chipgap[1]+chipsize[1])*0.27/60),  '11':(0.5*(chipgap[0]+chipsize[0])*0.27/60, 1.5*(chipgap[1]+chipsize[1])*0.27/60),  '12':(1.5*(chipgap[0]+chipsize[0])*0.27/60, 1.5*(chipgap[1]+chipsize[1])*0.27/60),  '13':(2.5*(chipgap[0]+chipsize[0])*0.27/60, 1.5*(chipgap[1]+chipsize[1])*0.27/60),
'14':(-2.5*(chipgap[0]+chipsize[0])*0.27/60,  2.5*(chipgap[1]+chipsize[1])*0.27/60),  '15':(-1.5*(chipgap[0]+chipsize[0])*0.27/60,  2.5*(chipgap[1]+chipsize[1])*0.27/60),  '16':(-0.5*(chipgap[0]+chipsize[0])*0.27/60,  2.5*(chipgap[1]+chipsize[1])*0.27/60),  '17':(0.5*(chipgap[0]+chipsize[0])*0.27/60, 2.5*(chipgap[1]+chipsize[1])*0.27/60),  '18':(1.5*(chipgap[0]+chipsize[0])*0.27/60, 2.5*(chipgap[1]+chipsize[1])*0.27/60),  '19':(2.5*(chipgap[0]+chipsize[0])*0.27/60, 2.5*(chipgap[1]+chipsize[1])*0.27/60),
'20':(-2.0*(chipgap[0]+chipsize[0])*0.27/60,  3.5*(chipgap[1]+chipsize[1])*0.27/60),  '21':(-(chipgap[0]+chipsize[0])*0.27/60,  3.5*(chipgap[1]+chipsize[1])*0.27/60),  '22':( 0.0,  3.5*(chipgap[1]+chipsize[1])*0.27/60),  '23':((chipgap[0]+chipsize[0])*0.27/60, 3.5*(chipgap[1]+chipsize[1])*0.27/60),  '24':(2.0*(chipgap[0]+chipsize[0])*0.27/60, 3.5*(chipgap[1]+chipsize[1])*0.27/60),
'25':(-1.5*(chipgap[0]+chipsize[0])*0.27/60,  4.5*(chipgap[1]+chipsize[1])*0.27/60),  '26':(-0.5*(chipgap[0]+chipsize[0])*0.27/60,  4.5*(chipgap[1]+chipsize[1])*0.27/60),  '27':( 0.5*(chipgap[0]+chipsize[0])*0.27/60,  4.5*(chipgap[1]+chipsize[1])*0.27/60),  '28':(1.5*(chipgap[0]+chipsize[0])*0.27/60, 4.5*(chipgap[1]+chipsize[1])*0.27/60),
'29':(-(chipgap[0]+chipsize[0])*0.27/60,  5.5*(chipgap[1]+chipsize[1])*0.27/60),  '30':( 0.0,  5.5*(chipgap[1]+chipsize[1])*0.27/60),  '31':( (chipgap[0]+chipsize[0])*0.27/60,  5.5*(chipgap[1]+chipsize[1])*0.27/60)
 }
  if(not isinstance(chip,str) or not re.search('^[NS]', chip)): raise ValueError("Wrong value for chip name for DECam");
  ysign=1 if(chip[0]=='S') else -1;
  cid=chip[1];
  return (chippos0[cid][0], ysign*chippos0[cid][1]);
SkZp_DB['chipselect'][ 'DECam'      ]= {'pos': (lambda xdict: _DECam_chippos_(xdixt['CHIP'])), 'reject': (lambda xdict: True if(xdict['PROCTYPE']=='Resampled') else False), 'posang':(lambda xdict: xdict['POSANG'])};


SkZp_DB['_doc_']['obs_set_check']="""For each instrument, a callable to check for correct chip extraction values for several instruments. The callable should accept 2 parameters: list of dict (containing the extraction info), dict of dict (containing the header of HDU=0 of the mosaics)""";
def _VIRCAMVVV_obscheck(inputdata, mosinfo):
  obspS={}; # for each pawprint of OBS NAME, dict of set of chips
  obspL={}; # for each pawprint of OBS NAME, dict of list of members
  tilepS={};  #for each part (OFF of OBS), dict of set of chips
  tilepL={};  #for each part (OFF of OBS), dict of list of members
  for ii,inp in enumerate(inputdata):
#    if(not inp['outname']): continue;
   #get list of EXTNAME in the mosaic
    lstext=fits.listextname(inp['mosaic']); # For chip selection
    nhdu=len(lstext); # For chip selection
    obn  =headerkeyread('OBNAME', SkZp_DB['headerkey']['VIRCAM:VVV']['mos']['OBNAME'],  mosinfo[ inp['mosaic'] ] );
    tilen=headerkeyread('OBJECT', SkZp_DB['headerkey']['VIRCAM:VVV']['mos']['OBJECT'],  mosinfo[ inp['mosaic'] ] );
    offn =headerkeyread('OFFSET', SkZp_DB['headerkey']['VIRCAM:VVV']['mos']['OFFSET'],  mosinfo[ inp['mosaic'] ] );
    obsp ='{} {}'.format(obn. offn);
    tilep='{} {}'.format(tilen. offn);

    obspS.setdefault(obsp, set);
    obspL.setdefault(obsp, []);
    tilepS.setdefault(tilep, set);
    tilepL.setdefault(tilep, []);

    obspS[obsp].update(set(inp['chip']['#']));
    obspL[obsp].append(ii);
    tilepS[tilep].update(set(inp['chip']['#']));
    tilepL[tilep].append(ii);
  for obs in obspS:
    for ii in obspL[obs]:
      if(obspS[obs].issuperset(inputdata[ii]['chip']['#'])): inputdata[ii]['chip']['#']=tuple(obspS[obs]);
  if(_opt.OptionGet('image:select:uniform')):
    for tile in tilepS:
      for ii in tilepL[tile]:
        if(tilepS[tile].issuperset(inputdata[ii]['chip']['#'])): inputdata[ii]['chip']['#']=tuple(tilepS[tile]);


SkZp_DB['obs_set_check'][ 'VIRCAM:VVV' ]=_VIRCAMVVV_obscheck;






###################################
## PATTERN NAME
SkZp_DB['_doc_']['namepattern']=""" Definition of pattern to create filename. Pattern is defined by % followed by a character""";
SkZp_DB['namepattern'][ '-'          ]= {'%F':(lambda x : x)};
SkZp_DB['namepattern'][ None         ]= SkZp_DB['namepattern']['-'];
SkZp_DB['namepattern'][ 'VIRCAM'     ]= {'%F':(lambda x : x[3:9]+x[11:15])};
SkZp_DB['namepattern'][ 'VIRCAM:VVV' ]= deepcopy(SkZp_DB['namepattern']['VIRCAM']);

#####################################
## BAD PSF AREA
SkZp_DB['_doc_']['nopsfzone']="""Areas of the sensors not ideal for PSF calculation""";
SkZp_DB['nopsfzone'][ 'VIRCAM'     ]    =(lambda xdict:  '{}_{}_{}.npz'.format(str(xdict['OBJECT']), str(xdict['OFFSET']), str(xdict['CHIP']))  );
SkZp_DB['nopsfzone'][ 'VIRCAM:VVV' ]=SkZp_DB['nopsfzone']['VIRCAM'];

#####################################
## BAD PIXEL AREA

# {'type':'', 'x':, 'y':, 'wx':, 'wy':},
# {'type':'', 'x':, 'y':, 'wx':, 'wy':},  {'type':'', 'x':, 'y':, 'wx':, 'wy':},  {'type':'', 'x':, 'y':, 'wx':, 'wy':},  {'type':'', 'x':, 'y':, 'wx':, 'wy':},  {'type':'', 'x':, 'y':, 'wx':, 'wy':},
SkZp_DB['_doc_']['badpixelarea']="""Areas of the sensors that have surious issues and have to be removed from photometric file because the data inside are not good.
For each chip it is given a dictionary with keys:
    'bad': tuple
        Tuple of areas of bad pixels.
    'sugg' : tuple
        Tuple of areas with data of lesser quality that are suggested to be rejected.
The pixel areas are descrped by dictionary:
    'type' : str
        Type of the area:
          'box' : rettangular area centered on a point;
          'frame' : area along the border of the chip; use just 'wx' and 'wy';
          'ellipse' : elliptic area centered on a point.
    'x' : int or float
        X coordinate of the reference point.
    'y' : int or float
        Y coordinate of the reference point.
    'wx' : int or float
        Characteristic length along X axes
    'wy' : int or float
        Characteristic length along Y axes

""";

SkZp_DB['badpixelarea']['VIRCAM']={'1':{ 'bad':({'type':'box', 'x':1056, 'y':910, 'wx':47, 'wy':40},  {'type':'box', 'x':551, 'y':1042, 'wx':117, 'wy':62},  {'type':'box', 'x':368, 'y':1121, 'wx':57, 'wy':74},
                                               {'type':'box', 'x':483, 'y':1082, 'wx':130, 'wy':80},  {'type':'box', 'x':564, 'y':1017, 'wx':85, 'wy':28}, {'type':'box', 'x':423, 'y':1136, 'wx':69, 'wy':43},
                                               {'type':'box', 'x':472, 'y':1152, 'wx':74, 'wy':54},  {'type':'box', 'x':1019, 'y':858, 'wx':74, 'wy':69},  {'type':'box', 'x':1026, 'y':839, 'wx':53, 'wy':28}),
                                        'sugg':({'type':'frame', 'wx':60, 'wy':60}, ), 
   }};
SkZp_DB['badpixelarea']['VIRCAM:VVV']=deepcopy(SkZp_DB['badpixelarea']['VIRCAM']);




###################################
## LIST OF FILTER ALIAS
#List of standard names of passbands
##Standard Passband
SkZp_DB['_doc_']['passbands']="""Translation between filter name of the instruments and standard passband names (Almost a copy of alias:*:FILTER).
Used during standard calibration.
  '_wave_' : the internal database of the central wavelenth [nm] according to ADPS (The Asiago Database on Photometric Systems).
             Passband with same name and almost identical are not repeated. Otherwise common alias are used (as 'Rc' for R Cousins).
  None     : the list of the standard passsband names ordered by wavelength using data in '_wave_'.""";
SkZp_DB['passbands']['_wave_']={'SDSS':{'u':356, 'g':483, 'r':626, 'i':767, 'z':910},
'JOHNSON':{'U':360, 'B':440, 'V':550, 'R':700, 'I':900, 'J':1250, 'H':1620, 'K':2200, 'L':3400, 'M':5000, 'N':10000},
'COUSINS':{'Rc':647, 'Ic':787},
'BESSEL':{'Rb':643, 'Ib':806},
'STROMGREN':{'v':411, 'b':467, 'y':547}, 
'2MASS/UKIRT/UH2.2':{ 'Ks':2160, 'Z':882, 'Y':1031, 'Kp':2110,}, 
'WASHINGTON':{'C':391, 'Mw':509, 'T1':633, 'T2':789}, 
};
def PassbandDB():
  print("NAME  FILTER  L_EFF\n-------------------")
  for name,filters in SkZp_DB['passbands']['_wave_'].items():
    print(name);
    for flt,leff in filters.items():
      print("\t{fltr:5} {l_eff:5d}".format(fltr=flt, l_eff=leff));
    print();

_tmpd_=dict(ChainMap(*SkZp_DB['passbands']['_wave_'].values()));
SkZp_DB['passbands'][None]=sorted(_tmpd_, key=_tmpd_.get);

##Alias
SkZp_DB['_doc_']['alias']="""List of alias for header data instruments. Filters, chips, etc can have not standard name in the headers.
For the list of standard names see passbands:None""";
SkZp_DB['alias']['IMACS_Short-Camera'] ={'FILTER':{'Bessell_B2':'B', 'Bessell_V2':'V', 'Bessell_R2':'R', 'CTIO-I2':'I'} };
SkZp_DB['alias']['IMACS_Long-Camera']  ={'FILTER':{'Bessell_B1':'B', 'Bessell_V1':'V', 'Bessell_R1':'R', 'CTIO-I1':'I'} };
SkZp_DB['alias']['GSAOI']              ={'FILTER':{'Z_G1101':'Z', 'J_G1102':'J', 'H_G1103':'H', 'Kshort_G1105':'Ks', 'Kprime_G1104':'Kp', 'K_G1106':'K', 'BrG_G1122':'BrG', 'H2(1-0)_G1121':'H2_10', 'FeII_G1118':'FeII', 'Kcntshrt_G1111':'Kcs', 'CH4short_G1109':'CH4s'}, 
                                           'CHIP':{'GSAOI_Frame1':'1', 'GSAOI_Frame2':'2', 'GSAOI_Frame3':'3', 'GSAOI_Frame4':'4'} };
  #BAADE
SkZp_DB['passbands']['IMACS_Short-Camera']={'Bessell_B2':'B', 'Bessell_V2':'V', 'Bessell_R2':'R', 'CTIO-I2':'I'};
SkZp_DB['passbands']['IMACS_Long-Camera'] ={'Bessell_B1':'B', 'Bessell_V1':'V', 'Bessell_R1':'R', 'CTIO-I1':'I'};

#This create a reverse copy of the alias
#for instr in SkZp_DB['alias']:
#  for atype in SkZp_DB['alias'][instr]:
#    tmpd={};
#    for key,value in SkZp_DB['alias'][instr][atype].items():
#      tmpd[value]=key;
#    SkZp_DB['alias'][instr][atype].update(tmpd);

##########################
## GAINRONHIGH
  #GSAOI
SkZp_DB['gainronhigh']['IMACS_Short-Camera']={'HIGH':{'1':40000,   '2':56000,   '3':56000,   '4':39000, '5':57000, '6':44000, '7':40000, '8':57000},};

SkZp_DB['gainronhigh']['GSAOI']={'GAIN':{'1':2.434,   '2':2.010,   '3':2.411,   '4':2.644},
                                  #RON depends on the readout mode => Number of Non-destructive reads (tag:FOWLER)
                                  'RON':{'1':{2:26.53, 8:13.63, 16:10.22},
                                         '2':{2:19.10, 8: 9.85, 16: 7.44},
                                         '3':{2:27.24, 8:14.22, 16:10.61},
                                         '4':{2:32.26, 8:16.78, 16:12.79} },
                                 'HIGH':{'1':SkZp_Par['photo:hgdcorrection']*52400, '2':SkZp_Par['photo:hgdcorrection']*50250, '3':SkZp_Par['photo:hgdcorrection']*53700, '4':SkZp_Par['photo:hgdcorrection']*52300 }   };

  #VIRCAM
SkZp_DB['gainronhigh']['VIRCAM']={'GAIN':{'1':3.7,  '2':4.2,  '3':4.0,  '4':4.2,   '5':4.2,  '6':4.1,  '7':3.9,  '8':4.2,
                                          '9':4.6, '10':4.0, '11':4.6, '12':4.0,  '13':5.8, '14':4.8, '15':4.0, '16':5.0},
                                  'RON':{'1':23.9,  '2':24.4,  '3':22.8,  '4':24.0,   '5':24.4,  '6':23.6,  '7':23.1,  '8':24.3,
                                         '9':19.0, '10':24.9, '11':24.1, '12':23.8,  '13':26.6, '14':18.7, '15':17.7, '16':20.8},
                                 'HIGH':{'1': 32000 ,  '2': 32000 ,  '3': 32000 ,  '4': 32000 ,  '5': 32000 ,  '6': 32000 ,  '7': 32000 ,  '8': 32000 ,
                                         '9': 32000 , '10': 32000 , '11': 32000 , '12': 32000 , '13': 32000 , '14': 32000 , '15': 32000 , '16': 32000 }  };
  #VIRCAM:VVV
SkZp_DB['gainronhigh']['VIRCAM:VVV']=deepcopy(SkZp_DB['gainronhigh']['VIRCAM']);
SkZp_DB['gainronhigh']['VIRCAM:VVV'].update({'HIGH':{'1':19000.0,  '2':30800.0,  '3':29500.0,  '4':23000.0,  '5':16000.0,  '6':16000.0,  '7':18800.0,  '8':25000.0,
                                         '9':25000.0, '10':20000.0, '11':23000.0, '12':20000.0, '13':35000.0, '14':23000.0, '15':20000.0, '16':28000.0},
                                  'HIGHCORR':{'b':{'J'+'j':1.0600, 'H'+'j':1.0420, 'Ks'+'j':1.0000,  'Y'+'z':1.4160, 'Z'+'z':1.3770,  'Ks'+'v':1.0000},
                                              'd':{'J'+'j':1.2760, 'H'+'j':1.2940, 'Ks'+'j':1.3000,  'Y'+'z':1.5610, 'Z'+'z':1.5070,  'Ks'+'v':1.0000},
                                              'e':{'J'+'h':1.2760, 'H'+'h':1.1000, 'Ks'+'h':1.0000,  'J'+'j':1.2760,  'Ks'+'v':1.0000},} });
def VVV_HGD(datadict=None):
  return SkZp_Par['photo:hgdcorrection'] * (SkZp_DB['gainronhigh']['VIRCAM:VVV']['HIGH'][str(datadict['CHIP'])] * SkZp_DB['gainronhigh']['VIRCAM:VVV']['HIGHCORR'][ datadict['OBTYPE'][0] ][ datadict['FILTER']+datadict['OBTYPE'][1] ]-datadict['SKY']) +datadict['SKY'];



#############
## SKZ_OPT ##
#############
SkZp_DB['_doc_']['SkZp_Opt']="""Options for specific instrument or use.""";
SkZp_DB['SkZp_Opt']['GSAOI']={'photo:DAO:psfdef':'MOFFAT35', 'photo:DAO:psfother':['MOFFAT25', 'PENNY1', 'MOFFAT15', 'PENNY2', 'GAUSSIAN'], 'photo:DAO:psfothergood':2,
                           'photo:psf:starinit':500, 'photo:psf:starmax':400, 'photo:psf:starmin':100,
                           'photo:psf:psfradius':25, 'photo:in-outskyradius':11, 'photo:psf-inskyradius':3,
                           'photo:thre:psfcal':3, 'photo:thre:srclst':4, 'photo:DAO:varpsf':[-1,1,2,3], 'photo:DAO:allstarinput':'nei',
                           'photo:Steps:psfcal':["Ground", "AddFph", "AddFph", "AddFph", "Refine"], 'photo:Steps:srclst':["Ground", "AddFph", "AddFph", "AddFph", "Refine"],
                           'stack:match:makemode':['dao:|p20:/'],
                           };

SkZp_DB['SkZp_Opt']['VIRCAM:VVV']={'optfiles':['VVV-SkZpipe.opt', 'VSpipe.opt'], 'inputdata:file':'VVV_imgdata', 
                           'photo:DAO:psfdef':'MOFFAT35', 'photo:DAO:psfother':['MOFFAT25', 'PENNY1', 'PENNY2', 'GAUSSIAN', 'ALLPSF'], 'photo:DAO:psfothergood':1,
                           'photo:psf:starinit':400, 'photo:psf:starmax':250, 'photo:psf:starmin':50,
                           'photo:psf:psfradius':8, 'photo:in-outskyradius':11, 'photo:psf-inskyradius':3,
                           'photo:averagedsummed':'2,1', 'photo:thre:psfcal':3, 'photo:thre:srclst':4, 'photo:DAO:allstarinput':'nei', 'photo:DAO:varpsf':[-1,0,1,2],
                           'photo:Steps:psfcal':["Ground", "AddCoo", "AddFph", "ChkAdd", "Refine"], 'photo:Steps:srclst':["Ground", "AddFph", "AddFph", "Refine"],
                           'stack:bytag':'FOV', 'stack:substacktag':'OBTYPE', 'stack:match:srcext':'.als', 'stack:match:makemode':['wcs'], 'stack:match:improveposwith':'allframe', 'stack:match:improveposmode':-1, 'stack:par:minfrm':1, 'stack:par:percentile':.5, 
                           'photo:allframe:niter':175,
                           };




######################
## FIELD STRUCTURE ###
######################
## ORIENTATION ###
SkZp_DB['_doc_']['pointing']="""Information about the pointing and the field of view of the instrument."""
SkZp_DB['_doc_']['pointing:orientation']="""Dictionary with information about the orientation of the field of view of the instrument.
    'fixfov' : int
        Integer flag about if the the field of view has a fixed pointing or not:
            1 : Perfectly fixed respect ra,dec (the position angle and flipping is the same; typical of instruments of telescopes on equatorial mount).
            0 : It can rotate freely, even during an observation run (e.g. Hubble).
           -1 : It can rotate, but usually during a run X,Y keep the same position angle respect ra,dec (typical of instruments of telescopes on altazimuthal mount).
    'axdirection' : tuple of int
        Integer flag if the sensor axes (x,y) are parallel (+1) or antiparallel (-1) to the celestial tangential axes. Instruments with direct view of the sky have (1,1) (i.e. having declination increasing upwards and right ascension leftwards is (1,1), while if x,y are parallel to ra,dec is (-1,1) )
    """;
SkZp_DB['_doc_']['pointing:accuracy']="""Tuple with probable error in pointing (arcsec, pixel)."""

SkZp_DB['pointing']={'GSAOI':{'orientation':{'fixfov':-1, },'accuracy':(1, 50),},
                     'IMACS_Short-Camera':{'orientation':{'fixfov':-1, },'accuracy':(1, 50),},
                     'IMACS_Long-Camera':{'orientation':{'fixfov':-1, },'accuracy':(1, 50),},
                     'Direct/4Kx4K-4':{'orientation':{'fixfov':1, 'axdirection':(1,1)},'accuracy':(1, 50),},
                     'VIRCAM':{'orientation':{'fixfov':-1, },'accuracy':(1, 50),}, 'VIRCAM:VVV':{'orientation':{'fixfov':-1, },'accuracy':(1, 50),},
                     'DECam':{'orientation':{'fixfov':1, },'accuracy':(1, 50),}, 'Tucan':{'orientation':{'fixfov':1, },'accuracy':(1, 50),}
};

## DISTORSION ###
SkZp_DB['_doc_']['mosoffset']="""Linear trasformation for chips of a mosaic between their XY system and Tangential system. '0' is for the name of the chip selected as reference.
The structure is {0:(pan), 'X':(X_shift, *X, *Y, *X^2, *X*Y, *Y^2, ...), 'Y':(Y_shift, *X, *Y, *X^2, *X*Y, *Y^2, ...) }""";
SkZp_DB['mosoffset']={} 
SkZp_DB['mosoffset']['GSAOI']={'1':(   +1.0, -2186.0,  +0.9717, -0.0013, +0.0054, +0.9976), 
                               '2':(-2206.0, -2186.0,  +1.0015, -0.0004, +0.0070, +0.9987), 
                               '3':(-2185.0,    -1.0,  +0.9987, +0.0016, -0.0295, +0.9966),
                               '4':(   +0.0,    +0.0,  +1.0000, +0.0000, +0.0000, +1.0000),
                               '0':'4'}

SkZp_DB['MOSdistortion']={}
SkZp_DB['MOSdistortion']['GSAOI']={'XY2TAN':{'1':{0:(    0, -2040), 'X':(+109.80, +1.012301, -0.005240,  -6.4630e-6, -0.7839e-6, -6.4819e-6), 'Y':(-54.55, +0.0088626, +0.9986750)}, 
                                             '2':{0:(-2040, -2040), 'X':( -53.19, +1.014186, -0.006859,  -6.9459e-6, -0.6716e-6, -6.8029e-6), 'Y':(-55.14, +0.0093159, +0.9990231)}, 
                                             '3':{0:(-2040,     0), 'X':( -53.25, +1.015191, -0.011735,  -6.7015e-6, -0.6234e-6, -6.0440e-6), 'Y':(+97.25, +0.0122772, +0.9980012)}, 
                                             '4':{0:(    0,     0), 'X':( +97.34, +1.013634, -0.007376,  -6.7308e-6, -0.3860e-6, -6.2116e-6), 'Y':(+96.95, +0.0080727, +0.9978631)}} }
SkZp_DB['MOSdistortion']['IMACSshort']={'XY2TAN':{'1':{0:(    0, -2040), 'X':(+109.80, +1.012301, -0.005240,  -6.4630e-6, -0.7839e-6, -6.4819e-6), 'Y':(-54.55, +0.0088626, +0.9986750)}, 
                                                  '2':{0:(-2040, -2040), 'X':( -53.19, +1.014186, -0.006859,  -6.9459e-6, -0.6716e-6, -6.8029e-6), 'Y':(-55.14, +0.0093159, +0.9990231)}, 
                                                  '3':{0:(-2040,     0), 'X':( -53.25, +1.015191, -0.011735,  -6.7015e-6, -0.6234e-6, -6.0440e-6), 'Y':(+97.25, +0.0122772, +0.9980012)}, 
                                                  '4':{0:(-2040,     0), 'X':( -53.25, +1.015191, -0.011735,  -6.7015e-6, -0.6234e-6, -6.0440e-6), 'Y':(+97.25, +0.0122772, +0.9980012)}, 
                                                  '5':{0:(-2040,     0), 'X':( -53.25, +1.015191, -0.011735,  -6.7015e-6, -0.6234e-6, -6.0440e-6), 'Y':(+97.25, +0.0122772, +0.9980012)}, 
                                                  '6':{0:(-2040,     0), 'X':( -53.25, +1.015191, -0.011735,  -6.7015e-6, -0.6234e-6, -6.0440e-6), 'Y':(+97.25, +0.0122772, +0.9980012)}, 
                                                  '7':{0:(-2040,     0), 'X':( -53.25, +1.015191, -0.011735,  -6.7015e-6, -0.6234e-6, -6.0440e-6), 'Y':(+97.25, +0.0122772, +0.9980012)}, 
                                                  '8':{0:(    0,     0), 'X':( +97.34, +1.013634, -0.007376,  -6.7308e-6, -0.3860e-6, -6.2116e-6), 'Y':(+96.95, +0.0080727, +0.9978631)}} }
SkZp_DB['MOSdistortion']['Direct/4Kx4K-4']={'TAN2XY':{'1':{0:(    0,     0), 'X':(    0.00,  +2.298851, +0.000000,  -0.0000e-6, -0.0000e-6, -0.0000e-6), 'Y':(    0.00,  +0.000000, +2.298851)}, 
                                                      '2':{0:(    0,     0), 'X':(    0.00,  +2.298851, +0.000000,  -0.0000e-6, -0.0000e-6, -0.0000e-6), 'Y':(    0.00,  +0.000000, +2.298851)}, 
                                                      '3':{0:(    0,     0), 'X':( 1927.39,  +2.299079, +0.020899,  -0.0000e-6, -0.0000e-6, -0.0000e-6), 'Y':( 1838.52,  +0.021282, +2.297132)}, 
                                                      '4':{0:(    0,     1), 'X':(    0.00,  +2.298851, +0.000000,  -0.0000e-6, -0.0000e-6, -0.0000e-6), 'Y':(    0.00,  +0.000000, +2.298851)}} }
















#########
## END ##
#########

#For the double naming of GSAOI chips
for db_ in [SkZp_DB['mosoffset']['GSAOI'], SkZp_DB['MOSdistortion']['GSAOI']['XY2TAN'], SkZp_DB['gainronhigh']['GSAOI']['GAIN'], SkZp_DB['gainronhigh']['GSAOI']['RON'], SkZp_DB['gainronhigh']['GSAOI']['HIGH']]:
  for ii in range(1,5):
    ii=str(ii);
    db_['GSAOI_Frame'+ii]=db_[ii];

SkZp_DBI={'_name_':'SkZp_DBI', '_doc_':{}};
for key in SkZp_DB:
  for instr in SkZp_DB[key]:
    SkZp_DBI.setdefault(instr, set());
    SkZp_DBI[instr].add(key);



