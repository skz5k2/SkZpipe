"""Pipes Package.

Modules
-------
    catalogpipe : module
        Pipeline to produce the final photometry and catalog
    photopipe : module
        Pipeline to produce photometric products
    matchstackpipe : module
        Pipeline to use 
    pbsstdmatch : module
        Pipeline to use 
    pipelines : module
        Pipeline to use 
    vspipe : module
        Pipeline to use 
    vvvskzpipeline : module
        Pipeline to use 
    : module
""";

#modules


#from . import allframepipe
from . import catalogpipe
from . import photopipe
from . import matchstackpipe
from . import pbsstdmatch
from . import vspipe
from . import vvvskzpipeline
#from . import pipelines
#from . import pipefunctions
#    pipefunctions : module
#        Pipeline to use 
