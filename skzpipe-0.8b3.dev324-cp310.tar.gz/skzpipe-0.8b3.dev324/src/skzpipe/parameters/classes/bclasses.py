"""Generic classes.
""";

import os, re, math, io, copy 
import multiprocessing as multiprc
import psutil, numpy;
from sys import stdout, stderr



from ...exceptions import *
from .. import basicpar as bpar
from .. import options as _opt

###############################################################################
class Image:
    """Class to define a image

Attributes
----------
    fname : str
        Base name of the image (without extention)
    fwhm : float
        Full Width Half Maximum
    gain : float
        Gain
    ron : float
        Read Out Noise
    hgd : float
       Maximum  
    chip : str
        Chip identificator
    exptime : float
        Exposure time
    filter : str
        Filter (None if no filter)
    airmass : float
        Airmass
    mjd : float
        Modified Julian Day (Julian Day-2400000.5)
    date : str
        Date of observation
    time : str
        Time of observation (UT)
    ra : float
        Right Ascension
    dec : float
        Declination
    instr : str
        Instrument
    nx,ny : int
        Length of the two axes
    bitpix : int
        Bitpix, Bits per pixel
    scale : tuple of float
        Scale in arsec/pixel
    apcorr : tuple of float
        Aperture correction (to be eventually added)

""";

    def __init__(self, data=None):
        """Class to manage image data

Parameters
----------
    data : dict, str
        Dictionary with image data as a dictionary or the name of the image and the data will be retrieved from SkZp_Par['inputdata'].

Attributes
----------

""";
        if(not isinstance(data,(dict,str))): raise TypeError("Image class: wrong input type, it must be tha basename of the image or the dictionary with the data [dict, str]");
        if(isinstance(data, str) or (len(data)==1 and data.get('NAME') )):
            tmpd=bpar.SkZp_Par['inputdata'].get(data if(isinstance(data, str)) else data.get('NAME') )
            if(not tmpd): raise KeyError(f"Image class: input {data} is not a valid image name")
            if(isinstance(data, str)):
                data=tmpd
            else:
                data.update(tmpd)
        if(not all(tag in data for tag in ('NAME', 'FWHM'))): raise TypeError("Image class: input data doesn't have needed keys. (NAME FWHM)");
        
        from ...functions  import getfloat
        self.fname=data['NAME'].strip();
        if(not self.fname or not isinstance(self.fname,str)): raise ValueError("");
        self.fwhm=data.get('FWHM');
        self.gain=data.get('GAIN');
        self.ron=data.get('RON');
        self.hgd=data.get('HIGH');
        self.chip=data.get('CHIP');
        self.exptime=getfloat(data.get('EXPTIME'), 0);
        self.filter=data.get('FILTER');
        self.airmass=data.get('AIRMASS');
        self.mjd=data.get('MJD');
        self.night=data.get('NIGHT');
        self.date=data.get('DATE');
        self.time=data.get('TIME');
        self.ra=data.get('RA');
        self.dec=data.get('DEC');
        self.instr=data.get('INSTRUMENT');
        self.nx=data.get('NX');
        self.ny=data.get('NY');
        self.bitpix=data.get('BITPIX');
        self.scale=data.get('SCALE');
        self.apcorr=data.get('APCORR');
        if(isinstance(self.apcorr,str)): self.apcorr=tuple( getfloat( x, 0) for x in re.split('[,;]',self.apcorr));
    
        if(isinstance(self.scale,str)): self.scale=tuple(float(x) for x in self.scale.split(';'));
        else: self.scale=(self.scale,self.scale);
    
        try:
            self.dataframe=copy.deepcopy(data);
        except:
            print(data.__class__, data)
            raise
   ###

#####
    def __exit__(self, exc_type, exc_value, exc_tb):
        if(exc_type!=None):
            return False;

    def __enter__(self):
        return self;
    
###############################################################################
class MProc():
    """Class for multiprocessing 

Parameters
----------
    nproc : int or bool or None. Default option 'mp:nproc'.
        Number of requiered processes/jobs, or if to use multiprocessing. A value of 1 is equal to 0/False.
        If negative, it will be set to the number of core/cpu less (abs()-1) (joblib style: i.e. -1 for all the cpu, -2 to use all the cpu but one).
        If True, `nproc` will be set to the number of core/cpu.
    narg : int or None
        Number of input data to elaborate.
    method :  str. Default option mp:method'.
        Method for multiprocessing: Process or Pool;
    saferun : int
        Limit the number of processing up to the number of cores (1) or number of core less 1 (-1)
    memreq : int/float or list of int/float
        Amount of memory n MiB required by each process. If it is a number, a list of nproc values will be considered.
        If it is a iterable, only the nproc highest values will be considered.
        nproc will be reduced to match the available system memory.
    minproc : int
        Minimum number of processes/jobs. Useful for elaboration that use few resources and need to be speed up.
        If negative, it will be set to the number of core/cpu less (abs()-1) (joblib style: i.e. -1 for all the cpu, -2 to use all the cpu but one).
        


""";
   # __init__(self, nproc=None, narg=None, method='pool', saferun=True, memreq=0, minproc=0, verb=True):
    _name_="MPRoc";
    error,output=None,None;
    nproc=None;
    pool=None;
    _methT=('pool','process');

    def nproc_set(self, nproc=None, narg=None, method=None, saferun=-1, memreq=0, minproc=0):
        """Set the internal variables according to nproc value.
""";
        _name_='nproc_set';
        if(nproc is None): nproc=self.nproc;
        if(nproc is not None and not isinstance(nproc, (int,bool))): raise TypeError(self._name_+": `nproc` must be an int or bool <{}>".format(nproc));
        if(not isinstance(minproc, int)): raise TypeError(self._name_+": `minproc` must be an int");
        if(narg is not None):
            if( not isinstance(narg, int)): raise TypeError(self._name_+": `narg` must be an int or None <{}>".format(narg));
            elif(narg<=0): raise ValueError(self._name_+": `narg` must be a positive int <{}>".format(narg));
        if(method is not None and not isinstance(method, str)): raise TypeError(self._name_+": `method` must be a str.");
        if(method is not None):
            method=method.lower();
            if(method not in self._methT): raise ValueError(self._name_+": `method` must be {:}.".format(self.methT));
        if(not isinstance(memreq, (int,float, list,tuple))): raise TypeError(self._name_+": `memreq` must be an int or float, or a list/tuple of int/float");

        ncpu=multiprc.cpu_count();
        if(isinstance(nproc, bool)):  self.nproc= ncpu if(nproc) else 0;
        elif(nproc is None): self.nproc=_opt.OptionGet('mp:nproc', otype='I')
        else: self.nproc=nproc;

        if(self.nproc<0): self.nproc= ncpu-abs(nproc+1);  ## joblib style
        if(self.nproc==1): self.nproc=0;
   
   #INPUT
        if(narg is not None): self.nproc=min(narg,self.nproc);

   #SAFERUN
        if(saferun):
            if(self.nproc>ncpu-1):
                if(saferun==-1): self.nproc=ncpu-1;
                elif(self.nproc>ncpu): self.nproc=ncpu;
   #MINIMUM number of process (for jobs that use few resources)
        if(minproc):
            if(minproc<0): minproc= ncpu-abs(minproc+1);  ## joblib style
            if(self.nproc<minproc): self.nproc=minproc;

   #MEMORY
        if(self.nproc):
            if(isinstance(memreq, (int,float))):  memreq=[memreq];
            if(any(x<0 for x in memreq)): raise ValueError("Mproc: 'memreq' must be an int or float, or a list/tuple of int/float");
            if(len(memreq)>1):
                memreqL=sorted(memreq, reverse=True);
                for ii,x in enumerate(memreqL):
                    if(x>0):
                        x=int(x);
                        if(x<=0): x=1;
                        memreqL[ii]=x;
                    else: memreqL[ii]=0;
            else: memreqL=memreq[:];
            if(memreqL[0]>0):
                nwork=len(memreqL);
                if(nwork<self.nproc): memreqL.extend(memreqL[-1:]*(self.nproc-nwork));
                else: memreqL=memreqL[:self.nproc];
                memavl=(psutil.virtual_memory().available>>20)*bpar.SkZp_Par['mp:availmemfrac'];
                memreqC=0;
                for ii,x in enumerate(memreqL):
                    if(x==0): break;
                    memreqC+=x;
                    if(memreqC>memavl):
                        if(ii>0):
                            self.nproc=ii;
                            print(f"!!!Warning: Multiprocessing: number of processes reduced to {self.nproc} for memory limit!!! {memreqL}", file=bpar.SkZp_Par['stdout']);
                        else:
                            self.nproc=1;
                            print("!!!Warning: Multiprocessing: Exceeded memory limit!!! Number of processes reduced to 1!! ",memreqL, file=bpar.SkZp_Par['stdout']);

                        break;

        bpar.ParameterSet('mp:nproc', self.nproc)
        if(self.nproc):
            if(method[0:4]=='proc'):
                self.error=multiprc.Queue();
                self.output=multiprc.Queue();
            elif(method[0:4]=='pool'):
                self.pool=multiprc.Pool(processes=self.nproc)
                if(_opt.OptionGet('debug', otype='Flg')): print(f"nproc={self.nproc}", file=bpar.SkZp_Par['stderr'], flush=True)
        else:
            self.error=[];
            self.output=[];

        return;
    
 ## INIT #START# 
    def __init__(self, nproc=None, narg=None, method='pool', saferun=True, memreq=0, minproc=0, verb=True):
        """MPRoc object for multiprocessing """;

        self._name_='MProc object';
        if(nproc is not None and not isinstance(nproc, (int,bool))): raise TypeError(self._name_+": `nproc` must be an int or bool.");
        if(method is not None and not isinstance(method, str)): raise TypeError(self._name_+": 'method' must be a str.");
        if(method is not None):
            method=method.lower();
            if(method not in self._methT): raise ValueError(self._name_+": 'method' must be {:}.".format(self.methT));
        if(memreq is not None and not isinstance(memreq, (int,float)) and not isinstance(memreq, list) ): 
            raise TypeError(self._name_+": 'memreq' must be an int or float <{}>".format(memreq));
    

        self.nproc=nproc;
        self.nproc_set(nproc=nproc, narg=narg, saferun=saferun, method=method, memreq=memreq, minproc=minproc);
 ## INIT #END# 

    def close(self):
        bpar.SkZp_Par['mp:nproc']= 0

    def __exit__(self, exc_type, exc_value, exc_tb):
        self.close();
        if(exc_type!=None):
            return False;

    def __enter__(self):
        return self;

    def __del__(self):
        self.close();


###############################################################################
class GlobalOutPut:
    """Class to manage the global output.

Parameters
----------
    otype : str
        Type of the output: 'out' for stdout, 'err' for stderr. Deafult 'out'.

    """;
    otype,stream=None,None;
    dbglog,logopn=None,None;
  

    def __init__(self, otype='out'):
        """GlobalOutPut object


""";
        _name_="GlobalOutPut object";
        if(not isinstance(otype,str)): raise ValueError(_name_+": 'otype' must be a str ('out' or 'err')");
        otype=otype.lower();
        if( otype not in ('out', 'err')): raise ValueError(_name_+": 'otype' must be a str ('out' or 'err')");
        self.otype=otype;
        self.stream=stdout if(self.otype == 'out') else stderr;

    def write(self, s=None):
        """Write method of class GlobalOutPut"""
        if(s is None): raise TypeError(self._name_+": write() takes exactly one argument (0 given)");
        if(_opt.OptionGet('debugging:log', otype='Flg')):
            with open(_opt.OptionGet('debugging:logfile', otype='S'), 'a') as flog:
                flog.write(s);
        return self.stream.write(s);


    def flush(self):
        self.stream.flush();
    def writelines(self, datas):
        self.stream.writelines(datas)
    def __getattr__(self, attr):
        return getattr(self.stream, attr);

###############################################################################
class OutputPipe:
  """OutputPipe class: class to manage the output of the parallel processing.

Parameters
----------
    mproc : int or bool
        Number of processes to run parallelly (if >1 the output must be manage for multiprocessing, otherwise not), or if the multiprocessing is on.
    otype : str
        Type of the output: 'out' for like stdout; 'err' for like stderr; 'null' for like '/dev/null': the output will throw away. Deafult 'out'.
    output : str or StringIO or TextIOWrapper
        Name of the file or where store the output when closing the object (deafult SkZp_Par['stdout']);
    mode : str
        The mode in which the output file is opened: 'w' for writing (truncating the file if it already exists), 'a' for appending.

""";
  mproc,output,stream=None,None,None;
  sopened,fopened=True, True;
  mode, otype='w', 'out';
  _name_="OutputPipe";
  

  def __init__(self, mproc=None, otype='out', output=None, mode='w'):
    """OutputPipe onject for output of process""";
    _name_="OutputPipe object";
    if(mproc is not None and not isinstance(mproc, (int,bool))): raise TypeError(_name_+": `mproc` must be a int or bool.");
    if(output is not None and not isinstance(output,(str,io.StringIO, io.TextIOWrapper, OutputPipe)) and not hasattr(output,'write')): raise TypeError(_name_+": `output` can be None, a string or StringIO, TextIOWrapper, OutputPipe, or an object with `write` method.<{}>".format(output.__class__)); 
    if( not isinstance(mode,str)): raise TypeError(_name_+": `mode` must be a str.");
    if( mode not in ('w','a')): raise ValueError(_name_+": wrong value for `mode`: must be 'w' or 'a' (it cannot be read mode 'r') <{}>.".format(mode));
    if( not isinstance(otype,str)): raise TypeError(_name_+": `otype` must be a str.");
    if( otype not in ('out', 'err', 'null')): raise ValueError(_name_+": `otype` must be a str ('out', 'err', 'null') <{}>.".format(otype));
    self.otype=otype;

    if(mproc is None): 
      if(not bpar.SkZp_Par['mp:nproc']):
        mproc=_opt.OptionGet('mp:nproc', otype='I')
      else:
        mproc=bpar.SkZp_Par['mp:nproc'];
    self.mproc=bool(mproc>1) if(isinstance(mproc,int)) else mproc;
    self.output=output;
    if(self.mproc or self.output):
      self.stream= io.StringIO(); #if change it, change in discharge
      self.sopened=True
      if(isinstance(self.output, str)):
        self.output=open(self.output, self.mode);
        self.fopened=True
    else:
      if(self.otype == 'out'):
        self.stream=bpar.SkZp_Par['stdout'];
      elif(self.otype == 'err'):
        bpar.SkZp_Par['stderr'];
        
      self.sopened=False;
    self.mode=mode;
  #### INIT END #

  def write(self, s=None):
    if(s is None): raise TypeError(self._name_+": write() takes exactly one argument (0 given)");
    if(self.otype=='null' or not s): return;
    if(not hasattr(self.stream, 'write')):
      if(_opt.OptionGet('debug', otype='Flg')): print(">>!!{}!!<<".format(s), end=' ');
      return;
    return self.stream.write(s);

  def close(self):
    """Terminate the use of the object, flushing it.
""";
    if(self.stream is None): return;
    outopn=False;
    if(hasattr(self.stream, 'getvalue')):
      if(self.output):
        self.output.write(self.stream.getvalue());
        self.output.flush();
        if(self.sopened): self.stream.close()
        if(self.fopened): self.output.close()
      else:
        output_=bpar.SkZp_Par['stdout'] if(self.otype == 'out') else bpar.SkZp_Par['stderr'];
        output_.write(self.stream.getvalue());
        output_.flush();
    self.stream=None;
    self.output=None;

  def discharge(self):
    self.stream.flush();
    if(self.sopened):
      if(self.output):
        output_=self.output;
      else:
        output_=bpar.SkZp_Par['stdout'] if(self.otype == 'out') else bpar.SkZp_Par['stderr'];
      output_.write(self.stream.getvalue());
      output_.flush();
      self.stream= io.StringIO();  #Same as in init

  def flush(self):
    if(hasattr(self.stream, 'flush')): self.stream.flush();
  def writelines(self, datas):
    self.stream.writelines(datas)
  def __getattr__(self, attr):
    return getattr(self.stream, attr);
    
#  def fileno(self):
#    return self.stream.fileno();
    
  def __exit__(self, exc_type, exc_value, exc_tb):
    self.close();
    if(exc_type!=None):
      return False;

  def __enter__(self):
    return self;

#  def __del__(self):
#    self.close();


###############################################################################
class Region:
  """Class to define region of 2D space."""

  def __init__(self, data=None, x=None, y=None, dx=None, dy=None, shape=None):
    """Class to define region of 2D space.

Parameters
----------
    data : dict
        Dictionary with keys 'x', 'y', 'dx', 'dy', 'shape' that define the region.
    x : float
        First coordinate of the central point.
    y : float
        Second coordinate of the central point.
    dx : float
        Half size along first coordinate.
    dy : float
        Half size along second coordinate.
        
    shape : str
     
""";
    
    if(isinstance(data,dict)):
      if(data.get('x')): x=data['x'];
    
###############################################################################





###############################################################################
    
 #OTHER Class
class CoordTransf:
  """Class that define a coordinate transformation in 'ndim' dimensions.

    coeff : dict or CoordTransf
        Dictionary with the full trasnformation: {0:(pan), 'X':(X_shift, *X, *Y, *X^2, *X*Y, *Y^2, ...), 'Y':(Y_shift, *X, *Y, *X^2, *X*Y, *Y^2, ...) } }
    pan : tuple of floats
        Initial shift (tuple of ndim elements).
    zoom : tuple of floats
        Linear trasformation in the axes (tuple of ndim positive elements).
    flip :  tuple of int
        Change of the sign (mirroring, invertion) along the axes (tuple of ndim 0/1).
    rotate : tuple of floats
        Angles of the rotation (tuple of ndim-1 elements).
    shift :  tuple of floats
        Final shift (tuple of ndim elements).
These five trasformation are executed in the given order.
""";

  def __init__(self, coeff=None, pan=None, zoom=None, rotate=None, flip=None, shift=None, ndim=2):
    if(ndim!=2): raise ValueError('CoordTransf: implemented only 2D')
    if(not coeff):
      if(pan==None): pan=(0.,)*ndim;
      elif(not(isinstance(pan,tuple) or isinstance(pan,list)) or len(pan)!=ndim): raise ValueError('CoordTransf: wrong value for pan');
      if(zoom==None): zoom=(1.,)*ndim;
      elif(not(isinstance(zoom,tuple) or isinstance(pan,list)) or len(zoom)!=ndim): raise ValueError('CoordTransf: wrong value for zoom');
      if(flip==None): flip=(0.,)*ndim;
      elif(not(isinstance(flip,tuple) or isinstance(flip,list)) or len(flip)!=ndim): raise ValueError('CoordTransf: wrong value for flip');
      if(rotate==None): rotate=(0.,)*(ndim-1);
      elif(isinstance(rotate,float) or isinstance(rotate,int)): rotate=(rotate,);
      elif(not (isinstance(rotate,tuple) or isinstance(rotate,list)) or len(rotate)!=ndim-1):  raise ValueError('CoordTransf: wrong value for rotate');
      if(shift==None): shift=(0.,)*ndim;
      elif(not(isinstance(shift,tuple) or isinstance(shift,list)) or len(shift)!=ndim): raise ValueError('CoordTransf: wrong value for shift');
      zoom=( abs(zoom[0]) if(flip[0]==0) else -abs(zoom[0]) , abs(zoom[1]) if(flip[1]==0) else -abs(zoom[1]));
      rotate=(rotate[0]%360,);
      if(rotate[0]==0): cosa,sina=1.,0.;
      elif(rotate[0]==90): cosa,sina=0.,1.;
      elif(rotate[0]==180): cosa,sina=-1.,0.;
      elif(rotate[0]==270): cosa,sina=0.,-1.;
      elif(rotate[0]==45): cosa,sina=0.5*math.sqrt(2),0.5*math.sqrt(2);
      else: cosa,sina=math.cos(rotate[0]/180*math.pi), math.sin(rotate[0]/180*math.pi);
      coeff={0:pan, 'X':(shift[0], zoom[0]*cosa, -zoom[1]*sina), 'Y':(shift[1], zoom[0]*sina, zoom[1]*cosa) };
    if(not isinstance(coeff,(dict,CoordTransf))): raise TypeError("CoordTransf: `coeff` must be dict, a CoordTransf object or None if transformation is define with other parameters.");
    if(isinstance(coeff, CoordTransf)):
      coeff=coeff.coeff.copy();
    else:
      if(0 not in coeff): coeff[0]=(0,0);
      if('X' not in coeff): coeff['X']=(0, 1., 0.);
      if('Y' not in coeff): coeff['Y']=(0, 0., 1.);
      if(len(coeff[0])!=ndim): raise ValueError("CoordTransf: wrong value for coeff[0]");
      if(isinstance(coeff['X'],float)): coeff['X']=(coeff['X'],);
      if(isinstance(coeff['Y'],float)): coeff['Y']=(coeff['Y'],);
      if(len(coeff['X'])==1):
        coeff[0]=(coeff[0][0]+coeff['X'][0],   coeff[0][1]); 
        coeff['X']=(0, 1., 0.);
      if(len(coeff['Y'])==1):
        coeff[0]=(coeff[0][0],   coeff[0][1]+coeff['Y'][0]); 
        coeff['Y']=(0, 0., 1.);
    self.coeff=coeff.copy();

    self.dgr={};
    for tag in ('X','Y'):
      dgr=(math.sqrt(8*len(self.coeff[tag])+1)-3)/2;
      if(dgr!=int(dgr)): raise ValueError("CoordTransf: wrong length for coeff['{:}']".format(tag));
      self.dgr[tag]=int(dgr);

  def concatenate(self, ante=None, post=None):
    if(isinstance(ante, CoordTransf) and post is None):
      coeff={}
      coeff[0]=ante.coeff[0];
      if(self.coeff['X']==(0., 1., 0.)):
        coeff['X']=ante.coeff['X'];
      elif(ante.coeff['X']==(0., 1., 0.)):
        coeff[0]=(coeff[0][0]+self.coeff[0][0], coeff[0][1]);
        coeff['X']=self.coeff['X'];
      else:
        x0= self.coeff['X'][0] + self.coeff['X'][1]*(ante.coeff['X'][0]+self.coeff[0][0]) + self.coeff['X'][2]*(ante.coeff['Y'][0]+self.coeff[0][1]);
        xx= self.coeff['X'][1]*ante.coeff['X'][1] + self.coeff['X'][2]*ante.coeff['Y'][1];
        xy= self.coeff['X'][1]*ante.coeff['X'][2] + self.coeff['X'][2]*ante.coeff['Y'][2];
        coeff['X']=(x0, xx, xy);
      
      if(self.coeff['Y']==(0., 0., 1.)):
        coeff['Y']=ante.coeff['Y'];
      elif(ante.coeff['Y']==(0., 0., 1.)):
        coeff[0]=(coeff[0][0], coeff[0][1]+self.coeff[0][1] );
        coeff['Y']=self.coeff['Y'];
      else:
        y0= self.coeff['Y'][0] + self.coeff['Y'][1]*(ante.coeff['X'][0]+self.coeff[0][0]) + self.coeff['Y'][2]*(ante.coeff['Y'][0]+self.coeff[0][1]);
        yx= self.coeff['Y'][1]*ante.coeff['X'][1] + self.coeff['Y'][2]*ante.coeff['Y'][1];
        yy= self.coeff['Y'][1]*ante.coeff['X'][2] + self.coeff['Y'][2]*ante.coeff['Y'][2];
        coeff['Y']=(y0, yx, yy);
      return CoordTransf(coeff=coeff);
    elif(isinstance(post, CoordTransf) and ante is None):
      return post.concatenate(ante=self);

  def do(self, xy=None):
    """Apply the transformation to a couple of coordinates

Parameters
----------
    xy : object with 
        Couple of coordinates""";
    if(len(xy)!=2): return;
    
    x=xy[0]+self.coeff[0][0];
    y=xy[1]+self.coeff[0][1];
    new={'X':0, 'Y':0};
    for tag in ('X','Y'):
      for dgr in range(self.dgr[tag]+1):
        for idx in range(dgr+1):
          new[tag]+=self.coeff[tag][((dgr*(dgr+1))>>1)+idx]*x**(dgr-idx)*y**(idx);
    return (new['X'], new['Y']);
  
  def applyto(self, points=None):
    """Apply the coordinate trasformation to a set of points given as tuple of coordinates, or list objects

Parameters
----------
    points : tuple of 2 floats, list of tuples of 2 floats, list of object with x,y attributes, iterable of 2-elements objects
        Coordinates to be transformed. They can be a tuple of (x,y), or a list of (x,y) or a list of objects that have attributes x and y

Return
------
    
    """
    outL=[]
    if(isinstance(points, tuple)): points=[points]
#    if(not isinstance(points, list)): raise TypeError(f"CoordTransf.applyto: `points` must be tuple of 2 floats, list of tuples of 2 floats, list of object with x,y attributes.   <{points.__class__}>")

    for ii, pnt in enumerate(points):
      if(isinstance(pnt, tuple)): 
          points[ii]=self.do(pnt)
      elif(hasattr(pnt,'x') and hasattr(pnt,'y')): 
          (pnt.x,pnt.y)=self.do( (pnt.x, pnt.y) )
      else: 
          pnt=pnt.__class__(self.do(tuple(pnt)))
      outL.append(pnt)
    return points.__class__(outL)


###############################################################################
class LinkedNode():
  """Class for a node in a linked list

""";
  node=None;
  nextnd=None;
  prevnd=None

  def __init__(self, obj=None, prevnd=None, nextnd=None):
    _name_="LinkNode";
    if(any(x is not None and not isinstance(x,LinkedNode)  for x in (prevnd, nextnd))): raise TypeError(_name_+": `prevnd` and `nextnd` must be None or LinkedNode object");
    self.node=obj;
    if(prevnd is not None):
      self.prevnd=prevnd;
      if(self.prevnd.nextnd is not None):  #Inserting a new node in a chain
        if(nextnd is not None): raise SkZPipeError("Interrupting a chain: inserting a new node and giving a next node", exclocus=_name_);
        self.nextnd=self.prevnd.nextnd;
        self.prevnd.nextnd=self;
        
        if(self.prevnd is not self.nextnd.prevnd): raise SkZPipeError("Error in the chain where it is inserting a new node: the previous of the next node is not the previous node", exclocus=_name_);
        self.nextnd.prevnd=self;
      else: self.nextnd=nextnd;
    if(self.nextnd is None and nextnd is not None):
      self.nextnd=nextnd;
      if(self.nextnd.prevnd is not None):  #Inserting a new node in a chain
        self.prevnd=self.nextnd.prevnd;
        self.nextnd.prevnd=self;
        
        if(self.nextnd is not self.prevnd.nextnd): raise SkZPipeError("Error in the chain where it is inserting a new node: the next of the previous node is not the next node", exclocus=_name_);
        self.prevnd.nextnd=self;
      

###############################################################################
class GenStructData():
    """Class for data structured in multi lines

Parameters
----------
    data : str, list of str, tuple of values, dict, object with read/readline method
        The several lines appended sequencely, or a sequence of lines.
          str : a string with data that will be split and converted in the values (functions.splitconvert)
          list of str : several lines of input data (same as str)
          tuple of values : the values assigned to attributes according to the order in _dtype_names
          dict : the keys must be contained in _dtype_names. The values will be assigned properly.
          objcet : _dtype_nlines will be read and attributes assigned as list of str
    check_default : bool
        If the first check in initialization has to check if there are default values. Default True.
    attributes : dict
        Dictionary to set the basic attribute: _dtype_names, _dtype_nlines, _dtype_nfield, _dtype_formats, _dtype_delimiter, _str_format.
        Each key is the name of the attribute.
 
Attributes for correct definition
---------------------------------
  _dtype_nlines : int
        For each line, number of line to be read for each source. Default len(_dtype_names).
  _dtype_names : tuple of tuples of str
        For each line, tuple of the names of the variables in the order as they appear in the input.
        '-' for values that has to be skipped (in `_dtype_formats` set the coverters as str).
        If _dtype_nlines is 1 (single-lined data), it can be just a tuple of names (it will transform in a tuple of tuples later).
  _dtype_formats : tuple of tuples of class/coverters 
        For each line, a tuple of object convertibles, one for each item in _dtype_namesa (e.g.   ((int, float, float),) )
        If _dtype_nlines is 1 (single-lined data), it can be just a tuple of coverters (it will transform in a tuple of tuples later).
        Rememeber to set as str the coverter for fields defined as '-' that has to be skipped
  _dtype_nfield : tuple of int
        For each line, number of single datum for each input. Default (len(x) for x in _dtype_names).
        If _dtype_nlines is 1 (single-lined data), it can be just a integer ( len(_dtype_names); it will transform in a tuple of intengers later).
  _dtype_delimiter : None, str, tuple of ints, or a tuple of previous types
        The characters used to separate values or a sequence of integers as width(s) of each field.
        It can be provided as a tuple with a value for each line, or as common value for all of them.
        Default, None (any consecutive  whitespaces act as delimiter).
  _str_format : tuple of formatted string, formatted string
        For each line, formatted string with each replacement field containing as keyword the variable name (as in _dtype_names, except the '-'s).
        If _dtype_nlines is 1 (single-lined data), it can be just a formatted string (it will transform in a tuple of strings later).
  _str_len : tuple of int, int
        For each line, its length.
        If _dtype_nlines is 1 (single-lined data), it can be just an int (it will transform in a tuple of ints later).

  
  If _dtype_nlines is 1 (single-lined data), the attributes must be given coherently, all with one-line format or multi-line format.

Methods
-------
    __str__
        To work with str(), print() (no ending newline)
    __repr__
        For repr()
    __iter__
        To return each value through iteration
    list
        Return a list with each value ordered as in the name definition
    formlist
        Return a list of the values of a certain format `form` in the same order of the name definition, 
        exluding certain attributes in `rej`
""";
    _dtype_names=((), );
 # _dtype_datanames=None;
    _dtype_nlines=len(_dtype_names);
    _dtype_formats=((), )*_dtype_nlines;
    _dtype_nfield=tuple(len(x) for x in _dtype_names);
    _dtype_delimiter=(None,)*_dtype_nlines;
    _str_format=("", "");
    _str_len=(None, None);
  
#  ()=();

 ###__INIT__###
    def _check_def(self, check_value=True):
        pass;

    def __init__(self, data=None, check_default=True, attributes=None):
        """An object from multi-lined structured data. This is not a class for direct use.

""";
        _name_='GenStructData object';
        from ...functions  import splitconvert
        if(data is None or (not isinstance(data,(str,list,tuple, dict,GenStructData,numpy.ndarray)) and not hasattr(data, 'read') and not hasattr(data, 'readline'))):
            raise TypeError(f"{_name_}: Wrong type for `data` to create the object.   < {data.__class__} > < {data} >");
#    if(not self._dtype_datanames): self._dtype_datanames=self._dtype_names;
        self._check_def(check_value=check_default); #Checking and fixing (i.e. self._dtype_names being a tuple of tuples)
    
        #If stream o Wrapper => string
        if(hasattr(data, 'read') or hasattr(data, 'readline')): 
            if(hasattr(data, 'readline')):
                ldata='';
                for ii in range(self._dtype_nlines):
                    ldata+=data.readline();
            else:
                ldata=''; nlines=0;
                while True:
                    if(nlines==self._dtype_nlines): break
                    char=data.read(1);
                    if(not char): raise IOError(_name_+": Reached end of stream before")
                    ldata+=char;
                    if(char=="\n"): nlines+=1
            data=ldata;

        #If string => list of str
        if(isinstance(data,str)): 
            data=data.rstrip('\n').split('\n');
            if(len(data)!=self._dtype_nlines): raise ValueError(_name_+": Wrong number of lines ({lendata}/{nline}) in `data`".format(lendata=len(data), nline=self._dtype_nlines));

        # If list of str => list of list of data
        if(isinstance(data, list) and len(data)==self._dtype_nlines and all(isinstance(x,str) for x in data)): 
            dtmp=[];
            for ii in range(self._dtype_nlines):
                dtmp.append(splitconvert(data=data[ii], delimiter=self._dtype_delimiter[ii],  converters=self._dtype_formats[ii], maxsplit=len(self._dtype_names[ii]), appendinput=False, conv_repeat=False) );
            data=dtmp;

        if(isinstance(data,(list,tuple)) and self._dtype_nlines==1 and len(data)!=self._dtype_nlines): data=[data]; #If _dtype_nlines==1 and list of data => list of list of data


        if(isinstance(data,(list,tuple))):
            for ii in range(self._dtype_nlines):
                self.__dict__.update(dict((var, val) for var,val in zip( self._dtype_names[ii] , data[ii]  ) if(var!='-'))); #
        # data= GenStructData
        elif(isinstance(data, GenStructData)):
            self.__dict__.update(copy.deepcopy(data.__dict__))
        # data= dict
        elif(isinstance(data, dict)):
            _names=self._dtype_names[0]
            for x in self._dtype_names[1:]:
                _names+=x
            _names=set(data)-(set(_names)-{'-'})
            if(_names): raise SkZpipeError(f"in `data` as dict, some keys are not legit attributes names.   <{_names}>", exclocus=_name_)
            self.__dict__.update(copy.deepcopy(data))
        else: raise TypeError(_name_+': Wrong type for `data` in the initialization');

        self._check_def();

 ####
    def _check_def(self, check_value=True):
        """Function to check if the class is defined correctly

Parameters
----------
    check_value : bool
        Check if the variable listed in `_dtype_names` are set. Default True.
""";
        _name_='GenStructData object';
        if(not isinstance(self._dtype_nlines, int)): raise TypeError(_name_+": `_dtype_nlines` must be a positive integer");
        if(self._dtype_nlines<1): raise ValueError(_name_+": `_dtype_nlines` must be a positive integer");
        if(not isinstance(self._dtype_names, tuple)):  raise TypeError(_name_+": `_dtype_names` must be a tuple");
    
       #Fixing 1-line case
        if(self._dtype_nlines==1):
            if(not isinstance(self._dtype_names[0], tuple)): #Attributes given with one-line format
                self._dtype_names=(self._dtype_names,);
                self._dtype_nfield=(self._dtype_nfield,);
                self._dtype_formats=(self._dtype_formats,);
                self._str_format=(self._str_format,);
                self._str_len=(self._str_len,);
       #Fixing delimiters
        if(not isinstance(self._dtype_delimiter,tuple) or (isinstance(self._dtype_delimiter,tuple) and all(isinstance(x,int)for x in self._dtype_delimiter )) ):
            self._dtype_delimiter=(self._dtype_delimiter,)*self._dtype_nlines;
    
       #Checking multilines
        if(any( self._dtype_nlines != len(x) for x in  (self._dtype_names, self._dtype_nfield, self._dtype_formats, self._dtype_delimiter, self._str_format) ) ):
            raise ValueError(_name_+"The class has not been defined correctly! `_dtype_nlines` is not the number of elements in `_dtype_names`, `_dtype_formats` and the entries '{}' in `_str_format`");
       #Checking field number
        for ii in range(self._dtype_nlines):
            if(any( self._dtype_nfield[ii] != len(x) for x in  (self._dtype_names[ii], self._dtype_formats[ii], re.findall("{.*?}", self._str_format[ii])) ) ):
                raise SkZpipeError("The class has not been defined correctly! For the input line {nl}, `_dtype_nfield[{nl}]` <{nfld}> is not the number of elements in `_dtype_names[{nl}]` <{names}>, or `_dtype_formats[{nl}]` <{formats}>, or the entries in `_str_format[{nl}] <{str_f}>`".format(nl=ii, nfld=self._dtype_nfield[ii], names=self._dtype_names[ii], formats=self._dtype_formats[ii], str_f=self._str_format[ii]), exclocus=_name_);
   #Checking delimiters
        for ii in range(self._dtype_nlines):
            if(isinstance(self._dtype_delimiter[ii],tuple)):
                if(any( not isinstance(x,int) for x in self._dtype_delimiter[ii])): 
                    raise TypeError(_name_+"The class has not been defined correctly! For the input line {nl}, `_dtype_delimiter[{nl}]` is a tuple but not of integer".format(nl=ii));
                if(len(self._dtype_delimiter[ii])!=self._dtype_nfield[ii]): 
                    raise ValueError(_name_+"The class has not been defined correctly! `_dtype_nfield[{nl}]` is not the number of elements in `_dtype_delimiter[{nl}]`".format(nl=ii));
    
       #Checking all the variable has a (default) value
        if(check_value):
            for ii in range(self._dtype_nlines):
                for var in self._dtype_names[ii]:
                    if(var!='-'):
                        if(not hasattr(self, var)): 
                            raise SkZpipeError("The class has not been defined correctly! `{var}` for line {nl} of `_dtype_names` is not defined".format(var=var, nl=ii), exclocus=_name_);
    
  ###
    def __str__(self):
        return '\n'.join( fstr.format(**dict( ( var , getattr(self, var) ) for var in tvar if(var!='-') )  ) for fstr,tvar in zip(self._str_format,self._dtype_names)  )
    def __repr__(self):
        return str(self)  #Can be better representation?
    def print(self):
        """String representation terminating with newline
""";
        return str(self)+'\n';
    def __iter__(self):
        for tvar in self._dtype_names:
            for varn in tvar:
                if(varn!='-'):
                    yield getattr(self, varn);
    def list(self):
        """Return a list of the values in the same order of the name definition"""
        return [getattr(self, var) for tvar in self._dtype_names for var in tvar if(var!='-')];
    def formlist(self, form=None, rej=None):
        """Return a list of the values of a certain format `form` in the same order of the name definition, 
        exluding certain attributes in `rej`

Parameters
----------
    form : class
        Class of the values to be selected
    rej : list of str
        List of attributes not to be included
    """
        _name_='GenStructData.formlist'
        if(form is None and not rej): return self.list()
        from inspect import isclass
        if(form is not None and not isclass(form)): raise SkZpipeError("`form` must be None or a class", exclocus=_name_)
        if(rej):
            if(not isinstance(rej, list)): raise SkZpipeError(f"`rej` must be None or a list.   <{rej.__class__}>", exclocus=_name_)
            if(not all(isinstance(x, str) for x in rej)): raise SkZpipeError("`rej` must be a list of str.   {rej}", exclocus=_name_)
        _names=self._dtype_names[0]
        for x in self._dtype_names[1:]:
            _names+=x
        _names=[x for x in _names if(x!='-')]
        if(rej):
            for x in rej:
                if(x in _name): _name.remove(x)
                else: raise SkZpipeError("`rej` must be a list of attribute names. '{x}' do not exist.", exclocus=_name_)
        if(form):
            return [getattr(self, var) for tvar in self._dtype_names for var in _names if(isinstance(var, form))]
        else:
            return [getattr(self, var) for tvar in self._dtype_names for var in _names]
    
###############################################################################

class Multimeasure():
    """Class to store several measures with their uncertainties and retrieve them with indexes. 
It permits to create attributes with indexing operator to retrieve the pair (value,sigma). 
The indexing can be with positional numbers (like a list) or optional names (like a dict).

Parameters
----------
    values : sequence of floats
        List of data values
    sigmas : sequence of floats
        List of data uncertainties. If shorter than `values`, it will be filled with last value.
    names : sequence of str
        List of names variables (same order as `values`)

Attributes
----------
    num : int
        Number of measures
"""

    _values=[] #list of pairs (val,err)
    _names={} #dictionary of name:pos
    num=0
    def __init__(self, values=None, sigmas=None, names=None):
        """An object of Multimeasure class for multi-measure attributes"""
        _name_='Multimeasure object'
    
        if(not values): raise SkZpipeError(f"Wrong type or value for `values`.   <{values}>", exclocus=_name_)
        if(not sigmas): raise SkZpipeError(f"Wrong type or value for `sigmas`.   <{sigmas}>", exclocus=_name_)
        if(not all(isinstance(x,(float,int)) for x in values) or not all(isinstance(x,(float,int)) for x in sigmas) ): 
            raise SkZpipeError(f"Wrong values for `values` or `sigmas`: they must be numbers ", exclocus=_name_);
        if(len(sigmas)<len(values)):
            sigmas=list(sigmas)
            sigmas.extend(sigmas[-1:]*(len(values)-len(sigmas)))
        self._values=list(zip(values,sigmas));
        self.num=len(self._values)
        if(names):
            if(not all(isinstance(x,str) for x in names)): 
                raise SkZpipeError(f"Wrong value for `names`.   <{names}>", exclocus=_name_);
            if(len(names) != self.num): 
                raise SkZpipeError(f"`names` has not the same number of items as `values`.   <{len(names)} != {self.num}>".format(self.num, len(self._names)), exclocus=_name_);
      
            self._names=dict(zip( names, range(self.num)  ));
          
    def __getitem__(self, key):
        _name_='Multimeasure object'
        if(isinstance(key, int)): return self._values[key];
        elif(isinstance(key, str)): return self._values[self._names[key]];
        else: raise TypeError(f'{_name_}: wrong type for key.   <{key}>')
    
    def __setitem__(self, key, value, sigma):
        _name_='Multimeasure object'
        if(not isinstance(value,(int,float))): raise SkZpipeError("Wrong type: `value` must be float.   <{value}>".format(value), exclocus=_name_);
        if(not isinstance(sigma,(int,float))): raise SkZpipeError("Wrong type: `sigma` must be float.   <{value}>".format(sigma), exclocus=_name_);
        if(isinstance(key, int)): self._values[key]=(value, sigma);
        elif(isinstance(key, str)): self._values[self._names[key]]=(value, sigma);
        else: raise TypeError(f'{_name_}: wrong type for `key`.   <{key.__class__}>')
    def __getattr__(self, name=None):
        _name_='Multimeasure object'
        if(not isinstance(name,str)): raise TypeError(f"{_name_}: `name` must be a str.   <{name}>")
        if(not self._names): raise AttributeError(f"{_name_}: there are no named attributes")
        if(name not in self._names): raise AttributeError(f"{_name_} object has no {name} attribute")
        return self._values[self._names[name]]

     
    def list(self, names=None):
        """Return a list of the data (value,sigma). If `names` is given, only these data (and in that order) are returned.

Parameters
----------
    names: sequence of indexes
        Sequence of the indexes of the data to be return as list of tuple
Return
------
    list : list of tuple
        List of tuple of 2 float (value,sigma)
        """
        if(names):   return [ self[key] for key in names]
        else :  return self._values[:]
  
###############################################################################
###############################################################################

class Multivalue():
    """Class to store several single values and retrieve them with indexes. 
It permits to create attributes with indexing operator to retrieve the value. 
The indexing can be with positional numbers (like a list) or optional names (like a dict).

Parameters
----------
    values : sequence of floats
        List of data values
    names : sequence of str
        List of names variables (same order as `values`)

Attributes
----------
    num : int
        Number of values
"""

    _values=[] #list of pairs (val,err)
    _names={} #dictionary of name:pos
    num=0
    def __init__(self, values=None, names=None):
        """An object of Multivalue class for multi-valued attributes""";
        _name_='Multivalue object';
    
        if(not values): raise SkZpipeError(f"Wrong type or value for `values` <{values}>", exclocus=_name_)
        if(not all(isinstance(x,(float,int)) for x in values)): 
            raise SkZpipeError(f"Wrong value for `values` <{values}>", exclocus=_name_);
        self._values=list(values)
        self.num=len(self._values)
        if(names):
            if(not all(isinstance(x,str) for x in names)): 
                raise SkZpipeError(f"Wrong value for `names` <{names}>", exclocus=_name_);
            self._names=tuple(names)  #temporarly a tuple
            if(self.num != len(self._names)): 
                raise SkZpipeError("`names` has not the same number of items as `values` <{} {}>".format(self.num, len(self._names)), exclocus=_name_);
      
            self._names=dict(zip( self._names, range(self.num)  ));
          
    def __getitem__(self, key):
        _name_='Multivalue object'
        if(isinstance(key, int)): return self._values[key];
        elif(isinstance(key, str)): return self._values[self._names[key]];
        else: raise TypeError(f'{_name_}: wrong type for key.   <{key}>')
    
    def __setitem__(self, key, value, sigma):
        _name_='Multivalue object'
        if(not isinstance(value,(int,float))): raise SkZpipeError("Wrong type: `value` must be float.   <{value}>".format(value), exclocus=_name_);
        if(not isinstance(sigma,(int,float))): raise SkZpipeError("Wrong type: `sigma` must be float.   <{value}>".format(sigma), exclocus=_name_);
        if(isinstance(key, int)): self._values[key]=(value, sigma);
        elif(isinstance(key, str)): self._values[self._names[key]]=(value, sigma);
        else: raise TypeError(f'{_name_}: wrong type for `key`.   <{key.__class__}>')
    def __getattr__(self, name=None):
        _name_='Multivalue object'
        if(not isinstance(name,str)): raise TypeError(f"{_name_}: `name` must be a str.   <{name}>")
        if(not self._names): raise AttributeError(f"{_name_}: there are no named attributes")
        if(name not in self._names): raise AttributeError(f"{_name_} object has no {name} attribute")
        return self._values[self._names[name]]

     
    def list(self, names=None):
        """Return a list of the data (value,sigma). If `names` is given, only these data (and in that order) are returned.

Parameters
----------
    names: sequence of indexes
        Sequence of the indexes of the data to be return as list of tuple
Return
------
    list : list of tuple
        List of tuple of 2 float (value,sigma)
        """
        if(names):   return [ self[key] for key in names]
        else :  return self._values[:]
  
###############################################################################
