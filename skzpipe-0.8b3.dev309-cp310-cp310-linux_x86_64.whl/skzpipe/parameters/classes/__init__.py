"""Classes Package.

Modeles
-------
    classes : module
        Definition of several classes
    fileclass : package
        Package with file-related classes (files, format, sources, ...)

""";


#modeles
from . import bclasses 

#Subpackage
from . import fileclass
